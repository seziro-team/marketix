<?php
function handle_login(): void {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
  csrf_check();
  $login = trim($_POST['login'] ?? '');
  $password = $_POST['password'] ?? '';
  $st = db()->prepare('SELECT * FROM users WHERE lower(email)=lower(?) OR id=?');
  $st->execute([$login, strtoupper($login)]);
  $u = $st->fetch();
  if (!$u || !password_verify($password, $u['password_hash'])) {
    flash('Email, member ID or password is wrong.', 'err');
    return;
  }
  if ($u['status'] === 'rejected' || $u['status'] === 'suspended') {
    flash('This account cannot sign in.', 'err');
    return;
  }
  if ($u['role'] === 'admin' || otp_skip_email($u['email'])) {
    session_regenerate_id(true);
    $_SESSION['uid'] = $u['id'];
    $next = $_SESSION['next'] ?? ($u['role'] === 'admin' ? '/admin/' : '/dashboard/');
    unset($_SESSION['next']);
    redirect($next);
  }
  try {
    issue_otp($u['email'], 'login', ['uid' => $u['id']]);
  } catch (Throwable $e) {
    flash('Could not send the verification email. Try again shortly.', 'err');
    return;
  }
  $_SESSION['otp_email'] = $u['email'];
  redirect('/verify/?purpose=login');
}

function handle_register(): void {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
  csrf_check();
  $name = trim($_POST['name'] ?? '');
  $email = strtolower(trim($_POST['email'] ?? ''));
  $mobile = trim($_POST['mobile'] ?? '');
  $country = trim($_POST['country'] ?? '');
  $sponsorIn = strtoupper(trim($_POST['sponsor'] ?? ($_COOKIE['bfx_ref'] ?? '')));
  $leg = $_POST['leg'] ?? 'A';
  $pw = $_POST['password'] ?? '';
  $pw2 = $_POST['confirm'] ?? '';
  if (strlen($name) < 2) { flash('Enter your full name.', 'err'); return; }
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { flash('Enter a valid email.', 'err'); return; }
  if (!valid_country($country)) { flash('Select your country from the list.', 'err'); return; }
  if (strlen($pw) < 8) { flash('Password must be at least 8 characters.', 'err'); return; }
  if ($pw !== $pw2) { flash('Passwords do not match.', 'err'); return; }
  if (empty($_POST['terms'])) { flash('Accept the terms to continue.', 'err'); return; }
  $st = db()->prepare('SELECT id FROM users WHERE lower(email)=?');
  $st->execute([$email]);
  if ($st->fetch()) { flash('That email is already registered.', 'err'); return; }
  if ($sponsorIn === '') { flash('A sponsor ID is required. Use a referral link or enter the ID of the member who introduced you.', 'err'); return; }
  try {
    $sponsorU = resolve_sponsor($sponsorIn);
  } catch (Throwable $e) {
    flash($e->getMessage(), 'err');
    return;
  }
  $payload = [
    'name' => $name, 'email' => $email, 'mobile' => $mobile, 'country' => $country,
    'sponsor' => $sponsorU['id'], 'leg' => $leg,
    'password' => password_hash($pw, PASSWORD_DEFAULT),
    'password_plain' => $pw,
  ];
  try {
    issue_otp($email, 'register', $payload);
  } catch (Throwable $e) {
    flash('Could not send the verification email. Check the address and try again.', 'err');
    return;
  }
  $_SESSION['otp_email'] = $email;
  flash('We sent a 6-digit code to ' . $email . '.');
  redirect('/verify/?purpose=register');
}

function complete_register(array $p): void {
  if (empty($p['sponsor'])) throw new RuntimeException('A sponsor ID is required.');
  $sponsorU = resolve_sponsor((string)$p['sponsor']);
  $place = find_placement($sponsorU['id'], in_array($p['leg'] ?? 'A', ['L','R'], true) ? $p['leg'] : 'A');
  $id = next_id('MTX', 'member', 6);
  $t = now();
  db()->prepare("INSERT INTO users (id, role, email, password_hash, name, mobile, country, sponsor_id, placement_parent_id, leg, status, kyc, created_at, approved_at, wallet_cents)
    VALUES (?,'member',?,?,?,?,?,?,?,?,'active','not_started',?,?,0)")
    ->execute([$id, $p['email'], $p['password'], $p['name'], $p['mobile'] ?? '', $p['country'] ?? 'Canada', $sponsorU['id'], $place['parent'], $place['leg'], $t, $t]);
  $plain = (string)($p['password_plain'] ?? '');
  if ($plain !== '' && !otp_skip_email((string)$p['email'])) {
    try { send_registration_mail((string)$p['email'], (string)$p['name'], $id, $plain); }
    catch (Throwable $e) { /* account is already live; login still works */ }
  }
  flash("Account $id is ready. We emailed your member ID and password. Log in with your email — we will send an OTP.");
}

function page_sponsor_lookup(): void {
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store');
  $id = strtoupper(trim($_GET['id'] ?? ''));
  if ($id === '' || !preg_match('/^[A-Z0-9-]{3,20}$/', $id)) {
    echo json_encode(['ok' => false, 'error' => 'Enter a sponsor ID.']);
    exit;
  }
  $u = user_by_id($id);
  if (!$u || ($u['status'] ?? '') !== 'active') {
    echo json_encode(['ok' => false, 'error' => 'That sponsor ID was not found.']);
    exit;
  }
  $can = can_accept_referrals($u);
  echo json_encode([
    'ok' => true,
    'id' => $u['id'],
    'name' => $u['name'],
    'can_sponsor' => $can,
    'error' => $can ? null : 'This sponsor is not Active yet. New members can join only under an ID with an uncapped funded package.',
  ]);
  exit;
}

function page_verify(): void {
  $purpose = $_GET['purpose'] ?? $_POST['purpose'] ?? '';
  if (!in_array($purpose, ['login', 'register', 'reset'], true)) redirect('/login/');
  $email = $_SESSION['otp_email'] ?? '';
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = strtolower(trim($_POST['email'] ?? $email));
    $code = preg_replace('/\s+/', '', $_POST['code'] ?? '');
    $payload = verify_otp($email, $purpose, $code);
    if ($payload === null) {
      flash('That code is wrong or has expired.', 'err');
    } elseif ($purpose === 'register') {
      complete_register($payload);
      redirect('/login/');
    } elseif ($purpose === 'login') {
      session_regenerate_id(true);
      $_SESSION['uid'] = $payload['uid'];
      unset($_SESSION['otp_email']);
      $u = user_by_id($payload['uid']);
      $next = $_SESSION['next'] ?? (($u['role'] ?? '') === 'admin' ? '/admin/' : '/dashboard/');
      unset($_SESSION['next']);
      redirect($next);
    } elseif ($purpose === 'reset') {
      $_SESSION['reset_ok'] = $payload['uid'];
      redirect('/reset/?set=1');
    }
  }
  auth_shell('login', 'Enter the 6-digit code', 'Sent to ' . ($email ?: 'your email') . '. It expires in 10 minutes.', '<a href="/login/" class="text-brass underline underline-offset-4">Back to log in</a>', function () use ($purpose, $email) { ?>
    <form method="post" class="mt-8 flex flex-col gap-5">
      <?= csrf_field() ?>
      <input type="hidden" name="purpose" value="<?= e($purpose) ?>">
      <input type="hidden" name="email" value="<?= e($email) ?>">
      <div><label class="label" for="code">Code</label><input id="code" class="field" name="code" inputmode="numeric" autocomplete="one-time-code" required autofocus></div>
      <button class="btn-brass h-12 w-full">Verify</button>
    </form>
  <?php });
}

function page_reset(): void {
  if (!empty($_GET['set']) && !empty($_SESSION['reset_ok'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      csrf_check();
      $pw = $_POST['password'] ?? '';
      $pw2 = $_POST['confirm'] ?? '';
      if (strlen($pw) < 8 || $pw !== $pw2) { flash('Passwords must match and be at least 8 characters.', 'err'); }
      else {
        db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $_SESSION['reset_ok']]);
        unset($_SESSION['reset_ok']);
        flash('Password updated. You can log in.');
        redirect('/login/');
      }
    }
    auth_shell('login', 'Choose a new password', 'Must be at least 8 characters.', '<a href="/login/" class="text-brass underline underline-offset-4">Back to log in</a>', function () { ?>
      <form method="post" class="mt-8 flex flex-col gap-5">
        <?= csrf_field() ?>
        <div><label class="label">New password</label><input class="field" type="password" name="password" required></div>
        <div><label class="label">Confirm</label><input class="field" type="password" name="confirm" required></div>
        <button class="btn-brass h-12 w-full">Save password</button>
      </form>
    <?php });
    return;
  }
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $st = db()->prepare("SELECT * FROM users WHERE lower(email)=? AND role='member'");
    $st->execute([$email]);
    $u = $st->fetch();
    if ($u) {
      try { issue_otp($u['email'], 'reset', ['uid' => $u['id']]); } catch (Throwable $e) {}
    }
    $_SESSION['otp_email'] = $email;
    flash('If that email is on file, a code is on its way.');
    if ($u) redirect('/verify/?purpose=reset');
    redirect('/reset/');
  }
  auth_shell('login', 'Reset your password', 'Enter the email on the account. We will send a 6-digit code.', '<a href="/login/" class="text-brass underline underline-offset-4">Back to log in</a>', function () { ?>
    <form method="post" class="mt-8 flex flex-col gap-5">
      <?= csrf_field() ?>
      <div><label class="label" for="email">Email</label><input id="email" class="field" type="email" name="email" required></div>
      <button class="btn-brass h-12 w-full">Send code</button>
    </form>
  <?php });
}

function page_login(): void {
  handle_login();
  $c = cfg();
  auth_shell('login', 'Log in to your account', 'Enter the email or member ID you registered with.', 'No account yet? <a href="/register/" class="text-brass underline underline-offset-4">Open one</a>', function () use ($c) { ?>
    <form method="post" class="mt-8 flex flex-col gap-5">
      <?= csrf_field() ?>
      <div><label class="label" for="login">Email or member ID</label><input class="field" id="login" name="login" placeholder="you@example.com" autocomplete="username" required></div>
      <div><label class="label" for="password">Password</label><input class="field" id="password" name="password" type="password" placeholder="••••••••" autocomplete="current-password" required></div>
      <label class="text-muted flex items-center gap-2.5 text-[0.875rem]"><input type="checkbox" name="remember" class="accent-[var(--color-brass)]"> Keep me signed in on this device</label>
      <button class="btn-brass h-12 w-full text-[0.9375rem]">Log in</button>
      <p class="text-center text-[0.8125rem]"><a href="/reset/" class="text-brass underline underline-offset-4">Forgot password</a></p>
    </form>
    <div class="border-line mt-8 border-t pt-6">
      <p class="tag mb-3">Need access now?</p>
      <a href="mailto:<?= e($c['support_email']) ?>" class="btn-ghost h-11 w-full text-sm font-medium">Email <?= e($c['support_email']) ?></a>
    </div>
  <?php });
}

function page_register(): void {
  if (!empty($_GET['ref'])) setcookie('bfx_ref', strtoupper($_GET['ref']), time()+86400*30, '/');
  handle_register();
  $ref = strtoupper($_GET['ref'] ?? ($_COOKIE['bfx_ref'] ?? ''));
  auth_shell('register', 'Open an account', 'Registration takes a few minutes. Verify the email OTP, then you can log in and fund in USDT on BEP20.', 'Already registered? <a href="/login/" class="text-brass underline underline-offset-4">Log in</a>', function () use ($ref) { ?>
    <form method="post" class="mt-8 flex flex-col gap-5">
      <?= csrf_field() ?>
      <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div><label class="label" for="name">Full name</label><input class="field" id="name" name="name" placeholder="As on your ID" autocomplete="name" required></div>
        <div><label class="label" for="email">Email</label><input class="field" id="email" name="email" type="email" placeholder="you@example.com" autocomplete="email" required></div>
        <div>
          <label class="label" for="mobile">Mobile number <span class="text-faint font-normal normal-case tracking-normal">(optional)</span></label>
          <input class="field" id="mobile" name="mobile" placeholder="+91 …" autocomplete="tel">
          <p class="text-faint mt-1.5 text-[0.75rem] leading-relaxed">Completely optional. An email address is enough to open an account.</p>
        </div>
        <div>
          <label class="label" for="country">Country</label>
          <?= country_select('country', 'India', true, 'country') ?>
        </div>
      </div>
      <div class="border-line border-t pt-5">
        <p class="tag mb-4">Placement</p>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div>
            <label class="label" for="sponsor">Sponsor ID</label>
            <input class="field" id="sponsor" name="sponsor" placeholder="MTX-100001" value="<?= e($ref) ?>" required autocomplete="off">
            <p id="sponsor-preview" class="sponsor-preview" hidden></p>
          </div>
          <input type="hidden" name="leg" value="A">
        </div>
        <p class="text-faint mt-3 text-[0.75rem] leading-relaxed">A sponsor ID is required. The sponsor’s name appears below so you can confirm whose team you are joining. The desk ID is MTX-ADMIN.</p>
      </div>
      <script>
      (function () {
        var input = document.getElementById('sponsor');
        var box = document.getElementById('sponsor-preview');
        if (!input || !box) return;
        var t = null;
        function paint(ok, text) {
          box.hidden = !text;
          box.textContent = text || '';
          box.className = 'sponsor-preview' + (ok ? ' ok' : ' err');
        }
        function lookup() {
          var id = (input.value || '').trim().toUpperCase();
          input.value = id;
          if (id.length < 3) { paint(false, ''); return; }
          fetch('/register/lookup/?id=' + encodeURIComponent(id), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (d) {
              if (!d || !d.ok) { paint(false, (d && d.error) || 'That sponsor ID was not found.'); return; }
              paint(true, 'Sponsor: ' + d.name + ' · ' + d.id);
            })
            .catch(function () { paint(false, 'Could not verify this sponsor ID.'); });
        }
        input.addEventListener('input', function () { clearTimeout(t); t = setTimeout(lookup, 280); });
        input.addEventListener('blur', lookup);
        if (input.value) lookup();
      })();
      </script>
      <div class="border-line grid grid-cols-1 gap-5 border-t pt-5 sm:grid-cols-2">
        <div><label class="label">Password</label><input class="field" type="password" name="password" autocomplete="new-password" required></div>
        <div><label class="label">Confirm password</label><input class="field" type="password" name="confirm" autocomplete="new-password" required></div>
      </div>
      <label class="text-muted flex items-start gap-2.5 text-[0.8125rem] leading-relaxed">
        <input type="checkbox" name="terms" class="mt-1 accent-[var(--color-brass)]" required>
        <span>I have read the <a href="/terms/" class="text-brass underline underline-offset-2">terms of service</a> and <a href="/privacy/" class="text-brass underline underline-offset-2">privacy policy</a>.</span>
      </label>
      <button class="btn-brass h-12 w-full text-[0.9375rem]">Create account</button>
    </form>
  <?php });
} ?>
