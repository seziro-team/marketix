# Marketix Ltd — Hostinger public_html pack

This folder is what you upload to Hostinger **File Manager → public_html**, after deleting the old site. PHP 8 + SQLite. No Node, no MySQL.

Production domain: **https://marketix.ltd**

## Before email will send

Create these mailboxes in hPanel for marketix.ltd:

- `noreply@marketix.ltd` — the sender
- `support@marketix.ltd` — the desk inbox

Then paste the noreply mailbox password into `config.php` → `smtp_password`. Until that is set, registration and OTP emails cannot leave the server.

## Upload

1. Zip this folder, including the hidden `.htaccess`. Leave out `data/` if a database is already in it.
2. Delete the old files in `public_html` so nothing from the previous site remains.
3. Upload and extract so `index.php` and `.htaccess` sit in `public_html`, not inside an extra folder.
4. Make `data/` writable (755 or 775).
5. Open https://marketix.ltd . The database and the desk login are created on first load.
6. In hPanel → Cron Jobs, call this once a day:

   `https://marketix.ltd/cron.php?key=AGUbev3aZo4RzdRKQZyL`

## Desk login

| | |
| --- | --- |
| Email | `support@marketix.ltd` |
| Password | `Mtx-Desk-2026-k7Q` |
| Member ID | `MTX-ADMIN` |

Change the password under Admin → Members after the first login. New members join with sponsor `MTX-ADMIN`, or with any member’s referral link. The sponsor’s name is shown on the registration form.

## How money moves

1. Member sends **USDT on BEP20** to `0x4a80a20c5f9750b610dbC39f229B273174aCA65D` and submits the hash.
2. Desk approves it. The amount lands in the **fund wallet**. It does not start a plan by itself.
3. Member activates a package from that balance. The 24-hour clock starts then. The sponsor receives **10%**.
4. Interest credits every 24 hours after activation: Plan 1 **8%** ($100–$500), Plan 2 **10%** ($600–$5,000), Plan 3 **12%** ($6,000–$50,000), Plan 4 **15%** ($60,000 and up).
5. Withdrawals come from available income. Minimum **$10**, fee **10%**, transaction password, then an email code. Reviewed and released within 1–2 hours.
6. Reinvest spends available income on a new package. Top-up moves fund-wallet balance to another member and asks for an email code. Changing a saved payout address also asks for an email code.

Plan 1’s 8% is taken from the handwritten sheet, where an 8 is visible next to a corrected digit. Say if that rate should be different.

## PDFs

- `/marketix-presentation.pdf`
- `/marketix-member-guide.pdf`
