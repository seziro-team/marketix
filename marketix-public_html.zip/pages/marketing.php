<?php
function page_home(): void {
  $c = cfg();
  ?>
  <section class="hero">
    <div class="hero-in">
      <p class="eyebrow"><i></i>Since <?= e((string)$c['founded']) ?> · United States</p>
      <h1>Welcome to Marketix Ltd</h1>
      <p class="kicker">Your future is created by what you do today.</p>
      <p class="lede">Marketix Ltd is a fully certified, licensed company in the United States which offers investors around the globe reliable investment schedules, with a minimum investment as low as $100.</p>
      <div class="hero-actions">
        <a class="btn-sky" href="/register/">Open an account</a>
        <a class="btn-ghost" href="/business-plan/">Business plan</a>
      </div>
      <div class="hero-facts">
        <div><b>$100</b><span>Minimum investment</span></div>
        <div><b>8–15%</b><span>Interest after 24 hours</span></div>
        <div><b>USDT</b><span>BEP20 payments only</span></div>
        <div><b>10%</b><span>Referral income</span></div>
      </div>
    </div>
  </section>
  <div class="wrap overlap">
    <div class="cards-3">
      <article class="feature">
        <div class="ico"><?= icon('trending-up', 'h-6 w-6') ?></div>
        <h3>Stable income</h3>
        <p>We trade different types of forex and cryptocurrency to maximize profit.</p>
      </article>
      <article class="feature">
        <div class="ico"><?= icon('banknote', 'h-6 w-6') ?></div>
        <h3>Withdrawal processing</h3>
        <p>Manually reviewed, and released within 1–2 hours.</p>
      </article>
      <article class="feature">
        <div class="ico"><?= icon('users', 'h-6 w-6') ?></div>
        <h3>Over 10+ years of experience</h3>
        <p>With a large investor community, we can assure you the best profit-earning opportunity. Grab the chance and grow with us in this trading industry.</p>
      </article>
    </div>
  </div>

  <section class="section">
    <div class="wrap cards-2">
      <div class="split-copy">
        <p class="kicker-sky">About us</p>
        <h2>A licensed company, running since <?= e((string)$c['founded']) ?>.</h2>
        <p class="intro">Our indefinitely scalable investment platform is solving one of the most limiting and long-due issues of the current investment market without any compromise.</p>
        <ul class="ticks">
          <li><?= icon('check', 'h-4 w-4') ?><span>The mission of Marketix is to set up, promote and implement high quality standards for competence and ethical behavior for the financial advisory sector.</span></li>
          <li><?= icon('check', 'h-4 w-4') ?><span>Chief executive <?= e($c['ceo']) ?>.</span></li>
          <li><?= icon('check', 'h-4 w-4') ?><span>We offer the best forex and cryptocurrency investment platform, with a wide range of investments.</span></li>
        </ul>
        <div class="hero-actions">
          <a class="btn-sky" href="/about/">About us</a>
          <a class="btn-ghost" href="/contact/">Contact us</a>
        </div>
      </div>
      <div class="photo-frame">
        <img src="/img/deck/skyline.jpg" alt="New York skyline">
        <div class="photo-cap"><b><?= e($c['name']) ?></b><span><?= e($c['address_city']) ?>, <?= e($c['address_region']) ?> · Fully certified and licensed</span></div>
      </div>
    </div>
  </section>

  <section class="section" style="padding-top:0">
    <div class="wrap">
      <p class="kicker-sky">We offer</p>
      <h2>Forex and cryptocurrency, in one place.</h2>
      <div class="cards-2" style="margin-top:22px;align-items:stretch">
        <article class="offer">
          <div class="ico"><?= icon('layers', 'h-6 w-6') ?></div>
          <h3>The best forex and cryptocurrency investment platform</h3>
          <p>We offer the best forex and cryptocurrency investment platform. Payments are accepted in USDT on BEP20 only.</p>
        </article>
        <article class="offer">
          <div class="ico"><?= icon('wallet', 'h-6 w-6') ?></div>
          <h3>A wide range of investments</h3>
          <p>We offer a wide range of forex and cryptocurrency investments, from $100, across four published plans.</p>
        </article>
      </div>
    </div>
  </section>

  <section class="section" style="padding-top:0">
    <div class="wrap">
      <p class="kicker-sky">Get started</p>
      <h2>Three simple steps.</h2>
      <?php public_steps(); ?>
    </div>
  </section>

  <section class="section" style="padding-top:0" id="plans">
    <div class="wrap">
      <p class="kicker-sky">Investment package</p>
      <h2>Four plans. Interest after 24 hours.</h2>
      <p class="intro">Choose the band that matches the amount you want to activate. Interest is credited once every 24 hours from activation.</p>
      <div style="margin-top:22px"><?php public_plans(); ?></div>
    </div>
  </section>

  <section class="section" style="padding-top:0">
    <div class="wrap">
      <p class="kicker-sky">Why us</p>
      <h2>Protected, active, and answered.</h2>
      <div style="margin-top:22px"><?php public_why(); ?></div>
    </div>
  </section>

  <section class="section" style="padding-top:10px">
    <div class="wrap">
      <div class="band">
        <div>
          <h2>We are an award-winning multinational company.</h2>
          <p>We believe in quality and standard worldwide. Open an account, choose a plan, and fund in USDT on BEP20.</p>
        </div>
        <a class="btn-sky" href="/register/">Open an account</a>
      </div>
    </div>
  </section>
<?php }

function page_about(): void {
  $c = cfg();
  public_banner('About us', 'Welcome to Marketix Ltd.', 'A fully certified, licensed company in the United States, running since ' . $c['founded'] . '.');
  ?>
  <section class="section">
    <div class="wrap cards-2">
      <div>
        <p class="kicker-sky">The company</p>
        <h2>Reliable schedules, from $100.</h2>
        <p class="intro">Marketix is a fully certified, licensed company in the United States which offers investors around the globe reliable investment schedules, with a minimum investment as low as $100.</p>
        <p class="intro">Our indefinitely scalable investment platform is solving one of the most limiting and long-due issues of the current investment market without any compromise.</p>
        <p class="intro">The mission of Marketix is to set up, promote and implement high quality standards for competence and ethical behavior for the financial advisory sector.</p>
      </div>
      <article class="panel">
        <p class="kicker-sky">At a glance</p>
        <ul class="ticks">
          <li><?= icon('check', 'h-4 w-4') ?><span>Running since <?= e((string)$c['founded']) ?></span></li>
          <li><?= icon('check', 'h-4 w-4') ?><span>Chief executive <?= e($c['ceo']) ?></span></li>
          <li><?= icon('check', 'h-4 w-4') ?><span>Forex and cryptocurrency</span></li>
          <li><?= icon('check', 'h-4 w-4') ?><span>Settlement in USDT on BEP20</span></li>
          <li><?= icon('check', 'h-4 w-4') ?><span><?= e($c['address']) ?></span></li>
        </ul>
      </article>
    </div>
    <div class="wrap">
      <div class="people">
        <figure>
          <img src="/brand/ceo.jpg" alt="<?= e($c['ceo']) ?>, Chief Executive Officer">
          <figcaption><b><?= e($c['ceo']) ?></b><span>Chief Executive Officer</span></figcaption>
        </figure>
        <figure>
          <img src="/brand/certificate.jpg" alt="Company certificate" style="object-fit:contain;background:#fff">
          <figcaption><b>Fully certified and licensed</b><span><?= e($c['address_city']) ?>, <?= e($c['address_region']) ?></span></figcaption>
        </figure>
      </div>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <p class="kicker-sky">We offer</p>
      <h2>Forex and cryptocurrency investments.</h2>
      <div class="cards-2" style="margin-top:22px">
        <article class="offer">
          <h3>Investment platform</h3>
          <p>We offer the best forex and cryptocurrency investment platform.</p>
        </article>
        <article class="offer">
          <h3>A wide range</h3>
          <p>We offer a wide range of forex and cryptocurrency investments.</p>
        </article>
      </div>
      <div style="margin-top:22px"><?php public_why(); ?></div>
    </div>
  </section>
<?php }

function page_business(): void {
  public_banner('Business plan', 'Choose a plan and make the investment.', 'Interest is credited after 24 hours, counted from the time the package is activated.');
  ?>
  <section class="section">
    <div class="wrap">
      <p class="kicker-sky">Investment package</p>
      <h2>Plan 1 through Plan 4.</h2>
      <p class="intro">Whether you are seeking stable growth, high returns or a balanced approach, Marketix offers a diverse range of plans. All payments are in USDT on BEP20.</p>
      <div style="margin-top:22px"><?php public_plans(); ?></div>
    </div>
  </section>
  <section class="section" style="padding-top:0">
    <div class="wrap">
      <p class="kicker-sky">Get started</p>
      <h2>Three simple steps.</h2>
      <?php public_steps(); ?>
      <div class="cards-3" style="margin-top:22px">
        <article class="why">
          <h3>Referral income</h3>
          <p>10% when a direct member activates a package, and 10% again when they reinvest. A deposit that has not been activated does not pay the referral.</p>
        </article>
        <article class="why">
          <h3>Withdrawal</h3>
          <p>Manually reviewed and released within 1–2 hours. Minimum $10 from income. A 10% fee is deducted. Principal stays invested.</p>
        </article>
        <article class="why">
          <h3>Support</h3>
          <p>24/7 service. All support requests are answered within a maximum of 24 hours.</p>
        </article>
      </div>
    </div>
  </section>
<?php }

function page_contact(): void {
  $c = cfg();
  public_banner('Contact us', 'We are here around the clock.', 'All support requests are answered within a maximum of 24 hours. Withdrawals are released within 1–2 hours after review.');
  ?>
  <section class="section">
    <div class="wrap contact-grid">
      <div>
        <article class="info-card"><?= icon('map-pin', 'h-5 w-5') ?><div><b>Address</b><span><?= e($c['address']) ?></span></div></article>
        <article class="info-card"><?= icon('mail', 'h-5 w-5') ?><div><b>Mail</b><a href="mailto:<?= e($c['support_email']) ?>"><?= e($c['support_email']) ?></a></div></article>
        <article class="info-card"><?= icon('phone', 'h-5 w-5') ?><div><b>Phone</b><a href="tel:<?= e($c['phone_tel']) ?>"><?= e($c['phone']) ?></a></div></article>
        <article class="info-card"><?= icon('share-2', 'h-5 w-5') ?><div><b>Telegram</b><a href="<?= e($c['telegram']) ?>" target="_blank" rel="noopener"><?= e($c['telegram_handle']) ?></a></div></article>
        <article class="info-card"><?= wa_glyph() ?><div><b>WhatsApp</b><a href="<?= e($c['whatsapp']) ?>" target="_blank" rel="noopener">Message us on WhatsApp</a></div></article>
      </div>
      <form class="panel form-grid" method="post" action="/contact/">
        <?= csrf_field() ?>
        <div>
          <p class="kicker-sky">Write to the desk</p>
          <h2 style="font-size:1.6rem;margin-top:6px">Send a message</h2>
        </div>
        <div class="form-row">
          <div><label class="label" for="name">Name</label><input class="field" id="name" name="name" required></div>
          <div><label class="label" for="email">Email</label><input class="field" id="email" name="email" type="email" required></div>
        </div>
        <div>
          <label class="label" for="interest">Interest</label>
          <select class="field" id="interest" name="interest">
            <option value="General">General</option>
            <?php foreach (plan()['plans'] as $row): ?>
              <option><?= e($row['name']) ?></option>
            <?php endforeach; ?>
            <option>Account support</option>
          </select>
        </div>
        <div><label class="label" for="message">Message</label><textarea class="field" id="message" name="message" rows="6" required></textarea></div>
        <button class="btn-sky" type="submit" style="height:48px">Send message</button>
        <p class="help">The form is delivered to <?= e($c['support_email']) ?>.</p>
      </form>
    </div>
  </section>
<?php }

function page_legal_doc(string $kicker, string $title, string $lede, string $updated, array $clauses): void {
  public_banner($kicker, $title, $lede);
  ?>
  <section class="section">
    <div class="wrap-s legal">
      <p class="legal-meta">Updated <?= e($updated) ?></p>
      <?php foreach ($clauses as $i => $c): ?>
        <section id="c<?= $i + 1 ?>">
          <h2><?= e($c['h']) ?></h2>
          <?php foreach ($c['p'] as $para): ?><p><?= e($para) ?></p><?php endforeach; ?>
        </section>
      <?php endforeach; ?>
    </div>
  </section>
<?php }

function page_terms(): void {
  $c = cfg();
  page_legal_doc(
    'Terms of service',
    'The rules of membership.',
    'What you agree to when you open an account on ' . $c['domain'] . '.',
    '4 November 2026',
    [
      ['h' => 'Who these terms are between', 'p' => [
        'These terms govern your use of ' . $c['domain'] . ' and your membership of ' . $c['name'] . ', a United States company at ' . $c['address'] . '. By registering an account you accept them.',
        'If you do not accept them, do not register and do not send funds.',
      ]],
      ['h' => 'Eligibility', 'p' => [
        'You must be at least 18 years old and legally able to enter a contract where you live.',
        'One person may hold one account. Accounts opened to manufacture referral volume may be closed.',
      ]],
      ['h' => 'Opening an account', 'p' => [
        'Registration needs a full name, an email address, a country, a password, a sponsor ID, and acceptance of these terms and the privacy policy. A mobile number is optional.',
        'The sponsor’s name is shown before you submit. Member IDs are in the form MTX-……. We email your member ID and password, and a one-time code from ' . $c['from_email'] . '.',
      ]],
      ['h' => 'Deposits', 'p' => [
        'Deposits are accepted in USDT on BEP20 only, to the company address shown in your dashboard. The minimum deposit is $100.',
        'You submit the amount and the transaction hash. Approval credits your fund wallet. It does not open a plan by itself and it does not pay a referral.',
      ]],
      ['h' => 'Plans', 'p' => [
        'You activate a plan from the fund wallet. Plan 1 is $100 to $500 at 8%. Plan 2 is $600 to $5,000 at 10%. Plan 3 is $6,000 to $50,000 at 12%. Plan 4 is $60,000 and above at 15%.',
        'Amounts from $501 to $599, $5,001 to $5,999, and $50,001 to $59,999 are not accepted.',
        'Interest is credited once every 24 hours, counted from the moment that package is activated. There is no profit cap. Principal stays invested. Reinvesting uses available income and opens another package on the same rules.',
      ]],
      ['h' => 'Referral', 'p' => [
        'The sponsor receives 10% of the amount a direct member uses to activate a package, and 10% again if that member reinvests. It is credited to the sponsor’s income.',
        'You may move at least $1 from your fund wallet to another member’s fund wallet. That transfer needs an email code. It is not a plan and it does not pay a referral.',
      ]],
      ['h' => 'Withdrawals', 'p' => [
        'Withdrawals are taken from available income. The minimum is $10. A 10% fee is deducted. A withdrawal needs your transaction password and then an email code. It is manually reviewed and released within 1–2 hours to the USDT BEP20 address on your profile.',
        'The first time you save a receiving address, it is stored immediately. Changing a saved address needs an email code.',
      ]],
      ['h' => 'Your details and conduct', 'p' => [
        'You are responsible for the details on your profile and for keeping your passwords secret. Optional identity documents, a front and a back, can be uploaded from settings.',
        'You must not use the platform for money laundering or on behalf of an undisclosed third party, and you must not attempt to access another member’s account.',
      ]],
      ['h' => 'Support', 'p' => [
        'Member support is ' . $c['support_email'] . ', ' . $c['phone'] . ', Telegram ' . $c['telegram_handle'] . ', and the ticket desk inside your dashboard. The desk is open 24/7 and replies within 24 hours.',
        'To report fraud or a grievance about the website itself, use Report to developer in the footer.',
      ]],
      ['h' => 'Changes and disputes', 'p' => [
        'We may update these terms. The date at the top of this page is the current version.',
        'Raise a membership dispute first by writing to ' . $c['support_email'] . '. Governing law is the law of the State of New York, United States.',
      ]],
    ]
  );
}

function page_privacy(): void {
  $c = cfg();
  page_legal_doc(
    'Privacy policy',
    'What we hold about you.',
    'The data ' . $c['domain'] . ' needs to run your account, and who sees it.',
    '4 November 2026',
    [
      ['h' => 'Who controls your data', 'p' => [
        $c['name'] . ', at ' . $c['address'] . ', is the controller. Write to ' . $c['support_email'] . ' with any question about it.',
      ]],
      ['h' => 'What we collect', 'p' => [
        'Account details you give us: full name, email, country, password (stored as a hash), optional mobile number, and the sponsor ID.',
        'Profile details you add later: USDT BEP20 address, transaction password (stored as a hash), and optional identity images.',
        'Financial records of deposits, plan activations, interest, referral, reinvests and withdrawals, plus support tickets and developer reports.',
      ]],
      ['h' => 'Why we collect it', 'p' => [
        'To open and operate your account, send email codes, credit interest and referral, and process deposits and withdrawals.',
        'To show your sponsor the details the referral is calculated from. They cannot see your email, password, wallet address or ticket history.',
      ]],
      ['h' => 'Who else sees it', 'p' => [
        'The hosting provider that runs ' . $c['domain'] . ', and the email provider that sends mail from ' . $c['from_email'] . '.',
        'A deposit or withdrawal on BNB Smart Chain is public on that network. We do not sell personal data.',
      ]],
      ['h' => 'Cookies and language', 'p' => [
        'We use a cookie to keep you signed in and to protect forms.',
        'The language control at the top of the public pages is a translator. If you choose a language, that service may set its own cookie. We do not use advertising cookies.',
      ]],
      ['h' => 'Your rights', 'p' => [
        'You can ask for a copy of your data, ask us to correct it, and ask us to delete it where we are not required to keep it. Write to ' . $c['support_email'] . '.',
      ]],
    ]
  );
}

function handle_report(): void {
  csrf_check();
  $return = (string)($_POST['return'] ?? '/');
  if ($return === '' || $return[0] !== '/' || str_starts_with($return, '//') || str_contains($return, "\n") || str_contains($return, "\r")) {
    $return = '/';
  }
  if (!empty($_POST['website'])) {
    redirect($return);
  }
  $name = trim((string)($_POST['name'] ?? ''));
  $phone = trim((string)($_POST['phone'] ?? ''));
  $details = trim((string)($_POST['details'] ?? ''));
  $phoneDigits = preg_replace('/\D+/', '', $phone) ?? '';
  $reopen = (str_contains($return, '?') ? '&' : '?') . 'report=1';
  if (strlen($name) < 2 || strlen($details) < 20) {
    flash('Name and a description of the issue are required.', 'err');
    redirect($return . $reopen);
  }
  if ($phone !== '' && strlen($phoneDigits) < 8) {
    flash('If you add a contact number, use a working one.', 'err');
    redirect($return . $reopen);
  }
  $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
  $st = db()->prepare('SELECT COUNT(*) FROM reports WHERE ip = ? AND created_at > ?');
  $st->execute([$ip, gmdate('c', time() - 300)]);
  if ((int)$st->fetchColumn() >= 3) {
    flash('Please wait a few minutes before sending another report.', 'err');
    redirect($return . $reopen);
  }
  db()->prepare('INSERT INTO reports (name, phone, details, ip, created_at) VALUES (?,?,?,?,?)')
    ->execute([$name, $phone, $details, $ip, now()]);
  $body = "Name: {$name}\nPhone: " . ($phone !== '' ? $phone : '—') . "\nPage: {$return}\n\n{$details}\n";
  try {
    send_mail(report_email(), cfg()['name'] . ' report — ' . $name, $body);
    flash('Report sent.');
  } catch (Throwable $e) {
    flash('Saved, but the report could not be sent. Please try again.', 'err');
  }
  redirect($return);
}

function page_not_found(): void { ?>
  <section class="section not-found">
    <div class="wrap-s">
      <p class="kicker-sky">404</p>
      <h1>That page is not on this site.</h1>
      <p class="intro">The address does not match a page. Use one of the links below.</p>
      <ul>
        <?php foreach (public_nav() as [$label, $href]): ?>
          <li><a href="<?= e($href) ?>"><?= e($label) ?><span><?= e($href) ?></span></a></li>
        <?php endforeach; ?>
      </ul>
      <div class="hero-actions"><a class="btn-sky" href="/">Back to home</a></div>
    </div>
  </section>
<?php }
