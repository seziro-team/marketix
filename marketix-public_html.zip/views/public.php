<?php
function public_nav(): array {
  return [
    ['Home', '/'],
    ['About Us', '/about/'],
    ['Business Plan', '/business-plan/'],
    ['Contact Us', '/contact/'],
  ];
}

function wa_glyph(): string {
  return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.5 3.5A11 11 0 0 0 2.1 16.8L1 23l6.4-1.1A11 11 0 0 0 20.5 3.5zM12 20.2a8.2 8.2 0 0 1-4.2-1.1l-.3-.2-3.8.6.6-3.7-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.4-.7-1.6-.8s-.4-.1-.5.1-.6.8-.7.9-.3.2-.5.1a6.7 6.7 0 0 1-2-1.2 7.4 7.4 0 0 1-1.4-1.7c-.1-.2 0-.4.1-.5l.4-.4.2-.3a1.8 1.8 0 0 0 .2-.4.5.5 0 0 0 0-.4c0-.1-.5-1.3-.7-1.8s-.4-.4-.5-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 12 12 0 0 0 4.5 4 15 15 0 0 0 1.5.5 3.6 3.6 0 0 0 1.7.1 2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.2-.1-.4-.2z"/></svg>';
}

function public_brand(): string {
  return '<span class="brand"><img src="/brand/logo.png" alt="" width="886" height="561"><span class="brand-name">Marketix <i>Ltd</i></span></span>';
}

function plan_span(array $row): string {
  $min = '$' . number_format((int)$row['min']);
  if ($row['max'] === null) return $min . ' – Unlimited';
  return $min . ' – $' . number_format((int)$row['max']);
}

function public_document_start(string $title, array $meta = []): void {
  $robots = $meta['robots'] ?? 'index, follow';
  $desc = $meta['desc'] ?? office_meta_desc();
  $brand = cfg()['name'];
  $origin = cfg()['url'];
  $pageTitle = ($title === $brand || $title === 'Marketix Ltd') ? ($brand . ' — ' . cfg()['tagline']) : ($title . ' · ' . $brand);
  echo '<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0369a1"><meta name="color-scheme" content="light">
<title>' . e($pageTitle) . '</title>
<meta name="description" content="' . e($desc) . '">
<meta name="robots" content="' . e($robots) . '">
<link rel="canonical" href="' . e($origin . path()) . '">
<meta property="og:type" content="website">
<meta property="og:site_name" content="' . e($brand) . '">
<meta property="og:url" content="' . e($origin . path()) . '">
<meta property="og:title" content="' . e($pageTitle) . '">
<meta property="og:description" content="' . e($desc) . '">
<link rel="icon" href="/favicon.png" type="image/png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="' . e(asset_url('/assets/public.css')) . '">
' . jsonld_organization() . '
</head><body>
<a class="skip" href="#content">Skip to content</a>';
}

function public_header(): void {
  $c = cfg();
  $here = path();
  ?>
  <div class="topbar">
    <div class="topbar-in">
      <div class="top-links">
        <a href="tel:<?= e($c['phone_tel']) ?>"><?= icon('phone', 'h-4 w-4') ?><?= e($c['phone']) ?></a>
        <a href="mailto:<?= e($c['support_email']) ?>"><?= icon('mail', 'h-4 w-4') ?><?= e($c['support_email']) ?></a>
        <span><?= icon('clock', 'h-4 w-4') ?>24/7 support</span>
      </div>
      <div class="lang-slot">
        <div id="google_translate_element"></div>
      </div>
    </div>
  </div>
  <header class="sitehead" id="site-header">
    <div class="head-in">
      <a href="/" aria-label="<?= e($c['name']) ?> home"><?= public_brand() ?></a>
      <nav class="nav" aria-label="Primary">
        <?php foreach (public_nav() as [$label, $href]): ?>
          <a href="<?= e($href) ?>"<?= $here === $href ? ' class="on" aria-current="page"' : '' ?>><?= e($label) ?></a>
        <?php endforeach; ?>
      </nav>
      <div class="head-actions">
        <div class="account">
          <button type="button" class="account-btn" id="account-btn" aria-expanded="false" aria-haspopup="true">Account</button>
          <div class="account-menu" id="account-menu">
            <a href="/login/">Log in</a>
            <a href="/register/">Registration</a>
          </div>
        </div>
        <a class="btn-sky" href="/register/">Open account</a>
      </div>
      <button type="button" class="menu-btn" id="menu-btn" aria-expanded="false" aria-label="Menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>
    </div>
    <div class="drawer" id="menu-panel">
      <?php foreach (public_nav() as [$label, $href]): ?>
        <a href="<?= e($href) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
      <div class="drawer-actions">
        <a class="btn-ghost" href="/login/">Log in</a>
        <a class="btn-sky" href="/register/">Registration</a>
      </div>
    </div>
  </header>
  <main id="content">
  <?php
}

function public_banner(string $kicker, string $title, string $lede = ''): void { ?>
  <section class="page-banner">
    <div class="wrap">
      <p class="eyebrow"><i></i><?= e($kicker) ?></p>
      <h1><?= e($title) ?></h1>
      <?php if ($lede !== ''): ?><p><?= e($lede) ?></p><?php endif; ?>
    </div>
  </section>
<?php }

function public_plans(bool $featured = true): void {
  $direct = (int)plan()['direct_pct'];
  ?>
  <div class="cards-4">
    <?php foreach (plan()['plans'] as $row): $hot = $featured && (int)$row['id'] === 2; ?>
      <article class="plan<?= $hot ? ' featured' : '' ?>">
        <?php if ($hot): ?><span class="badge">Popular</span><?php endif; ?>
        <h3><?= e($row['name']) ?></h3>
        <p class="pct"><?= e((string)$row['daily']) ?>%</p>
        <p class="after">Interest after 24 hours</p>
        <ul>
          <li><?= e(plan_span($row)) ?></li>
          <li>Referral income: <?= $direct ?>%</li>
          <li>Withdrawal: manually reviewed, released within 1–2 hours</li>
          <li>24/7 support</li>
        </ul>
        <a class="btn-sky" href="/register/">Open an account</a>
      </article>
    <?php endforeach; ?>
  </div>
  <p class="note">The 24 hours are counted from the time the package is activated. A deposit is USDT on BEP20 and is credited to the fund wallet. You then activate the plan. Amounts between the bands ($501–$599, $5,001–$5,999 and $50,001–$59,999) are not accepted. Withdrawals are from income, minimum $10, with a 10% fee. Principal stays invested.</p>
<?php }

function public_steps(): void { ?>
  <div class="steps">
    <article class="step">
      <div class="n">01</div>
      <h3>Register account</h3>
      <p>Registration is your gateway to a world of investment possibilities. Enjoy a seamless onboarding process, where your information is handled with the utmost security. The sponsor’s name is shown before you submit.</p>
    </article>
    <article class="step">
      <div class="n">02</div>
      <h3>Choose plan</h3>
      <p>Whether you are seeking stable growth, high returns or a balanced approach, Marketix offers a diverse range of plans.</p>
    </article>
    <article class="step">
      <div class="n">03</div>
      <h3>Make investment</h3>
      <p>Choose the plan you believe in, specify your investment amount, and fund it in USDT on BEP20. The plan starts when you activate it from your fund wallet.</p>
    </article>
  </div>
<?php }

function public_why(): void { ?>
  <div class="cards-3">
    <article class="why">
      <div class="ico"><?= icon('shield-check', 'h-6 w-6') ?></div>
      <h3>Anti-DDoS server</h3>
      <p>Our platform is protected against all kinds of DDoS attacks. All data is protected with 256-bit SSL.</p>
    </article>
    <article class="why">
      <div class="ico"><?= icon('trending-up', 'h-6 w-6') ?></div>
      <h3>Investment growth</h3>
      <p>We trade with top forex pairs and cryptocurrency, to help our investors maximize their profit while investing on this platform.</p>
    </article>
    <article class="why">
      <div class="ico"><?= icon('clock', 'h-6 w-6') ?></div>
      <h3>24/7 support</h3>
      <p>Our support staff provides 24/7 service to all our investors. All support requests are answered within a maximum of 24 hours.</p>
    </article>
  </div>
<?php }

function public_footer(): void {
  $c = cfg();
  $here = path();
  ?>
  </main>
  <footer class="site-foot">
    <div class="wrap foot-grid">
      <div>
        <?= public_brand() ?>
        <p>We are an award-winning multinational company. We believe in quality and standard worldwide. Running since <?= e((string)$c['founded']) ?>.</p>
      </div>
      <div>
        <h3>Company</h3>
        <div class="foot-links">
          <?php foreach (public_nav() as [$label, $href]): ?>
            <a href="<?= e($href) ?>"><?= e($label) ?></a>
          <?php endforeach; ?>
          <a href="/login/">Log in</a>
          <a href="/register/">Registration</a>
        </div>
      </div>
      <div>
        <h3>Contact</h3>
        <div class="foot-contact">
          <span><?= icon('map-pin', 'h-4 w-4') ?><span><?= e($c['address_street']) ?>, <?= e($c['address_city']) ?>, <?= e($c['address_region']) ?> <?= e($c['address_postal']) ?>, <?= e($c['address_country']) ?></span></span>
          <a href="mailto:<?= e($c['support_email']) ?>"><?= icon('mail', 'h-4 w-4') ?><?= e($c['support_email']) ?></a>
          <a href="tel:<?= e($c['phone_tel']) ?>"><?= icon('phone', 'h-4 w-4') ?><?= e($c['phone']) ?></a>
          <a href="<?= e($c['telegram']) ?>" target="_blank" rel="noopener"><?= icon('share-2', 'h-4 w-4') ?>Telegram <?= e($c['telegram_handle']) ?></a>
          <a href="<?= e($c['whatsapp']) ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><?= wa_glyph() ?>WhatsApp</a>
        </div>
      </div>
    </div>
    <div class="wrap foot-bottom">
      <span>© <?= (int)$c['founded'] ?>–<?= date('Y') ?> <?= e($c['name']) ?></span>
      <div>
        <a href="/terms/">Terms of Service</a>
        <a href="/privacy/">Privacy Policy</a>
        <button type="button" id="report-open">Report to developer</button>
      </div>
    </div>
  </footer>
  <div class="modal-bg" id="report-modal" role="dialog" aria-modal="true" aria-labelledby="report-title">
    <div class="modal">
      <div class="modal-h">
        <div>
          <p class="kicker-sky">Developer</p>
          <h2 id="report-title">Report to developer</h2>
        </div>
        <button type="button" class="x" data-report-close aria-label="Close">×</button>
      </div>
      <form method="post" action="/report/" class="form-grid" style="margin-top:16px">
        <?= csrf_field() ?>
        <input type="hidden" name="return" value="<?= e($here) ?>">
        <input type="text" name="website" value="" tabindex="-1" autocomplete="off" class="report-hp" aria-hidden="true">
        <p class="help">Use this form to report fraud, a scam, or anything this business has done that customer support has not helped with.</p>
        <div><label class="label" for="report-name">Full name</label><input id="report-name" name="name" class="field" required></div>
        <div><label class="label" for="report-phone">Contact number <span class="help">(optional)</span></label><input id="report-phone" name="phone" class="field" type="tel"></div>
        <div><label class="label" for="report-details">Description</label><textarea id="report-details" name="details" class="field" rows="5" required></textarea></div>
        <button class="btn-sky" type="submit">Send report</button>
      </form>
    </div>
  </div>
  <a class="wa-float" href="<?= e($c['whatsapp']) ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><?= wa_glyph() ?></a>
  <script>
  function googleTranslateElementInit() {
    new google.translate.TranslateElement({ pageLanguage: 'en', autoDisplay: false }, 'google_translate_element');
  }
  </script>
  <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
  <script>
  (function () {
    var head = document.getElementById('site-header');
    var onScroll = function () { if (head) head.classList.toggle('is-stuck', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    var btn = document.getElementById('menu-btn');
    var panel = document.getElementById('menu-panel');
    if (btn && panel) btn.addEventListener('click', function () {
      var open = panel.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    var account = document.querySelector('.account');
    var ab = document.getElementById('account-btn');
    if (account && ab) ab.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = account.classList.toggle('open');
      ab.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('click', function () { if (account) account.classList.remove('open'); });
  })();
  </script>
  <script src="<?= e(asset_url('/assets/app.js')) ?>" defer></script>
  </body></html>
  <?php
}
