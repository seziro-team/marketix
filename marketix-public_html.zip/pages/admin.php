<?php
function page_admin_home(): void {
  $members = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='member'")->fetchColumn();
  $pendingM = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='member' AND status='pending'")->fetchColumn();
  $rejectedM = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='member' AND status='rejected'")->fetchColumn();
  $aum = (int)db()->query("SELECT COALESCE(SUM(principal_cents),0) FROM investments WHERE status IN ('active','capped','matured')")->fetchColumn();
  $pd = db()->query("SELECT d.*, u.name AS member_name FROM deposits d JOIN users u ON u.id=d.user_id WHERE d.status='pending' ORDER BY d.submitted_at DESC")->fetchAll();
  $pw = db()->query("SELECT w.*, u.name AS member_name FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE w.status='pending' ORDER BY w.requested_at DESC")->fetchAll();
  $signups = db()->query("SELECT * FROM users WHERE role='member' AND status='pending' ORDER BY created_at DESC")->fetchAll();
  ?>
  <div class="page-title"><div><h1>Desk overview</h1><p class="muted">Approvals waiting and business written.</p></div></div>
  <div class="tiles">
    <a href="/admin/members/" class="panel tile"><p class="tag">Members</p><div class="v" style="color:var(--brass)"><?= $members ?></div><p class="faint"><?= $pendingM ?> awaiting · <?= $rejectedM ?> rejected</p></a>
    <div class="panel tile"><p class="tag">Under management</p><div class="v"><?= usd(dollars($aum),0) ?></div></div>
    <a href="/admin/deposits/" class="panel tile"><p class="tag">Pending deposits</p><div class="v"><?= count($pd) ?></div></a>
    <a href="/admin/withdrawals/" class="panel tile"><p class="tag">Pending withdrawals</p><div class="v"><?= count($pw) ?></div></a>
  </div>
  <?php if ($signups): ?>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Pending signups</span><a href="/admin/members/" style="color:var(--brass);font-size:.625rem;font-family:var(--font-mono)">MEMBERS</a></div>
    <?php foreach ($signups as $m): ?>
      <div style="display:flex;justify-content:space-between;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
        <span><?= e($m['name']) ?><div class="faint" style="font-family:var(--font-mono);font-size:.625rem"><?= e($m['id']) ?> · <?= e($m['email']) ?></div></span>
        <?= status_pill('pending') ?>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div class="grid-2" style="margin-top:1rem">
    <div class="panel">
      <div class="card-h"><span class="tag">Deposits</span><a href="/admin/deposits/" style="color:var(--brass);font-size:.625rem;font-family:var(--font-mono)">ALL</a></div>
      <?php foreach ($pd as $d): ?>
        <div style="display:flex;justify-content:space-between;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
          <span><?= e($d['member_name']) ?><div class="faint"><?= e($d['id']) ?></div></span>
          <span class="num"><?= usd(dollars((int)$d['amount_cents']),0) ?></span>
        </div>
      <?php endforeach; if (!$pd): ?><p class="muted" style="padding:1.25rem">Queue clear.</p><?php endif; ?>
    </div>
    <div class="panel">
      <div class="card-h"><span class="tag">Withdrawals</span><a href="/admin/withdrawals/" style="color:var(--brass);font-size:.625rem;font-family:var(--font-mono)">ALL</a></div>
      <?php foreach ($pw as $w): ?>
        <div style="display:flex;justify-content:space-between;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
          <span><?= e($w['member_name']) ?><div class="faint"><?= e($w['id']) ?> · <?= e($w['type']) ?></div></span>
          <span class="num"><?= usd(dollars((int)$w['amount_cents']),0) ?></span>
        </div>
      <?php endforeach; if (!$pw): ?><p class="muted" style="padding:1.25rem">Queue clear.</p><?php endif; ?>
    </div>
  </div>
<?php }

function page_admin_deposits(): void {
  if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $id = $_POST['id'] ?? '';
    if (($_POST['do']??'')==='approve') { try { approve_deposit($id); flash("Approved $id."); } catch (Throwable $e) { flash($e->getMessage(),'err'); } }
    if (($_POST['do']??'')==='reject') { db()->prepare("UPDATE deposits SET status='rejected', reviewed_at=?, reject_reason=? WHERE id=? AND status='pending'")->execute([now(), $_POST['reason']??'Rejected', $id]); flash("Rejected $id."); }
    redirect('/admin/deposits/');
  }
  $rows = db()->query("SELECT d.*, u.name AS member_name, u.id AS member_id FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.submitted_at DESC")->fetchAll();
  ?>
  <div class="page-title"><h1>Deposit approvals</h1></div>
  <div class="panel"><table class="ledger">
    <thead><tr><th>Ref</th><th>Member</th><th>Credit</th><th>Hash</th><th>Amount</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $d): ?>
      <tr>
        <td><?= e($d['id']) ?></td>
        <td><?= e($d['member_name']) ?><div class="faint"><?= e($d['member_id']) ?></div></td>
        <td>Fund wallet</td>
        <td style="font-family:var(--font-mono);font-size:.75rem"><a href="https://bscscan.com/tx/<?= e($d['tx_hash']) ?>" target="_blank" rel="noopener" style="color:var(--brass)"><?= e(substr($d['tx_hash'],0,10)) ?>…</a></td>
        <td><?= usd(dollars((int)$d['amount_cents']),0) ?></td>
        <td><?= status_pill($d['status']) ?></td>
        <td>
          <?php if ($d['status']==='pending'): ?>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($d['id']) ?>"><button class="btn-brass" style="height:28px;padding:0 .6rem;font-size:.7rem" name="do" value="approve">Approve</button></form>
            <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($d['id']) ?>"><button class="btn-ghost" style="height:28px;padding:0 .6rem;font-size:.7rem" name="do" value="reject">Reject</button></form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
<?php }

function page_admin_withdrawals(): void {
  if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $id = $_POST['id'] ?? '';
    $st = db()->prepare('SELECT * FROM withdrawals WHERE id=?'); $st->execute([$id]); $w = $st->fetch();
    if ($w && $w['status']==='pending') {
      if (($_POST['do']??'')==='approve') {
        db()->prepare("UPDATE withdrawals SET status='approved', tx_hash=? WHERE id=?")->execute([trim($_POST['tx_hash']??''), $id]);
        flash("Approved $id.");
      } else {
        if ($w['type']==='profit') {
          db()->prepare('UPDATE users SET wallet_cents = wallet_cents + ? WHERE id=?')->execute([$w['amount_cents'], $w['user_id']]);
          write_ledger($w['user_id'], (int)$w['amount_cents'], 'withdrawal_reversal', "Rejected $id", $id);
        } elseif ($w['snapshot']) {
          foreach (json_decode($w['snapshot'], true) ?: [] as $s) {
            db()->prepare("UPDATE investments SET principal_cents=?, status=CASE WHEN kind='flex' THEN 'active' ELSE 'matured' END WHERE id=?")->execute([$s['from'], $s['id']]);
          }
          write_ledger($w['user_id'], (int)$w['amount_cents'], 'principal_reversal', "Rejected $id", $id);
        }
        db()->prepare("UPDATE withdrawals SET status='rejected', reject_reason=? WHERE id=?")->execute([$_POST['reason']??'Rejected', $id]);
        flash("Rejected $id.");
      }
    }
    redirect('/admin/withdrawals/');
  }
  $rows = db()->query("SELECT w.*, u.name AS member_name FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.requested_at DESC")->fetchAll();
  ?>
  <div class="page-title"><h1>Withdrawal approvals</h1></div>
  <?php foreach ($rows as $w): ?>
    <div class="panel" style="padding:1.25rem;margin-bottom:.75rem">
      <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap">
        <div>
          <strong><?= e($w['member_name']) ?></strong> <?= status_pill($w['status']) ?>
          <p class="faint"><?= e($w['id']) ?> · <?= e($w['type']) ?> · <?= e(when_fmt($w['requested_at'])) ?></p>
          <p>Send <span style="color:var(--brass)"><?= usd(dollars((int)$w['net_cents'])) ?></span> after <?= usd(dollars((int)$w['fee_cents'])) ?> fee</p>
          <p class="faint" style="font-family:var(--font-mono);font-size:.75rem"><?= e($w['address']) ?></p>
        </div>
        <?php if ($w['status']==='pending'): ?>
        <div style="min-width:240px">
          <form method="post" style="display:flex;flex-direction:column;gap:.4rem">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= e($w['id']) ?>">
            <input class="field" name="tx_hash" placeholder="0x… payout hash">
            <button class="btn-brass" style="height:36px" name="do" value="approve">Approve</button>
            <button class="btn-ghost" style="height:36px" name="do" value="reject">Reject and refund</button>
          </form>
        </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; if (!$rows): ?><p class="muted">None.</p><?php endif;
}

function page_admin_members(): void {
  if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $id = strtoupper(trim($_POST['id'] ?? ''));
    $do = $_POST['do'] ?? '';
    if ($do==='approve') {
      db()->prepare("UPDATE users SET status='active', approved_at=? WHERE id=? AND role='member'")->execute([now(), $id]);
      flash("Approved $id.");
    }
    if ($do==='reject') {
      db()->prepare("UPDATE users SET status='rejected', approved_at=? WHERE id=? AND role='member' AND status='pending'")->execute([now(), $id]);
      flash("Rejected $id. They stay in the rejected queue — approve or delete later.");
    }
    if ($do==='delete') {
      try { delete_rejected_member($id); flash("Deleted $id."); }
      catch (Throwable $e) { flash($e->getMessage(), 'err'); }
    }
    if ($do==='suspend') {
      $st = db()->prepare('SELECT status FROM users WHERE id=? AND role=\'member\''); $st->execute([$id]);
      $cur = $st->fetchColumn();
      if ($cur === 'suspended') {
        db()->prepare("UPDATE users SET status='active' WHERE id=?")->execute([$id]);
        flash("Reinstated $id.");
      } elseif ($cur === 'active') {
        db()->prepare("UPDATE users SET status='suspended' WHERE id=?")->execute([$id]);
        flash("Suspended $id.");
      }
    }
    if ($do==='save') {
      db()->prepare('UPDATE users SET name=?, email=?, mobile=?, country=?, usdt_address=?, kyc=? WHERE id=?')
        ->execute([$_POST['name']??'', strtolower($_POST['email']??''), $_POST['mobile']??'', $_POST['country']??'', $_POST['usdt_address']??'', $_POST['kyc']??'not_started', $id]);
      if (strlen($_POST['password']??'')>=8) db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($_POST['password'], PASSWORD_DEFAULT), $id]);
      flash('Member updated.');
    }
    if ($do==='promo') {
      credit_wallet($id, cents((float)($_POST['amount']??0)), 'promo', $_POST['note']??'Promotional credit');
      flash('Promotional credit posted.');
    }
    if ($do==='sponsor') {
      $sp = strtoupper(trim($_POST['sponsor']??''));
      if ($sp && $sp !== $id) {
        $place = find_placement($sp, in_array($_POST['leg']??'A',['L','R'],true)?$_POST['leg']:'A');
        db()->prepare('UPDATE users SET sponsor_id=?, placement_parent_id=?, leg=? WHERE id=?')->execute([$sp, $place['parent'], $place['leg'], $id]);
      } else {
        db()->prepare('UPDATE users SET sponsor_id=NULL WHERE id=?')->execute([$id]);
      }
      flash('Placement saved.');
    }
    if ($do==='add') {
      $email = strtolower(trim($_POST['email']??''));
      $name = trim($_POST['name']??'');
      $pw = $_POST['password']??'';
      if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($pw)>=8) {
        $nid = next_id('MTX','member',6);
        $sp = strtoupper(trim($_POST['sponsor']??'')) ?: null;
        $place = $sp ? find_placement($sp, 'A') : null;
        db()->prepare("INSERT INTO users (id,role,email,password_hash,name,country,sponsor_id,placement_parent_id,leg,status,kyc,created_at,approved_at,wallet_cents) VALUES (?,'member',?,?,?,?,?,?,?,'active','not_started',?,?,0)")
          ->execute([$nid,$email,password_hash($pw,PASSWORD_DEFAULT),$name,$_POST['country']??'India',$sp,$place['parent']??null,$place['leg']??null,now(),now()]);
        flash("Created $nid.");
      } else flash('Name, email and 8+ char password required.', 'err');
    }
    redirect('/admin/members/');
  }
  $rows = db()->query("SELECT u.*, COALESCE((SELECT SUM(principal_cents) FROM investments i WHERE i.user_id=u.id AND i.status IN ('active','capped','matured')),0) AS invested_cents,
    COALESCE((SELECT SUM(principal_cents) FROM investments i WHERE i.user_id=u.id AND i.status='active'),0) AS earning_cents,
    (SELECT COUNT(*) FROM users d WHERE d.sponsor_id=u.id) AS directs, s.name AS sponsor_name
    FROM users u LEFT JOIN users s ON s.id=u.sponsor_id WHERE u.role='member' ORDER BY u.created_at DESC")->fetchAll();
  $invs = db()->query("SELECT * FROM investments ORDER BY started_at DESC")->fetchAll();
  $deps = db()->query("SELECT * FROM deposits ORDER BY submitted_at DESC")->fetchAll();
  $wds = db()->query("SELECT * FROM withdrawals ORDER BY requested_at DESC")->fetchAll();
  $earnRows = db()->query("SELECT user_id, kind, COALESCE(SUM(amount_cents),0) AS n FROM ledger
    WHERE amount_cents > 0 AND kind IN ('roi','direct','level','generation','salary','community','fd','promo')
    GROUP BY user_id, kind")->fetchAll();
  $recentRows = db()->query("SELECT id, user_id, at, kind, amount_cents, note FROM ledger ORDER BY at DESC LIMIT 2500")->fetchAll();
  $byInv = []; $byDep = []; $byWd = []; $byEarn = []; $byLed = [];
  foreach ($invs as $i) $byInv[$i['user_id']][] = $i;
  foreach ($deps as $d) $byDep[$d['user_id']][] = $d;
  foreach ($wds as $w) $byWd[$w['user_id']][] = $w;
  foreach ($earnRows as $r) {
    $byEarn[$r['user_id']][$r['kind']] = (int)$r['n'];
    $byEarn[$r['user_id']]['total'] = ($byEarn[$r['user_id']]['total'] ?? 0) + (int)$r['n'];
  }
  foreach ($recentRows as $r) {
    if (count($byLed[$r['user_id']] ?? []) >= 10) continue;
    $byLed[$r['user_id']][] = $r;
  }
  foreach ($rows as &$m) {
    $m['investments'] = $byInv[$m['id']] ?? [];
    $m['deposits'] = $byDep[$m['id']] ?? [];
    $m['withdrawals'] = $byWd[$m['id']] ?? [];
    $m['earnings'] = $byEarn[$m['id']] ?? ['total' => 0];
    $m['recent'] = $byLed[$m['id']] ?? [];
    $m['plan_summary'] = positions_summary($m['investments']);
    unset($m['password_hash'], $m['tx_password_hash']);
  }
  unset($m);
  $pending = array_values(array_filter($rows, fn($m) => $m['status']==='pending'));
  $rejected = array_values(array_filter($rows, fn($m) => $m['status']==='rejected'));
  ?>
  <div class="page-title"><div><h1>Members</h1><p class="muted">Click a row to open the member. Edit from the popup.</p></div>
    <button class="btn-brass" style="height:36px;padding:0 1rem" type="button" onclick="document.getElementById('addm').classList.add('open')">Add member</button>
  </div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Members</p><div class="v"><?= count($rows) ?></div></div>
    <div class="panel tile"><p class="tag">Pending</p><div class="v"><?= count($pending) ?></div></div>
    <div class="panel tile"><p class="tag">Rejected</p><div class="v"><?= count($rejected) ?></div></div>
  </div>
  <?php if ($pending): ?>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Signup queue</span></div>
    <?php foreach ($pending as $m): ?>
      <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
        <span style="flex:1;cursor:pointer" onclick="openMember('<?= e($m['id']) ?>')"><?= e($m['name']) ?><div class="faint"><?= e($m['id']) ?> · <?= e($m['email']) ?></div></span>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($m['id']) ?>"><button class="btn-brass" style="height:32px;padding:0 .8rem;font-size:.7rem" name="do" value="approve">Approve</button></form>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($m['id']) ?>"><button class="btn-ghost" style="height:32px;padding:0 .8rem;font-size:.7rem" name="do" value="reject">Reject</button></form>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <?php if ($rejected): ?>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Rejected registrations</span><span class="faint" style="font-family:var(--font-mono);font-size:.625rem">Approve later, or delete</span></div>
    <?php foreach ($rejected as $m): ?>
      <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
        <span style="flex:1;cursor:pointer" onclick="openMember('<?= e($m['id']) ?>')"><?= e($m['name']) ?><div class="faint"><?= e($m['id']) ?> · <?= e($m['email']) ?></div></span>
        <?= status_pill('rejected') ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($m['id']) ?>"><button class="btn-brass" style="height:32px;padding:0 .8rem;font-size:.7rem" name="do" value="approve">Approve</button></form>
        <form method="post" onsubmit="return confirm('Permanently delete <?= e($m['id']) ?>? This cannot be undone.')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($m['id']) ?>"><button class="btn-ghost" style="height:32px;padding:0 .8rem;font-size:.7rem" name="do" value="delete">Delete</button></form>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Register</span></div>
    <div style="overflow-x:auto">
    <div class="table-wrap"><table class="ledger" style="min-width:720px">
      <thead><tr><th>Member</th><th class="hide-sm">Joined</th><th>Plans</th><th>Allocated</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $m): ?>
        <tr>
          <td class="row-hit" style="cursor:pointer" onclick="openMember('<?= e($m['id']) ?>')"><?= e($m['name']) ?><div class="faint"><?= e($m['id']) ?></div></td>
          <td class="hide-sm"><?= e(substr($m['created_at'],0,10)) ?></td>
          <td class="faint" style="font-size:.75rem"><?= e($m['plan_summary']) ?></td>
          <td><?= usd(dollars((int)$m['invested_cents']),0) ?></td>
          <td style="white-space:nowrap">
            <?= package_pill($m) ?>
            <?php if ($m['status']==='active' || $m['status']==='suspended'): ?>
              <form method="post" style="display:inline-block;margin-left:.5rem;vertical-align:middle">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= e($m['id']) ?>">
                <button type="submit" class="btn-ghost" style="height:28px;padding:0 .75rem;font-size:.7rem" name="do" value="suspend"><?= $m['status']==='suspended' ? 'Reinstate' : 'Suspend' ?></button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    </div>
    <p class="faint" style="padding:.75rem 1.25rem;font-family:var(--font-mono);font-size:.625rem">Click a name to open investments, returns and account detail. Suspend / Reinstate is on the row.</p>
  </div>

  <div class="modal-bg" id="mem">
    <div class="modal wide">
      <div class="modal-h"><div><h2 id="m-title">Member</h2><p class="muted" id="m-sub"></p></div>
        <div style="display:flex;gap:.5rem;align-items:center">
          <button type="button" class="btn-ghost" id="m-edit-btn" style="height:32px;padding:0 .9rem;font-size:.75rem" onclick="showMemberView('edit')">Edit</button>
          <button class="btn-ghost" style="height:32px;width:32px" type="button" onclick="document.getElementById('mem').classList.remove('open')">×</button>
        </div>
      </div>
      <div style="padding:1.25rem" id="m-body"></div>
    </div>
  </div>
  <div class="modal-bg" id="addm">
    <div class="modal">
      <div class="modal-h"><h2>Add a member</h2><button class="btn-ghost" style="height:32px;width:32px" type="button" onclick="document.getElementById('addm').classList.remove('open')">×</button></div>
      <form method="post" style="padding:1.25rem;display:flex;flex-direction:column;gap:.75rem">
        <?= csrf_field() ?><input type="hidden" name="do" value="add">
        <div><label class="label">Name</label><input class="field" name="name" required></div>
        <div><label class="label">Email</label><input class="field" type="email" name="email" required></div>
        <div><label class="label">Country</label><?= country_select('country', 'India') ?></div>
        <div><label class="label">Password</label><input class="field" type="password" name="password" required></div>
        <div><label class="label">Sponsor ID (optional)</label><input class="field" name="sponsor"></div>
        <button class="btn-brass" style="height:44px">Create and approve</button>
      </form>
    </div>
  </div>
  <script>
  const MEMBERS = <?= json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
  const CSRF = <?= json_encode(csrf_token()) ?>;
  const COUNTRIES = <?= json_encode(countries(), JSON_UNESCAPED_UNICODE) ?>;
  const PRODUCTS = <?= json_encode(array_map(fn($p) => $p['name'], plan()['products'])) ?>;
  const KINDS = <?= json_encode([
    'roi' => 'Interest', 'direct' => 'Referral income', 'fd' => 'Interest',
    'plan1' => 'Plan 1', 'plan2' => 'Plan 2', 'plan3' => 'Plan 3', 'plan4' => 'Plan 4',
    'promo' => 'Promotional', 'deposit' => 'Fund wallet', 'activation' => 'Package activation',
    'reinvest' => 'Reinvest', 'topup_out' => 'Top up sent', 'withdrawal' => 'Withdrawal',
    'withdrawal_reversal' => 'Withdrawal reversed',
  ]) ?>;
  let currentMember = null;

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const lab = k => PRODUCTS[k] || KINDS[k] || String(k || '').toUpperCase();
  const usd = (n, d=0) => '$' + (Number(n || 0) / 100).toLocaleString(undefined, {minimumFractionDigits: d, maximumFractionDigits: d});
  const when = iso => String(iso || '').replace('T', ' ').slice(0, 16) || '—';
  const pill = s => {
    const map = {active:['Active','pill-up'], approved:['Approved','pill-up'], pending:['Pending','pill-wait'], rejected:['Rejected','pill-down'], suspended:['Suspended','pill-down'], matured:['Matured','pill-up'], capped:['Capped','pill-wait'], closed:['Closed','pill-idle'], verified:['Verified','pill-up'], inactive:['Inactive','pill-idle']};
    const x = map[String(s || '').toLowerCase()] || [s || '—', 'pill-idle'];
    return `<span class="pill ${x[1]}">${esc(x[0])}</span>`;
  };
  const countryOpts = cur => {
    const list = COUNTRIES.slice();
    if (cur && !list.includes(cur)) list.unshift(cur);
    return '<option value="" disabled>Select country</option>' + list.map(c => `<option value="${esc(c)}" ${c===cur?'selected':''}>${esc(c)}</option>`).join('');
  };
  const table = (headers, rows, empty) => rows.length
    ? `<table class="ledger"><thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`
    : `<p class="faint" style="margin-top:.5rem">${empty}</p>`;

  function openMember(id) {
    currentMember = MEMBERS.find(x => x.id === id) || null;
    if (!currentMember) return;
    document.getElementById('m-title').textContent = currentMember.name;
    document.getElementById('m-sub').textContent = currentMember.id + ' · ' + currentMember.email;
    showMemberView('view');
    document.getElementById('mem').classList.add('open');
  }

  function showMemberView(mode) {
    const m = currentMember;
    if (!m) return;
    const btn = document.getElementById('m-edit-btn');
    if (mode === 'edit') {
      btn.textContent = 'Back';
      btn.onclick = () => showMemberView('view');
      document.getElementById('m-body').innerHTML = editHtml(m);
    } else {
      btn.textContent = 'Edit';
      btn.onclick = () => showMemberView('edit');
      document.getElementById('m-body').innerHTML = viewHtml(m);
    }
  }

  function viewHtml(m) {
    const earn = m.earnings || {};
    const invs = m.investments || [];
    const deps = m.deposits || [];
    const wds = m.withdrawals || [];
    const recent = m.recent || [];
    const kinds = [['roi','Interest'],['direct','Referral'],['promo','Promotional']];
    const statusBar = m.status === 'pending'
      ? `<form method="post" style="display:flex;gap:.5rem;margin-bottom:1rem"><input type="hidden" name="_csrf" value="${CSRF}"><input type="hidden" name="id" value="${esc(m.id)}"><button class="btn-brass" style="height:36px;flex:1" name="do" value="approve">Approve</button><button class="btn-ghost" style="height:36px;flex:1" name="do" value="reject">Reject</button></form>`
      : m.status === 'rejected'
      ? `<form method="post" style="display:flex;gap:.5rem;margin-bottom:1rem"><input type="hidden" name="_csrf" value="${CSRF}"><input type="hidden" name="id" value="${esc(m.id)}"><button class="btn-brass" style="height:36px;flex:1" name="do" value="approve">Approve</button><button class="btn-ghost" style="height:36px;flex:1" name="do" value="delete" onclick="return confirm('Permanently delete ${esc(m.id)}?')">Delete</button></form>`
      : '';
    const facts = [
      ['Joined', when(m.created_at).slice(0,10)],
      ['Country', m.country || '—'],
      ['Mobile', m.mobile || '—'],
      ['KYC', m.kyc === 'verified' ? 'Verified' : (m.kyc === 'submitted' || m.kyc === 'pending' ? 'Submitted' : 'Not started')],
      ['Sponsor', m.sponsor_id ? `${m.sponsor_name || ''} (${m.sponsor_id})` : 'None'],
      ['USDT', m.usdt_address || 'Not set'],
      ['Fund wallet', usd(m.fund_cents || 0, 2)],
      ['Activated', m.activation_at ? when(m.activation_at).slice(0,10) : '—'],
    ];
    const invRows = invs.map(i => `<tr><td>${esc(i.id)}</td><td>${esc(lab(i.kind))}</td><td>${when(i.started_at)}</td><td>${when(i.unlock_at)}</td><td>${usd(i.principal_cents)}</td><td>${pill(i.status)}</td></tr>`);
    const depRows = deps.map(d => `<tr><td>${esc(d.id)}</td><td>${esc(lab(d.product))}</td><td>${when(d.submitted_at)}</td><td>${usd(d.amount_cents)}</td><td>${pill(d.status)}</td></tr>`);
    const wdRows = wds.map(w => `<tr><td>${esc(w.id)}</td><td>${esc(w.type)}</td><td>${when(w.requested_at)}</td><td>−${usd(w.amount_cents)}</td><td>${pill(w.status)}</td></tr>`);
    const recRows = recent.map(r => `<tr><td>${when(r.at)}</td><td>${esc(lab(r.kind))}</td><td class="faint">${esc(r.note||'')}</td><td style="color:${Number(r.amount_cents)<0?'var(--down)':'var(--up)'}">${Number(r.amount_cents)<0?'−':'+'}${usd(Math.abs(Number(r.amount_cents)),2)}</td></tr>`);
    return `
      <div style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin-bottom:1rem">
        ${pill((m.status==='suspended'||m.status==='rejected') ? m.status : (Number(m.invested_cents)>0 ? 'active' : 'inactive'))} ${pill(m.kyc === 'verified' ? 'verified' : m.kyc)}
      </div>
      ${statusBar}
      <div class="tiles" style="grid-template-columns:repeat(2,1fr);margin-bottom:1rem">
        <div class="panel tile"><p class="tag">Invested</p><div class="v">${usd(m.invested_cents)}</div><p class="faint">${esc(m.plan_summary || 'No positions')}</p></div>
        <div class="panel tile"><p class="tag">Wallet (profit)</p><div class="v" style="color:var(--brass)">${usd(m.wallet_cents,2)}</div></div>
        <div class="panel tile"><p class="tag">Total earned</p><div class="v" style="color:var(--up)">${usd(earn.total || 0,2)}</div></div>
        <div class="panel tile"><p class="tag">Directs</p><div class="v">${Number(m.directs||0)}</div></div>
      </div>
      <div class="panel" style="margin-bottom:1rem">
        <div class="card-h"><span class="tag">Account</span></div>
        <dl style="padding:.25rem 0">
          ${facts.map(([k,v]) => `<div style="display:flex;justify-content:space-between;gap:1rem;padding:.55rem 1.25rem;border-top:1px solid var(--line-soft)"><dt class="faint">${esc(k)}</dt><dd style="text-align:right;word-break:break-all">${esc(v)}</dd></div>`).join('')}
        </dl>
      </div>
      <div class="panel" style="margin-bottom:1rem">
        <div class="card-h"><span class="tag">Returns by line</span></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0">
          ${kinds.map(([k,l]) => `<div style="padding:.7rem 1.25rem;border-top:1px solid var(--line-soft)"><p class="tag">${esc(l)}</p><p class="num" style="margin-top:.25rem;color:${Number(earn[k]||0)?'var(--up)':'var(--faint)'}">${usd(earn[k]||0,2)}</p></div>`).join('')}
        </div>
      </div>
      <div class="panel" style="margin-bottom:1rem">
        <div class="card-h"><span class="tag">Positions · investments</span></div>
        ${table(['ID','Plan','Started','Unlocks','Principal','Status'], invRows, 'No funded products yet.')}
      </div>
      <div class="panel" style="margin-bottom:1rem">
        <div class="card-h"><span class="tag">Deposits</span></div>
        ${table(['Ref','Credit','When','Amount','Status'], depRows, 'No deposits submitted.')}
      </div>
      <div class="panel" style="margin-bottom:1rem">
        <div class="card-h"><span class="tag">Withdrawals</span></div>
        ${table(['Ref','Type','When','Amount','Status'], wdRows, 'No withdrawals.')}
      </div>
      <div class="panel">
        <div class="card-h"><span class="tag">Recent ledger</span></div>
        ${table(['When','Type','Detail','Amount'], recRows, 'No movements yet.')}
      </div>`;
  }

  function editHtml(m) {
    return `
      <form method="post" style="display:flex;flex-direction:column;gap:.75rem">
        <input type="hidden" name="_csrf" value="${CSRF}">
        <input type="hidden" name="id" value="${esc(m.id)}">
        <label class="label">Name</label><input class="field" name="name" value="${esc(m.name||'')}">
        <label class="label">Email</label><input class="field" name="email" value="${esc(m.email||'')}">
        <label class="label">Mobile</label><input class="field" name="mobile" value="${esc(m.mobile||'')}">
        <label class="label">Country</label><select class="field" name="country" required>${countryOpts(m.country||'')}</select>
        <label class="label">USDT</label><input class="field" name="usdt_address" value="${esc(m.usdt_address||'')}">
        <label class="label">KYC</label><select class="field" name="kyc">
          <option ${m.kyc==='not_started'?'selected':''} value="not_started">Not started</option>
          <option ${m.kyc==='pending'?'selected':''} value="pending">Pending</option>
          <option ${m.kyc==='verified'?'selected':''} value="verified">Verified</option>
        </select>
        <label class="label">New password (blank = keep)</label><input class="field" type="password" name="password">
        <button class="btn-brass" style="height:40px" name="do" value="save">Save member</button>
      </form>
      <form method="post" style="margin-top:1.25rem;display:flex;flex-direction:column;gap:.5rem">
        <input type="hidden" name="_csrf" value="${CSRF}"><input type="hidden" name="id" value="${esc(m.id)}">
        <p class="tag">Promotional income</p>
        <input class="field" name="amount" type="number" step="0.01" placeholder="Amount">
        <input class="field" name="note" value="Promotional credit">
        <button class="btn-ghost" style="height:40px" name="do" value="promo">Credit wallet</button>
      </form>
      <form method="post" style="margin-top:1.25rem;display:flex;flex-direction:column;gap:.5rem">
        <input type="hidden" name="_csrf" value="${CSRF}"><input type="hidden" name="id" value="${esc(m.id)}">
        <p class="tag">Sponsor</p>
        <input class="field" name="sponsor" value="${esc(m.sponsor_id||'')}" placeholder="MTX-000000">
        <input type="hidden" name="leg" value="A">
        <button class="btn-ghost" style="height:40px" name="do" value="sponsor">Save placement</button>
      </form>`;
  }
  </script>
<?php }

function page_admin_referrals(): void {
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='rate') {
    csrf_check();
    set_setting('direct_pct', (string)(float)$_POST['direct_pct']);
    flash('Direct bonus rate updated.');
    redirect('/admin/referrals/');
  }
  $pct = get_setting('direct_pct','3');
  $edges = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='member' AND sponsor_id IS NOT NULL")->fetchColumn();
  $paid = (int)db()->query("SELECT COALESCE(SUM(amount_cents),0) FROM ledger WHERE kind='direct' AND amount_cents>0")->fetchColumn();
  $sponsors = db()->query("SELECT s.id, s.name, COUNT(d.id) AS directs FROM users s JOIN users d ON d.sponsor_id=s.id WHERE s.role='member' GROUP BY s.id ORDER BY directs DESC")->fetchAll();
  $list = db()->query("SELECT u.id, u.name, u.status, u.leg, u.sponsor_id, s.name AS sponsor_name,
    COALESCE((SELECT SUM(principal_cents) FROM investments i WHERE i.user_id=u.id AND i.status IN ('active','capped','matured')),0) AS invested_cents,
    COALESCE((SELECT SUM(principal_cents) FROM investments i WHERE i.user_id=u.id AND i.status='active'),0) AS earning_cents
    FROM users u JOIN users s ON s.id=u.sponsor_id WHERE u.role='member' ORDER BY u.created_at DESC")->fetchAll();
  ?>
  <div class="page-title"><div><h1>Referrals</h1><p class="muted">Who introduced whom, and the 10% paid when a package is activated.</p></div></div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Links used</p><div class="v"><?= $edges ?></div></div>
    <div class="panel tile"><p class="tag">Direct bonus paid</p><div class="v" style="color:var(--up)"><?= usd(dollars($paid)) ?></div></div>
    <div class="panel tile"><p class="tag">Current rate</p><div class="v"><?= e($pct) ?>%</div></div>
  </div>
  <form method="post" class="panel" style="margin-top:1rem;padding:1.25rem;display:flex;gap:.75rem;align-items:end;flex-wrap:wrap">
    <?= csrf_field() ?><input type="hidden" name="do" value="rate">
    <div><label class="label">Direct referral %</label><input class="field" type="number" step="0.1" name="direct_pct" value="<?= e($pct) ?>" style="width:140px"></div>
    <button class="btn-brass" style="height:44px;padding:0 1.25rem">Update rate</button>
  </form>
  <div class="grid-2" style="margin-top:1rem">
    <div class="panel">
      <div class="card-h"><span class="tag">Sponsors</span></div>
      <table class="ledger"><?php foreach ($sponsors as $s): ?>
        <tr><td><?= e($s['name']) ?><div class="faint"><?= e($s['id']) ?></div></td><td><?= (int)$s['directs'] ?> directs</td></tr>
      <?php endforeach; if (!$sponsors): ?><tr><td class="muted">No downlines yet.</td></tr><?php endif; ?></table>
    </div>
    <div class="panel">
      <div class="card-h"><span class="tag">How it pays</span></div>
      <ol class="muted" style="padding:1.25rem 1.25rem 1.25rem 2.25rem;line-height:1.55">
        <li>Member shares /register/?ref=MTX-…</li>
        <li>Signup stores the sponsor (cookie lasts 30 days) and shows the sponsor’s name.</li>
        <li>When a package is activated or reinvested, <?= e($pct) ?>% is credited to the sponsor’s income wallet.</li>
      </ol>
    </div>
  </div>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Every referral edge</span></div>
    <table class="ledger">
      <thead><tr><th>Member</th><th>Sponsor</th><th>Leg</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($list as $e): ?>
        <tr><td><?= e($e['name']) ?><div class="faint"><?= e($e['id']) ?></div></td><td><?= e($e['sponsor_name']) ?><div class="faint"><?= e($e['sponsor_id']) ?></div></td>
        <td><?= $e['leg']==='L'?'Left':($e['leg']==='R'?'Right':'—') ?></td><td><?= package_pill($e) ?></td></tr>
      <?php endforeach; if (!$list): ?><tr><td colspan="4" class="muted">None yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
<?php }

function page_admin_packages(): void {
  ?>
  <div class="page-title"><h1>Plan & rates</h1></div>
  <p class="muted">Interest is credited every 24 hours from package activation. Referral is 10% of each activated package, paid to the sponsor. Withdrawals take a 10% fee, minimum $10.</p>
  <div class="panel table-wrap" style="margin-top:1rem">
    <table class="ledger">
      <thead><tr><th>Plan</th><th>Range</th><th>Interest</th><th>Referral</th></tr></thead>
      <tbody><?php foreach (plan()['plans'] as $row): ?>
        <tr>
          <td><?= e($row['name']) ?></td>
          <td><?= usd((float)$row['min'], 0) ?> – <?= $row['max'] === null ? 'Unlimited' : usd((float)$row['max'], 0) ?></td>
          <td><?= e((string)$row['daily']) ?>% / 24h</td>
          <td>10%</td>
        </tr>
      <?php endforeach; ?></tbody>
    </table>
  </div>
<?php }

function page_admin_settings(): void {
  if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    foreach (['wallet_address','min_deposit','min_withdraw','profit_fee_pct','direct_pct'] as $k) {
      if (isset($_POST[$k])) set_setting($k, trim($_POST[$k]));
    }
    try {
      if (save_uploaded_wallet_qr()) flash('Wallet address and QR saved. Members see the new QR immediately.');
      else flash('Settings saved.');
    } catch (Throwable $e) {
      flash($e->getMessage(), 'err');
    }
    redirect('/admin/settings/');
  }
  $keys = ['wallet_address'=>'Company USDT BEP20 address','min_deposit'=>'Minimum deposit','min_withdraw'=>'Minimum withdrawal','profit_fee_pct'=>'Withdrawal fee %','direct_pct'=>'Referral %'];
  $qr = wallet_qr_url();
  ?>
  <div class="page-title"><h1>Site settings</h1></div>
  <form method="post" enctype="multipart/form-data" class="panel" style="padding:1.25rem;display:grid;gap:.75rem;max-width:640px">
    <?= csrf_field() ?>
    <?php foreach ($keys as $k=>$lab): ?>
      <div><label class="label"><?= e($lab) ?></label><input class="field" name="<?= e($k) ?>" value="<?= e(get_setting($k)) ?>"></div>
    <?php endforeach; ?>
    <div>
      <label class="label">Company wallet QR</label>
      <p class="faint" style="margin:.35rem 0 .6rem">Upload the QR for the address above. It replaces the generated code on every member dashboard immediately.</p>
      <?php if ($qr): ?>
        <div style="background:#fff;padding:10px;display:inline-block;margin-bottom:.75rem">
          <img src="<?= e($qr) ?>" alt="Current QR" width="140" height="140" style="object-fit:contain;display:block">
        </div>
      <?php endif; ?>
      <input class="field" type="file" name="wallet_qr" accept="image/png,image/jpeg,image/webp,image/gif">
    </div>
    <button class="btn-brass" style="height:44px">Save settings</button>
  </form>
<?php }

function page_admin_positions(): void {
  $invs = db()->query("SELECT i.*, u.name AS member_name, u.email AS member_email
    FROM investments i JOIN users u ON u.id=i.user_id ORDER BY i.started_at DESC")->fetchAll();
  $deps = db()->query("SELECT d.*, u.name AS member_name
    FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.submitted_at DESC")->fetchAll();
  $byKind = [];
  foreach ($invs as $i) {
    if (!in_array($i['status'], ['active','capped','matured'], true)) continue;
    $k = $i['kind'];
    $byKind[$k] = ($byKind[$k] ?? 0) + (int)$i['principal_cents'];
  }
  ?>
  <div class="page-title"><div><h1>Plans & deposits</h1><p class="muted">Every product a member holds, and every deposit they submitted. One member can fund several plans.</p></div></div>
  <div class="tiles">
    <?php foreach (plan()['products'] as $k=>$p): ?>
      <div class="panel tile"><p class="tag"><?= e($p['name']) ?></p><div class="v"><?= usd(dollars($byKind[$k] ?? 0), 0) ?></div></div>
    <?php endforeach; ?>
  </div>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Live positions</span></div>
    <table class="ledger">
      <thead><tr><th>ID</th><th>Member</th><th>Plan</th><th>Started</th><th>Unlocks</th><th>Principal</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($invs as $i): ?>
        <tr>
          <td><?= e($i['id']) ?></td>
          <td><?= e($i['member_name']) ?><div class="faint"><?= e($i['user_id']) ?></div></td>
          <td><?= e(product_label($i['kind'])) ?></td>
          <td><?= e(when_fmt($i['started_at'])) ?></td>
          <td><?= e(when_fmt($i['unlock_at'])) ?></td>
          <td><?= usd(dollars((int)$i['principal_cents'])) ?></td>
          <td><?= status_pill($i['status']) ?></td>
        </tr>
      <?php endforeach; if (!$invs): ?><tr><td colspan="7" class="muted">No positions yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">All deposits</span></div>
    <table class="ledger">
      <thead><tr><th>Ref</th><th>Member</th><th>Plan</th><th>Hash</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($deps as $d): ?>
        <tr>
          <td><?= e($d['id']) ?></td>
          <td><?= e($d['member_name']) ?><div class="faint"><?= e($d['user_id']) ?></div></td>
          <td>Fund wallet</td>
          <td style="font-family:var(--font-mono);font-size:.75rem"><a href="https://bscscan.com/tx/<?= e($d['tx_hash']) ?>" target="_blank" rel="noopener" style="color:var(--brass)"><?= e(substr($d['tx_hash'],0,10)) ?>…</a></td>
          <td><?= usd(dollars((int)$d['amount_cents'])) ?></td>
          <td><?= status_pill($d['status']) ?></td>
        </tr>
      <?php endforeach; if (!$deps): ?><tr><td colspan="6" class="muted">No deposits yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
<?php }

function page_admin_tickets(): void {
  if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $tid = $_POST['ticket_id']??'';
    $body = trim($_POST['body']??'');
    if ($body) {
      db()->prepare("INSERT INTO ticket_messages (id,ticket_id,from_role,body,at) VALUES (?,?, 'desk', ?, ?)")
        ->execute([next_id('MG','message',5), $tid, $body, now()]);
      db()->prepare("UPDATE tickets SET status=?, updated_at=? WHERE id=?")->execute([isset($_POST['close'])?'Closed':'Answered', now(), $tid]);
      flash('Reply sent.');
    }
    redirect('/admin/tickets/');
  }
  $tickets = db()->query("SELECT t.*, u.name AS member_name FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.updated_at DESC")->fetchAll();
  ?>
  <div class="page-title"><h1>Support tickets</h1></div>
  <?php foreach ($tickets as $t):
    $ms = db()->prepare('SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY at'); $ms->execute([$t['id']]); ?>
    <div class="panel" style="padding:1.25rem;margin-bottom:.75rem">
      <div style="display:flex;justify-content:space-between"><strong><?= e($t['subject']) ?></strong><?= status_pill($t['status']) ?></div>
      <p class="faint"><?= e($t['member_name']) ?> · <?= e($t['id']) ?></p>
      <?php foreach ($ms as $m): ?><p class="muted" style="margin-top:.5rem"><span class="tag"><?= $m['from_role']==='desk'?'Desk':'Member' ?></span> <?= e($m['body']) ?></p><?php endforeach; ?>
      <?php if ($t['status']!=='Closed'): ?>
      <form method="post" style="margin-top:1rem;display:flex;flex-direction:column;gap:.5rem">
        <?= csrf_field() ?><input type="hidden" name="ticket_id" value="<?= e($t['id']) ?>">
        <textarea class="field" name="body" rows="3" required></textarea>
        <label class="muted"><input type="checkbox" name="close"> Close ticket</label>
        <button class="btn-brass" style="height:36px;width:120px">Reply</button>
      </form>
      <?php endif; ?>
    </div>
  <?php endforeach; if (!$tickets): ?><p class="muted">No tickets.</p><?php endif;
} ?>
