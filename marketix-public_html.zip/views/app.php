<?php
/** @var array $me */
/** @var string $variant */
/** @var string $content */
/** @var string $title */
$here = path();
if ($variant === 'admin') {
  $pd = (int)db()->query("SELECT COUNT(*) FROM deposits WHERE status='pending'")->fetchColumn();
  $pw = (int)db()->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
  $ps = (int)db()->query("SELECT COUNT(*) FROM users WHERE role='member' AND status IN ('pending','rejected')")->fetchColumn();
  $ot = (int)db()->query("SELECT COUNT(*) FROM tickets WHERE status!='Closed'")->fetchColumn();
  $nav = [
    ['Overview', [['Dashboard','/admin/','gauge',0]]],
    ['Approvals', [['Deposits','/admin/deposits/','arrow-down-to-line',$pd],['Withdrawals','/admin/withdrawals/','arrow-up-from-line',$pw],['Tickets','/admin/tickets/','life-buoy',$ot]]],
    ['Manage', [['Members','/admin/members/','users',$ps],['Plans & deposits','/admin/positions/','layers',0],['Referrals','/admin/referrals/','git-branch',0],['Plan & rates','/admin/packages/','layers',0],['Site settings','/admin/settings/','settings',0]]],
  ];
  $identName = $me['name'];
  $identSub = $me['email'];
  $initialsTxt = 'OP';
  $crumbRoot = 'Admin';
  $await = $pd + $pw + $ps;
  $actions = '<span class="border-line bg-panel/60 flex items-center gap-2 rounded-[2px] border px-3 py-1.5">'.icon('shield-check','text-up h-3.5 w-3.5','1.8').'<span class="num font-mono text-[0.8125rem]">'.$await.' awaiting review</span></span>';
} else {
  $st = db()->prepare("SELECT COUNT(*) FROM tickets WHERE user_id=? AND status!='Closed'");
  $st->execute([$me['id']]);
  $openT = (int)$st->fetchColumn();
  $nav = [
    ['Account', [['Dashboard','/dashboard/','layout-dashboard',0]]],
    ['Wallet', [
      ['Deposit','/dashboard/deposit/','arrow-down-to-line',0],
      ['Fund wallet','/dashboard/wallet/','wallet',0],
      ['Withdraw','/dashboard/withdraw/','arrow-up-from-line',0],
      ['Activate package','/dashboard/packages/','layers',0],
      ['Reinvest','/dashboard/reinvest/','piggy-bank',0],
      ['Top up a member','/dashboard/topup/','users',0],
    ]],
    ['Team', [['Referral list','/dashboard/team/','users',0]]],
    ['Income', [
      ['Income','/dashboard/income/','trending-up',0],
      ['Interest','/dashboard/income/?k=roi','trending-up',0],
      ['Referral','/dashboard/income/?k=direct','trending-up',0],
    ]],
    ['Reports', [['Transactions','/dashboard/transactions/','receipt',0],['Support','/dashboard/support/','life-buoy',$openT]]],
    ['Settings', [['Profile & KYC','/dashboard/profile/','user',0],['Passwords','/dashboard/settings/','settings',0]]],
  ];
  $identName = $me['name'];
  $identSub = $me['id'];
  $initialsTxt = initials($me['name']);
  $crumbRoot = 'Dashboard';
  $wallet = usd(dollars((int)$me['wallet_cents']));
  $actions = '<a href="/dashboard/withdraw/" class="border-line bg-panel/60 hover:border-brass/50 flex max-w-full min-w-0 items-center gap-2 rounded-[2px] border px-2.5 py-1.5 transition-colors sm:px-3">'.icon('wallet','text-brass h-3.5 w-3.5 shrink-0','1.8').'<span class="num min-w-0 truncate font-mono text-[0.75rem] sm:text-[0.8125rem]">'.$wallet.'</span></a>';
}
$flat = [];
foreach ($nav as $g) foreach ($g[1] as $it) $flat[] = $it;
$current = 'Overview';
$qk = $_GET['k'] ?? '';
foreach ($flat as $it) {
  $ip = parse_url($it[1], PHP_URL_PATH) ?: $it[1];
  if (substr($ip, -1) !== '/') $ip .= '/';
  $qs = [];
  parse_str((string)parse_url($it[1], PHP_URL_QUERY), $qs);
  $ik = $qs['k'] ?? '';
  if ($here === $ip && $ik === $qk) $current = $it[0];
}

ob_start(); ?>
<div class="flex h-full flex-col">
  <div class="border-line flex h-[60px] shrink-0 items-center gap-2.5 border-b px-5">
    <a href="/" aria-label="<?= e(cfg()['name']) ?> home"><?= logo() ?></a>
    <?php if ($variant === 'admin'): ?><span class="border-brass/40 text-brass ml-1 rounded-[2px] border px-1.5 py-0.5 font-mono text-[0.5625rem] tracking-[0.14em] uppercase">Admin</span><?php endif; ?>
  </div>
  <nav class="flex-1 overflow-y-auto px-3 py-5">
    <?php foreach ($nav as $g): ?>
      <div class="mb-6 last:mb-0">
        <p class="tag px-2 pb-2.5 text-[0.5625rem]"><?= e($g[0]) ?></p>
        <ul class="flex flex-col gap-0.5">
          <?php foreach ($g[1] as $item):
            $ip = parse_url($item[1], PHP_URL_PATH) ?: $item[1];
            if (substr($ip, -1) !== '/') $ip .= '/';
            $qs = [];
            parse_str((string)parse_url($item[1], PHP_URL_QUERY), $qs);
            $active = $here === $ip && (($qs['k'] ?? '') === $qk);
          ?>
            <li>
              <a href="<?= e($item[1]) ?>" class="group relative flex items-center gap-3 rounded-[2px] px-2.5 py-2 text-[0.875rem] transition-[background-color,color,transform] duration-200 <?= $active ? 'bg-brass/[0.10] text-porcelain' : 'text-muted hover:bg-panel/70 hover:text-porcelain hover:translate-x-0.5' ?>">
                <?php if ($active): ?><span class="bg-brass absolute inset-y-0 left-0 w-[2px]"></span><?php endif; ?>
                <?= icon($item[2], ($active ? 'text-brass' : 'text-faint group-hover:text-muted') . ' h-4 w-4 shrink-0', '1.8') ?>
                <span class="truncate"><?= e($item[0]) ?></span>
                <?php if (!empty($item[3])): ?><span class="bg-brass/15 text-brass ml-auto rounded-full px-1.5 py-0.5 font-mono text-[0.625rem]"><?= (int)$item[3] ?></span><?php endif; ?>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endforeach; ?>
  </nav>
  <div class="border-line shrink-0 border-t p-3">
    <div class="hover:bg-panel/60 flex items-center gap-3 rounded-[2px] px-2.5 py-2 transition-colors">
      <span class="bg-panel-2 border-line text-brass font-display grid h-8 w-8 shrink-0 place-items-center rounded-full border text-[0.6875rem] font-bold"><?= e($initialsTxt) ?></span>
      <span class="min-w-0 flex-1"><span class="block truncate text-[0.8125rem] font-medium"><?= e($identName) ?></span><span class="text-faint block truncate font-mono text-[0.625rem]"><?= e($identSub) ?></span></span>
      <form action="/logout/" method="post"><?= csrf_field() ?><button type="submit" aria-label="Sign out" class="text-faint hover:text-brass transition-colors"><?= icon('log-out','h-4 w-4','1.8') ?></button></form>
    </div>
  </div>
</div>
<?php $sidebar = ob_get_clean();
document_start($title, ['robots'=>'noindex, follow']);
?>
<div class="bg-ground min-h-screen">
  <aside class="border-line bg-ground-2/60 fixed inset-y-0 left-0 z-40 hidden w-[248px] border-r backdrop-blur-sm lg:block"><?= $sidebar ?></aside>
  <div id="app-drawer" class="bfx-drawer">
    <div class="fixed inset-0 z-40 bg-black/70 lg:hidden" data-drawer-bg></div>
    <aside class="border-line bg-ground fixed inset-y-0 left-0 z-50 w-[264px] border-r lg:hidden"><?= $sidebar ?></aside>
  </div>
  <div class="lg:pl-[248px]">
    <header class="border-line bg-ground/85 sticky top-0 z-30 flex min-h-[60px] items-center gap-2 border-b px-3 backdrop-blur-xl sm:gap-4 sm:px-6">
      <button type="button" id="app-menu" class="border-line text-porcelain flex h-9 w-9 shrink-0 items-center justify-center rounded-[2px] border lg:hidden" aria-label="Open menu"><?= icon('menu','h-4 w-4') ?></button>
      <div class="flex min-w-0 flex-1 items-center gap-2">
        <span class="text-faint hidden font-mono text-[0.6875rem] tracking-[0.14em] uppercase sm:inline"><?= e($crumbRoot) ?></span>
        <?= icon('chevron-right','text-faint hidden h-3 w-3 sm:inline') ?>
        <span class="truncate font-mono text-[0.6875rem] tracking-[0.14em] uppercase"><?= e($current) ?></span>
      </div>
      <div class="ml-auto flex min-w-0 max-w-[48%] shrink items-center justify-end"><?= $actions ?></div>
    </header>
    <main class="min-w-0 px-3 py-5 sm:px-6 sm:py-8">
      <div class="mx-auto w-full max-w-[1180px]">
        <?php include __DIR__ . '/flash.php'; ?>
        <?= $content ?>
      </div>
    </main>
  </div>
</div>
<?php document_end();
