<?php
function match6040(float $left, float $right, int $strong = 60, int $weak = 40): array {
  if ($left <= 0 && $right <= 0) return ['matched' => 0, 'leftCarry' => max(0, $left), 'rightCarry' => max(0, $right)];
  $leftIsStrong = $left >= $right;
  $s = $leftIsStrong ? $left : $right;
  $w = $leftIsStrong ? $right : $left;
  if ($w <= 0) return ['matched' => 0, 'leftCarry' => $left, 'rightCarry' => $right];
  $pair = min($s / ($strong / 100), $w / ($weak / 100));
  $sUsed = $pair * ($strong / 100);
  $wUsed = $pair * ($weak / 100);
  $lUsed = $leftIsStrong ? $sUsed : $wUsed;
  $rUsed = $leftIsStrong ? $wUsed : $sUsed;
  return ['matched' => $pair, 'leftCarry' => $left - $lUsed, 'rightCarry' => $right - $rUsed];
}
function invested_cents(string $id): int {
  $st = db()->prepare("SELECT COALESCE(SUM(principal_cents),0) FROM investments WHERE user_id=? AND status IN ('active','capped','matured')");
  $st->execute([$id]);
  return (int)$st->fetchColumn();
}
function has_active_package(string $id): bool {
  $st = db()->prepare("SELECT 1 FROM investments WHERE user_id=? AND status='active' AND principal_cents>0 LIMIT 1");
  $st->execute([$id]);
  return (bool)$st->fetchColumn();
}
function withdrawable_principal(string $id): int {
  $st = db()->prepare("SELECT COALESCE(SUM(principal_cents),0) FROM investments WHERE user_id=? AND (
    (kind='flex' AND status IN ('active','capped','matured'))
    OR (kind='fd' AND status IN ('capped','matured'))
    OR (kind IN ('fd2','fd3','fd4') AND status='matured')
  )");
  $st->execute([$id]);
  return (int)$st->fetchColumn();
}
function paid_roi_cents(string $invId): int {
  $st = db()->prepare("SELECT COALESCE(SUM(amount_cents),0) FROM roi_accruals WHERE investment_id=?");
  $st->execute([$invId]);
  return (int)$st->fetchColumn();
}
function investment_cap_cents(array $inv): int {
  return (int)($inv['cap_cents'] ?? 0);
}
function income_kinds(): array {
  return ['roi', 'direct', 'level', 'generation', 'salary', 'community', 'fd', 'promo'];
}
function earned_on_investment(array $inv): int {
  return (int)($inv['earned_cents'] ?? 0);
}
function remaining_on_investment(array $inv): int {
  $cap = investment_cap_cents($inv);
  if ($cap <= 0) return PHP_INT_MAX;
  return max(0, $cap - earned_on_investment($inv));
}
function active_investments(string $userId): array {
  $st = db()->prepare("SELECT * FROM investments WHERE user_id=? AND status='active' AND principal_cents>0 ORDER BY started_at, id");
  $st->execute([$userId]);
  return $st->fetchAll();
}
function remaining_income_cap(string $userId): int {
  $sum = 0;
  foreach (active_investments($userId) as $inv) {
    $room = remaining_on_investment($inv);
    if ($room === PHP_INT_MAX) return PHP_INT_MAX;
    $sum += $room;
  }
  return $sum;
}
function add_earned(string $invId, int $centsAmt): void {
  if ($centsAmt <= 0) return;
  db()->prepare('UPDATE investments SET earned_cents = earned_cents + ? WHERE id=?')->execute([$centsAmt, $invId]);
  $st = db()->prepare('SELECT * FROM investments WHERE id=?');
  $st->execute([$invId]);
  $inv = $st->fetch();
  if ($inv && remaining_on_investment($inv) <= 0) {
    db()->prepare("UPDATE investments SET status='capped' WHERE id=?")->execute([$invId]);
  }
}
function apply_income(string $user, int $centsAmt, string $kind, string $note, ?string $ref = null, ?string $preferInv = null): int {
  if ($centsAmt <= 0) return 0;
  $u = user_by_id($user);
  if ($u && ($u['role'] ?? '') === 'admin') {
    credit_wallet($user, $centsAmt, $kind, $note, $ref);
    return $centsAmt;
  }
  $invs = active_investments($user);
  if ($preferInv) {
    usort($invs, static function ($a, $b) use ($preferInv) {
      if ($a['id'] === $preferInv) return -1;
      if ($b['id'] === $preferInv) return 1;
      return 0;
    });
  }
  $left = $centsAmt;
  $paid = 0;
  foreach ($invs as $inv) {
    if ($left <= 0) break;
    $room = remaining_on_investment($inv);
    if ($room <= 0) continue;
    $take = $room === PHP_INT_MAX ? $left : min($left, $room);
    add_earned($inv['id'], $take);
    $left -= $take;
    $paid += $take;
  }
  if ($paid > 0) credit_wallet($user, $paid, $kind, $note, $ref);
  return $paid;
}
function highest_package_cents(string $userId): int {
  $st = db()->prepare("SELECT COALESCE(MAX(CASE WHEN package_cents>0 THEN package_cents ELSE principal_cents END),0) FROM investments WHERE user_id=?");
  $st->execute([$userId]);
  $a = (int)$st->fetchColumn();
  $st = db()->prepare("SELECT COALESCE(MAX(amount_cents),0) FROM deposits WHERE user_id=? AND status IN ('approved','pending')");
  $st->execute([$userId]);
  return max($a, (int)$st->fetchColumn());
}
function require_retopup_cents(string $userId, int $centsAmt): array {
  $sub = require_subscription_cents($centsAmt);
  $min = highest_package_cents($userId);
  if ($min > 0 && $centsAmt < $min) {
    throw new RuntimeException('Top up must be the same subscription or a higher one. Minimum now ' . usd(dollars($min), 0) . '.');
  }
  return $sub;
}
function can_accept_referrals(?array $u): bool {
  if (!$u) return false;
  return ($u['status'] ?? '') === 'active';
}
function resolve_sponsor(string $id): array {
  $id = strtoupper(trim($id));
  $u = user_by_id($id);
  if (!$u || ($u['status'] ?? '') !== 'active') {
    throw new RuntimeException('That sponsor ID was not found.');
  }
  return $u;
}
function current_package_label(string $userId): string {
  $st = db()->prepare("SELECT * FROM investments WHERE user_id=? AND status IN ('active','capped','matured') ORDER BY started_at DESC LIMIT 1");
  $st->execute([$userId]);
  $inv = $st->fetch();
  if (!$inv) return 'None';
  $amt = (int)(($inv['package_cents'] ?? 0) ?: $inv['principal_cents']);
  return product_label($inv['kind']) . ' · ' . usd(dollars($amt), 0) . ' · ' . ucfirst((string)$inv['status']);
}
function member_card(array $u): array {
  return [
    'id' => $u['id'],
    'name' => $u['name'],
    'joined' => substr((string)$u['created_at'], 0, 10),
    'active' => has_active_package($u['id']),
    'package' => current_package_label($u['id']),
    'leg' => $u['leg'] ?? '',
  ];
}
function write_ledger(string $user, int $cents, string $kind, string $note, ?string $ref = null): string {
  $id = next_id('LX', 'ledger', 6);
  db()->prepare('INSERT INTO ledger (id, user_id, at, kind, amount_cents, ref_id, note) VALUES (?,?,?,?,?,?,?)')
    ->execute([$id, $user, now(), $kind, $cents, $ref, $note]);
  return $id;
}
function credit_wallet(string $user, int $cents, string $kind, string $note, ?string $ref = null): void {
  if ($cents === 0) return;
  db()->prepare('UPDATE users SET wallet_cents = wallet_cents + ? WHERE id = ?')->execute([$cents, $user]);
  write_ledger($user, $cents, $kind, $note, $ref);
}
function descendants(string $root): array {
  $out = [];
  $stack = [$root];
  $seen = [$root => true];
  $st = db()->prepare('SELECT id FROM users WHERE placement_parent_id = ?');
  while ($stack) {
    $id = array_pop($stack);
    $st->execute([$id]);
    foreach ($st->fetchAll() as $k) {
      if (isset($seen[$k['id']])) continue;
      $seen[$k['id']] = true;
      $out[] = $k['id'];
      $stack[] = $k['id'];
    }
  }
  return $out;
}
function downline_ids(string $root, ?string $side = null): array {
  if ($side) {
    $st = db()->prepare('SELECT id FROM users WHERE placement_parent_id = ? AND leg = ?');
    $st->execute([$root, $side]);
    $child = $st->fetchColumn();
    if (!$child) return [];
    return array_merge([$child], descendants($child));
  }
  return descendants($root);
}
function team_principal(array $ids): int {
  if (!$ids) return 0;
  $ph = implode(',', array_fill(0, count($ids), '?'));
  $st = db()->prepare("SELECT COALESCE(SUM(principal_cents),0) FROM investments WHERE status IN ('active','capped','matured') AND user_id IN ($ph)");
  $st->execute($ids);
  return (int)$st->fetchColumn();
}
function find_placement(string $sponsorId, string $preferred = 'A'): array {
  $left = team_principal(downline_ids($sponsorId, 'L'));
  $right = team_principal(downline_ids($sponsorId, 'R'));
  $side = $preferred === 'A' ? ($left <= $right ? 'L' : 'R') : $preferred;
  $st = db()->prepare('SELECT id FROM users WHERE placement_parent_id = ? AND leg = ?');
  $st->execute([$sponsorId, $side]);
  $existing = $st->fetchColumn();
  if (!$existing) return ['parent' => $sponsorId, 'leg' => $side];
  $q = [$existing];
  $kids = db()->prepare('SELECT id, leg FROM users WHERE placement_parent_id = ?');
  while ($q) {
    $id = array_shift($q);
    $kids->execute([$id]);
    $got = $kids->fetchAll();
    $L = null; $R = null;
    foreach ($got as $g) { if ($g['leg'] === 'L') $L = $g['id']; if ($g['leg'] === 'R') $R = $g['id']; }
    if (!$L) return ['parent' => $id, 'leg' => 'L'];
    if (!$R) return ['parent' => $id, 'leg' => 'R'];
    $q[] = $L; $q[] = $R;
  }
  return ['parent' => $sponsorId, 'leg' => $side];
}
function active_direct_count(string $sponsorId): int {
  $st = db()->prepare("SELECT id FROM users WHERE sponsor_id=? AND role='member' AND status='active'");
  $st->execute([$sponsorId]);
  $n = 0;
  foreach ($st as $row) {
    if (has_active_package($row['id'])) $n++;
  }
  return $n;
}
function create_investment(string $userId, string $product, int $centsAmt): string {
  $row = plan_for_cents($centsAmt);
  if (!$row) throw new RuntimeException('That amount is not inside a published plan. ' . plan_bands_text());
  $inv = next_id('IN', 'investment', 4);
  $kind = 'plan' . (int)$row['id'];
  db()->prepare("INSERT INTO investments (id, user_id, kind, principal_cents, started_at, unlock_at, status, multiplier, cap_cents, earned_cents, package_cents, daily_pct, periods_paid) VALUES (?,?,?,?,?,NULL,'active',1,0,0,?,?,0)")
    ->execute([$inv, $userId, $kind, $centsAmt, now(), $centsAmt, (float)$row['daily']]);
  return $inv;
}
function credit_fund(string $user, int $centsAmt, string $note, ?string $ref = null): void {
  if ($centsAmt === 0) return;
  db()->prepare('UPDATE users SET fund_cents = fund_cents + ? WHERE id = ?')->execute([$centsAmt, $user]);
  write_ledger($user, $centsAmt, 'fund', $note, $ref);
}
function pay_referral(array $user, int $centsAmt, string $ref): void {
  if (empty($user['sponsor_id'])) return;
  $sp = user_by_id((string)$user['sponsor_id']);
  if (!$sp || ($sp['status'] ?? '') !== 'active') return;
  $pct = (float)get_setting('direct_pct', (string)plan()['direct_pct']);
  $bonus = (int) round($centsAmt * ($pct / 100));
  if ($bonus <= 0) return;
  credit_wallet($sp['id'], $bonus, 'direct', 'Referral ' . rtrim(rtrim(number_format($pct, 2, '.', ''), '0'), '.') . '% on ' . $user['name'], $ref);
}
function activate_package(string $userId, int $centsAmt): string {
  $u = user_by_id($userId);
  if (!$u || $u['status'] !== 'active') throw new RuntimeException('Account must be active.');
  if (!plan_for_cents($centsAmt)) throw new RuntimeException('That amount is not inside a published plan. ' . plan_bands_text());
  if ((int)$u['fund_cents'] < $centsAmt) throw new RuntimeException('Not enough in the fund wallet. Deposit USDT (BEP20) first.');
  db()->prepare('UPDATE users SET fund_cents = fund_cents - ? WHERE id = ?')->execute([$centsAmt, $userId]);
  $row = plan_for_cents($centsAmt);
  write_ledger($userId, -$centsAmt, 'activation', 'Activated ' . $row['name'] . ' · ' . usd(dollars($centsAmt), 0));
  $inv = create_investment($userId, 'plan', $centsAmt);
  if (empty($u['activation_at'])) {
    db()->prepare('UPDATE users SET activation_at = ? WHERE id = ?')->execute([now(), $userId]);
  }
  pay_referral($u, $centsAmt, $inv);
  return $inv;
}
function transfer_fund(array $from, string $toId, int $centsAmt): void {
  $toId = strtoupper(trim($toId));
  $to = user_by_id($toId);
  if (!$to || $to['role'] !== 'member') throw new RuntimeException('That member ID was not found.');
  if ($to['id'] === $from['id']) throw new RuntimeException('You cannot top up your own ID from this form. Use Activate package.');
  if ($to['status'] !== 'active') throw new RuntimeException('That member cannot receive a top up.');
  if ($centsAmt < 100) throw new RuntimeException('Minimum top up is $1.');
  if ((int)$from['fund_cents'] < $centsAmt) throw new RuntimeException('Not enough in your fund wallet.');
  db()->prepare('UPDATE users SET fund_cents = fund_cents - ? WHERE id = ?')->execute([$centsAmt, $from['id']]);
  write_ledger($from['id'], -$centsAmt, 'topup_out', 'Top up sent to ' . $to['name'] . ' (' . $to['id'] . ')');
  credit_fund($to['id'], $centsAmt, 'Top up from ' . $from['name'] . ' (' . $from['id'] . ')');
}
function level_rate(float $matchedTeam, int $directs): array {
  $lvl = 0;
  $rate = 0.0;
  foreach (plan()['levels'] as $s) {
    if ($matchedTeam >= (float)$s[1] && $directs >= (int)$s[3]) {
      $lvl = (int)$s[0];
      $rate = (float)$s[2];
    }
  }
  return [$lvl, $rate];
}

function team_active_count(array $ids): int {
  if (!$ids) return 0;
  $ph = implode(',', array_fill(0, count($ids), '?'));
  $st = db()->prepare("SELECT COUNT(DISTINCT user_id) FROM investments WHERE status='active' AND user_id IN ($ph)");
  $st->execute($ids);
  return (int)$st->fetchColumn();
}
function qualify_booster(array $user): bool {
  if ((int)$user['booster_qualified']) return true;
  if (empty($user['activation_at'])) return false;
  $windowDays = (int)get_setting('booster_window_days', (string)plan()['booster_days']);
  $needed = (int)get_setting('booster_directs', (string)plan()['booster_directs']);
  $end = gmdate('c', strtotime($user['activation_at'] . " +{$windowDays} days"));
  if (time() > strtotime($end)) return false;
  $mine = invested_cents($user['id']);
  $st = db()->prepare("SELECT id FROM users WHERE sponsor_id=? AND status='active' AND created_at<=?");
  $st->execute([$user['id'], $end]);
  $n = 0;
  foreach ($st as $d) {
    $their = invested_cents($d['id']);
    if ($their > 0 && $their >= $mine) $n++;
  }
  if ($n >= $needed) {
    db()->prepare('UPDATE users SET booster_qualified=1 WHERE id=?')->execute([$user['id']]);
    return true;
  }
  return false;
}
function delete_rejected_member(string $id): void {
  $u = user_by_id($id);
  if (!$u || $u['role'] !== 'member') throw new RuntimeException('Member not found.');
  if ($u['status'] !== 'rejected') throw new RuntimeException('Only rejected registrations can be deleted.');
  $db = db();
  $db->beginTransaction();
  foreach (['deposits', 'investments', 'ledger', 'withdrawals', 'roi_accruals', 'carry', 'salary_awards', 'community_awards', 'sessions'] as $t) {
    $db->prepare("DELETE FROM $t WHERE user_id=?")->execute([$id]);
  }
  $tids = $db->prepare('SELECT id FROM tickets WHERE user_id=?');
  $tids->execute([$id]);
  foreach ($tids as $t) {
    $db->prepare('DELETE FROM ticket_messages WHERE ticket_id=?')->execute([$t['id']]);
  }
  $db->prepare('DELETE FROM tickets WHERE user_id=?')->execute([$id]);
  $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
  $db->commit();
}
function approve_deposit(string $depId): void {
  $st = db()->prepare('SELECT * FROM deposits WHERE id = ?');
  $st->execute([$depId]);
  $d = $st->fetch();
  if (!$d || $d['status'] !== 'pending') throw new RuntimeException('Deposit is not pending.');
  credit_fund($d['user_id'], (int)$d['amount_cents'], 'Deposit approved · ' . usd(dollars((int)$d['amount_cents']), 0), $d['id']);
  db()->prepare("UPDATE deposits SET status='approved', reviewed_at=? WHERE id=?")->execute([now(), $d['id']]);
}
function user_by_id(string $id): ?array {
  $st = db()->prepare('SELECT * FROM users WHERE id = ?');
  $st->execute([$id]);
  return $st->fetch() ?: null;
}
function reduce_principal(string $user, int $cents): array {
  $st = db()->prepare("SELECT * FROM investments WHERE user_id=? AND (
    (kind='flex' AND status IN ('active','capped','matured'))
    OR (kind='fd' AND status IN ('capped','matured'))
    OR (kind IN ('fd2','fd3','fd4') AND status='matured')
  ) ORDER BY started_at");
  $st->execute([$user]);
  $taken = [];
  $left = $cents;
  foreach ($st as $inv) {
    if ($left <= 0) break;
    $take = min((int)$inv['principal_cents'], $left);
    $rem = (int)$inv['principal_cents'] - $take;
    if ($rem === 0) db()->prepare("UPDATE investments SET principal_cents=0, status='closed' WHERE id=?")->execute([$inv['id']]);
    else db()->prepare('UPDATE investments SET principal_cents=? WHERE id=?')->execute([$rem, $inv['id']]);
    $taken[] = ['id' => $inv['id'], 'from' => (int)$inv['principal_cents'], 'kind' => $inv['kind']];
    $left -= $take;
  }
  if ($left > 0) throw new RuntimeException('Not enough unlocked principal.');
  return $taken;
}
function request_reinvest(array $user, float $amount, string $product = 'plan'): string {
  $centsAmt = cents($amount);
  $row = plan_for_cents($centsAmt);
  if (!$row) throw new RuntimeException('That amount is not inside a published plan. ' . plan_bands_text());
  if ($user['status'] !== 'active') throw new RuntimeException('Account must be active.');
  if ((int)$user['wallet_cents'] < $centsAmt) throw new RuntimeException('Not enough available income to reinvest.');
  db()->prepare('UPDATE users SET wallet_cents = wallet_cents - ? WHERE id = ?')->execute([$centsAmt, $user['id']]);
  $inv = create_investment($user['id'], 'plan', $centsAmt);
  write_ledger($user['id'], -$centsAmt, 'reinvest', 'Reinvested into ' . $row['name'] . ' · ' . usd(dollars($centsAmt), 0), $inv);
  $fresh = user_by_id($user['id']);
  if ($fresh && empty($fresh['activation_at'])) {
    db()->prepare('UPDATE users SET activation_at = ? WHERE id = ?')->execute([now(), $user['id']]);
  }
  if ($fresh) pay_referral($fresh, $centsAmt, $inv);
  return $inv;
}
function request_withdrawal(array $user, float $amount, string $type = 'profit'): string {
  $min = (float)get_setting('min_withdraw', '10');
  $centsAmt = cents($amount);
  if ($centsAmt < cents($min)) throw new RuntimeException('Minimum withdrawal is $' . rtrim(rtrim(number_format($min, 2, '.', ''), '0'), '.') . '.');
  if (!preg_match('/^0x[a-fA-F0-9]{40}$/', $user['usdt_address'] ?? '')) throw new RuntimeException('Save a valid USDT BEP20 address before you withdraw.');
  if ($user['status'] !== 'active') throw new RuntimeException('Account must be active.');
  if ((int)$user['wallet_cents'] < $centsAmt) throw new RuntimeException('Not enough available income.');
  $feePct = (float)get_setting('profit_fee_pct', (string)plan()['withdraw_fee']);
  $fee = (int) round($centsAmt * ($feePct / 100));
  $id = next_id('WD', 'withdraw', 4);
  db()->prepare('UPDATE users SET wallet_cents = wallet_cents - ? WHERE id = ?')->execute([$centsAmt, $user['id']]);
  write_ledger($user['id'], -$centsAmt, 'withdrawal', "Withdrawal $id", $id);
  db()->prepare("INSERT INTO withdrawals (id,user_id,amount_cents,type,fee_cents,net_cents,address,status,requested_at,snapshot) VALUES (?,?,?,?,?,?,?,'pending',?,NULL)")
    ->execute([$id, $user['id'], $centsAmt, 'profit', $fee, $centsAmt - $fee, $user['usdt_address'], now()]);
  return $id;
}

function run_daily(?string $date = null): array {
  $date = $date ?: today();
  $sum = ['date' => $date, 'skipped' => false, 'roi' => 0, 'level' => 0, 'salary' => 0, 'community' => 0, 'fd' => 0, 'boosters' => 0, 'periods' => 0];
  $db = db();
  $open = $db->query("SELECT * FROM investments WHERE status='active' AND principal_cents>0")->fetchAll();
  $ins = $db->prepare('INSERT OR IGNORE INTO roi_accruals (investment_id, date, user_id, rate_bps, amount_cents, boosted) VALUES (?,?,?,?,?,0)');
  foreach ($open as $inv) {
    $start = strtotime((string)$inv['started_at']);
    if (!$start) continue;
    $due = intdiv(time() - $start, 86400);
    $paidN = (int)($inv['periods_paid'] ?? 0);
    if ($due <= $paidN) continue;
    $pct = (float)($inv['daily_pct'] ?? 0);
    if ($pct <= 0) {
      $row = plan_for_cents((int)$inv['principal_cents']);
      $pct = $row ? (float)$row['daily'] : 0;
    }
    if ($pct <= 0) continue;
    $n = min($due - $paidN, 60);
    $credited = 0;
    for ($i = 1; $i <= $n; $i++) {
      $periodDate = gmdate('Y-m-d', $start + ($paidN + $i) * 86400);
      $amt = (int) round(((int)$inv['principal_cents']) * ($pct / 100));
      if ($amt <= 0) continue;
      $ins->execute([$inv['id'], $periodDate, $inv['user_id'], (int) round($pct * 100), $amt]);
      if ($ins->rowCount() === 0) continue;
      $sum['roi'] += apply_income($inv['user_id'], $amt, 'roi', 'Interest ' . rtrim(rtrim(number_format($pct, 2, '.', ''), '0'), '.') . '% · 24h', $inv['id'], $inv['id']);
      $credited++;
    }
    if ($credited > 0) {
      $db->prepare('UPDATE investments SET periods_paid = periods_paid + ? WHERE id=?')->execute([$credited, $inv['id']]);
      $sum['periods'] += $credited;
    }
  }
  return $sum;
}
function today_roi(string $date, array $ids): int {
  if (!$ids) return 0;
  $ph = implode(',', array_fill(0, count($ids), '?'));
  $st = db()->prepare("SELECT COALESCE(SUM(amount_cents),0) FROM roi_accruals WHERE date=? AND user_id IN ($ph)");
  $st->execute(array_merge([$date], $ids));
  return (int)$st->fetchColumn();
}
