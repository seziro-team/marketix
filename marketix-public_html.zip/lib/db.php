<?php
function db(): PDO {
  static $pdo;
  if ($pdo) return $pdo;
  $dir = dirname(__DIR__) . '/data';
  if (!is_dir($dir)) mkdir($dir, 0770, true);
  $file = $dir . '/marketix.db';
  $pdo = new PDO('sqlite:' . $file, null, null, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  $pdo->exec('PRAGMA journal_mode = WAL');
  $pdo->exec('PRAGMA busy_timeout = 5000');
  $pdo->exec('PRAGMA foreign_keys = ON');
  migrate($pdo);
  return $pdo;
}

function migrate(PDO $db): void {
  $db->exec("
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, role TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, name TEXT NOT NULL, mobile TEXT DEFAULT '',
      country TEXT DEFAULT '', city TEXT DEFAULT '', usdt_address TEXT DEFAULT '',
      sponsor_id TEXT, placement_parent_id TEXT, leg TEXT,
      status TEXT NOT NULL, kyc TEXT NOT NULL DEFAULT 'not_started',
      created_at TEXT NOT NULL, approved_at TEXT, activation_at TEXT,
      booster_qualified INTEGER NOT NULL DEFAULT 0, wallet_cents INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS investments (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, kind TEXT NOT NULL,
      principal_cents INTEGER NOT NULL, started_at TEXT NOT NULL, unlock_at TEXT,
      status TEXT NOT NULL, multiplier REAL NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS deposits (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, amount_cents INTEGER NOT NULL,
      tx_hash TEXT NOT NULL, note TEXT DEFAULT '', product TEXT NOT NULL,
      status TEXT NOT NULL, submitted_at TEXT NOT NULL, reviewed_at TEXT, reject_reason TEXT
    );
    CREATE TABLE IF NOT EXISTS withdrawals (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, amount_cents INTEGER NOT NULL,
      type TEXT NOT NULL, fee_cents INTEGER NOT NULL, net_cents INTEGER NOT NULL,
      address TEXT NOT NULL, tx_hash TEXT, status TEXT NOT NULL,
      requested_at TEXT NOT NULL, reject_reason TEXT, snapshot TEXT
    );
    CREATE TABLE IF NOT EXISTS ledger (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, at TEXT NOT NULL, kind TEXT NOT NULL,
      amount_cents INTEGER NOT NULL, ref_id TEXT, note TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS roi_accruals (
      investment_id TEXT NOT NULL, date TEXT NOT NULL, user_id TEXT NOT NULL,
      rate_bps INTEGER NOT NULL, amount_cents INTEGER NOT NULL, boosted INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (investment_id, date)
    );
    CREATE TABLE IF NOT EXISTS carry (
      user_id TEXT PRIMARY KEY, left_cents INTEGER NOT NULL DEFAULT 0, right_cents INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS salary_awards (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, level INTEGER NOT NULL,
      weekly_cents INTEGER NOT NULL, weeks_total INTEGER NOT NULL DEFAULT 24,
      weeks_paid INTEGER NOT NULL DEFAULT 0, last_paid_date TEXT, UNIQUE(user_id, level)
    );
    CREATE TABLE IF NOT EXISTS community_awards (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, level INTEGER NOT NULL,
      amount_cents INTEGER NOT NULL, awarded_at TEXT NOT NULL, UNIQUE(user_id, level)
    );
    CREATE TABLE IF NOT EXISTS tickets (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, subject TEXT NOT NULL,
      category TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ticket_messages (
      id TEXT PRIMARY KEY, ticket_id TEXT NOT NULL, from_role TEXT NOT NULL, body TEXT NOT NULL, at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS counters (key TEXT PRIMARY KEY, value INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS otps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      purpose TEXT NOT NULL,
      code_hash TEXT NOT NULL,
      payload TEXT,
      expires_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT, email TEXT, message TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS reports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      details TEXT NOT NULL,
      ip TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_users_sponsor ON users(sponsor_id);
    CREATE INDEX IF NOT EXISTS idx_users_place ON users(placement_parent_id);
    CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger(user_id);
  ");
  $defaults = [
    'wallet_address' => cfg()['wallet_address'],
    'min_deposit' => (string)cfg()['min_deposit'],
    'direct_pct' => (string)plan()['direct_pct'],
    'roi_daily_pct' => (string)plan()['roi'],
    'booster_daily_pct' => (string)plan()['booster'],
    'booster_directs' => (string)plan()['booster_directs'],
    'booster_window_days' => (string)plan()['booster_days'],
    'min_withdraw' => (string)plan()['min_withdraw'],
    'profit_fee_pct' => (string)plan()['withdraw_fee'],
    'principal_fee_pct' => (string)plan()['withdraw_fee'],
    'cron_key' => cfg()['cron_key'],
  ];
  $ins = $db->prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  foreach ($defaults as $k => $v) $ins->execute([$k, $v]);
  foreach (['member' => 100000, 'deposit' => 1000, 'withdraw' => 1000, 'ticket' => 4000, 'ledger' => 10000, 'investment' => 1000, 'message' => 1, 'salary' => 1, 'community' => 1] as $k => $v) {
    $db->prepare('INSERT OR IGNORE INTO counters (key, value) VALUES (?, ?)')->execute([$k, $v]);
  }
  $n = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();
  if ($n === 0) seed($db);
  $db->exec("UPDATE users SET status='active', approved_at=COALESCE(approved_at, created_at) WHERE role='member' AND status='pending'");
  $cols = $db->query("PRAGMA table_info(users)")->fetchAll();
  $names = array_map(fn($c) => (string)$c['name'], $cols);
  if (!in_array('reinvest', $names, true)) {
    $db->exec("ALTER TABLE users ADD COLUMN reinvest INTEGER NOT NULL DEFAULT 0");
  }
  $invCols = $db->query("PRAGMA table_info(investments)")->fetchAll();
  $invNames = array_map(fn($c) => (string)$c['name'], $invCols);
  if (!in_array('cap_cents', $invNames, true)) {
    $db->exec("ALTER TABLE investments ADD COLUMN cap_cents INTEGER NOT NULL DEFAULT 0");
  }
  if (!in_array('earned_cents', $invNames, true)) {
    $db->exec("ALTER TABLE investments ADD COLUMN earned_cents INTEGER NOT NULL DEFAULT 0");
    $db->exec("UPDATE investments SET earned_cents = COALESCE((SELECT SUM(amount_cents) FROM roi_accruals WHERE roi_accruals.investment_id = investments.id), 0)");
  }
  if (!in_array('package_cents', $invNames, true)) {
    $db->exec("ALTER TABLE investments ADD COLUMN package_cents INTEGER NOT NULL DEFAULT 0");
    $db->exec("UPDATE investments SET package_cents = principal_cents WHERE package_cents = 0");
  }
  if (get_setting('fresh_start_20260830', '') !== '1') {
    wipe_member_data($db);
    set_setting('fresh_start_20260830', '1');
  }
  if (get_setting('fresh_start_20260903', '') !== '1') {
    wipe_member_data($db);
    set_setting('fresh_start_20260903', '1');
  }
  if (get_setting('plan_patch_20260908', '') !== '1') {
    set_setting('profit_fee_pct', '0');
    set_setting('booster_window_days', '30');
    set_setting('plan_patch_20260908', '1');
  }
  $cols = $db->query("PRAGMA table_info(users)")->fetchAll();
  $names = array_map(fn($c) => (string)$c['name'], $cols);
  if (!in_array('fund_cents', $names, true)) {
    $db->exec("ALTER TABLE users ADD COLUMN fund_cents INTEGER NOT NULL DEFAULT 0");
  }
  if (!in_array('tx_password_hash', $names, true)) {
    $db->exec("ALTER TABLE users ADD COLUMN tx_password_hash TEXT NOT NULL DEFAULT ''");
  }
  if (!in_array('kyc_front', $names, true)) {
    $db->exec("ALTER TABLE users ADD COLUMN kyc_front TEXT NOT NULL DEFAULT ''");
  }
  if (!in_array('kyc_back', $names, true)) {
    $db->exec("ALTER TABLE users ADD COLUMN kyc_back TEXT NOT NULL DEFAULT ''");
  }
  $invCols = $db->query("PRAGMA table_info(investments)")->fetchAll();
  $invNames = array_map(fn($c) => (string)$c['name'], $invCols);
  if (!in_array('daily_pct', $invNames, true)) {
    $db->exec("ALTER TABLE investments ADD COLUMN daily_pct REAL NOT NULL DEFAULT 0");
  }
  if (!in_array('periods_paid', $invNames, true)) {
    $db->exec("ALTER TABLE investments ADD COLUMN periods_paid INTEGER NOT NULL DEFAULT 0");
  }
  if (get_setting('plan_marketix_202611', '') !== '1') {
    set_setting('profit_fee_pct', (string)plan()['withdraw_fee']);
    set_setting('principal_fee_pct', (string)plan()['withdraw_fee']);
    set_setting('direct_pct', (string)plan()['direct_pct']);
    set_setting('min_withdraw', (string)plan()['min_withdraw']);
    set_setting('min_deposit', (string)cfg()['min_deposit']);
    set_setting('wallet_address', cfg()['wallet_address']);
    set_setting('plan_marketix_202611', '1');
  }
}

function wipe_member_data(PDO $db): void {
  $ids = $db->query("SELECT id FROM users WHERE role='member'")->fetchAll(PDO::FETCH_COLUMN);
  foreach ($ids as $id) {
    foreach (['deposits', 'investments', 'ledger', 'withdrawals', 'roi_accruals', 'carry', 'salary_awards', 'community_awards', 'sessions'] as $t) {
      $db->prepare("DELETE FROM {$t} WHERE user_id=?")->execute([$id]);
    }
    $tids = $db->prepare('SELECT id FROM tickets WHERE user_id=?');
    $tids->execute([$id]);
    foreach ($tids as $t) {
      $db->prepare('DELETE FROM ticket_messages WHERE ticket_id=?')->execute([$t['id']]);
    }
    $db->prepare('DELETE FROM tickets WHERE user_id=?')->execute([$id]);
    $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
  }
  $db->exec('DELETE FROM otps');
  $db->exec('DELETE FROM enquiries');
  $db->exec('DELETE FROM reports');
  $db->exec("DELETE FROM settings WHERE key LIKE 'daily_run_%'");
  $keep = $db->query("SELECT id FROM users")->fetchAll(PDO::FETCH_COLUMN);
  $keep[] = '';
  $ph = implode(',', array_fill(0, count($keep), '?'));
  foreach (['deposits', 'investments', 'ledger', 'withdrawals', 'roi_accruals', 'carry', 'salary_awards', 'community_awards', 'sessions', 'tickets'] as $t) {
    $db->prepare("DELETE FROM {$t} WHERE user_id NOT IN ($ph)")->execute($keep);
  }
  $db->exec('DELETE FROM ticket_messages WHERE ticket_id NOT IN (SELECT id FROM tickets)');

  foreach (['member' => 100000, 'deposit' => 1000, 'withdraw' => 1000, 'ticket' => 4000, 'ledger' => 10000, 'investment' => 1000, 'message' => 1, 'salary' => 1, 'community' => 1] as $k => $v) {
    $db->prepare('UPDATE counters SET value=? WHERE key=?')->execute([$v, $k]);
  }
}

function seed(PDO $db): void {
  $c = cfg();
  $ins = $db->prepare("INSERT INTO users (id, role, email, password_hash, name, country, status, kyc, created_at, approved_at, activation_at, booster_qualified, wallet_cents, sponsor_id, placement_parent_id, leg, usdt_address)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $t = now();
  $ins->execute(['MTX-ADMIN', 'admin', $c['admin_email'], password_hash($c['admin_password'], PASSWORD_DEFAULT), 'Marketix Desk', 'United States', 'active', 'verified', $t, $t, $t, 0, 0, null, null, null, '']);
}
