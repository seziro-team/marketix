<?php
require_once __DIR__ . '/public.php';
public_footer();
