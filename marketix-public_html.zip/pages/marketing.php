<?php
function page_home(): void {
  $c = cfg();
  ?>
  <section class="relative pt-28 pb-16 sm:pt-36 sm:pb-24">
    <?php shell_open(); ?>
      <div class="grid items-center gap-12 lg:grid-cols-[1.15fr_.85fr]">
        <div>
          <span class="tag flex items-center gap-2.5"><span class="bg-brass h-[5px] w-[5px]"></span>Running since <?= (int)$c['founded'] ?></span>
          <h1 class="font-display mt-5 text-[clamp(2.6rem,6vw,4.6rem)] leading-[0.98] font-extrabold tracking-[-0.04em]">Welcome to<br><?= e($c['name']) ?>.</h1>
          <p class="text-muted mt-6 max-w-[46ch] text-[1.125rem] leading-relaxed">A fully certified, licensed company in the United States. Reliable forex and cryptocurrency investment schedules, with a minimum of $100, settled only in USDT on BEP20.</p>
          <div class="mt-8 flex flex-wrap gap-3">
            <a href="/register/" class="btn-brass h-12 px-6">Open an account<?= icon('arrow-up-right','h-4 w-4') ?></a>
            <a href="/business-plan/" class="btn-ghost h-12 px-6">See the plans</a>
          </div>
        </div>
        <div class="panel p-6 sm:p-8">
          <img src="/brand/logo-lockup.jpg" alt="Marketix Ltd" class="mx-auto w-full max-w-[420px]">
          <p class="text-muted mt-6 text-center text-sm leading-relaxed">We are an award-winning multinational company. We believe in quality and standard worldwide.</p>
        </div>
      </div>
    <?php shell_close(); ?>
  </section>
  <section class="border-line border-y bg-white/70">
    <?php shell_open('py-8'); ?>
      <div class="grid grid-cols-2 gap-6 md:grid-cols-4">
        <?php foreach ([['Minimum','$100'],['Referral','10%'],['Withdrawal','1–2 hours'],['Support','24/7']] as [$k,$v]): ?>
          <div><p class="tag"><?= e($k) ?></p><p class="font-display mt-2 text-2xl font-extrabold"><?= e($v) ?></p></div>
        <?php endforeach; ?>
      </div>
    <?php shell_close(); ?>
  </section>
  <section class="py-16 sm:py-24"><?php shell_open(); section_head('Three steps','Get started', 'Registration is the gateway. Choose a plan, then fund it in USDT.'); ?>
    <div class="mt-10 grid gap-4 md:grid-cols-3">
      <?php foreach ([
        ['01','Register','A sponsor ID is required. We show that sponsor’s name before the account is created, then email your login.'],
        ['02','Choose a plan','Four schedules, from $100 to unlimited. Interest is counted 24 hours from the moment the package is activated.'],
        ['03','Make the investment','Deposit USDT on BEP20 into the fund wallet, then activate the plan you believe in.'],
      ] as [$n,$t,$b]): ?>
        <article class="panel p-6">
          <p class="font-display text-3xl font-extrabold text-brass"><?= e($n) ?></p>
          <h3 class="mt-3 text-xl"><?= e($t) ?></h3>
          <p class="text-muted mt-3 text-sm leading-relaxed"><?= e($b) ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  <?php shell_close(); ?></section>
  <section class="pb-8"><?php shell_open(); section_head('The book','What we offer'); ?>
    <div class="mt-10 grid gap-4 md:grid-cols-3">
      <?php foreach ([
        ['Forex & cryptocurrency','A wide range of forex and cryptocurrency investments, traded to maximise the published schedule.'],
        ['Stable income','Different forex pairs and cryptocurrency markets, reviewed on the same desk.'],
        ['Ten years and more','A large investor community. The aim is an equal chance to earn, and to grow with the people who join.'],
      ] as [$t,$b]): ?>
        <article class="panel p-6"><h3 class="text-xl"><?= e($t) ?></h3><p class="text-muted mt-3 text-sm leading-relaxed"><?= e($b) ?></p></article>
      <?php endforeach; ?>
    </div>
  <?php shell_close(); ?></section>
  <?php cta_band();
}

function page_about(): void {
  $c = cfg();
  page_header('About us', 'Marketix Ltd', 'Running since ' . $c['founded'] . '. A United States company offering investment schedules to people around the globe.', '');
  ?>
  <section class="py-14"><?php shell_open(); ?>
    <div class="grid gap-10 lg:grid-cols-[1.1fr_.9fr]">
      <div class="space-y-5 text-[1.05rem] leading-relaxed text-muted">
        <p>Marketix is a fully certified, licensed company in the United States which offers investors around the globe reliable investment schedules, with a minimum investment of $100.</p>
        <p>Our infinitely scalable investment platform is built to remove the limits that used to sit between an investor and a straightforward schedule.</p>
        <h2 class="font-display text-3xl font-bold text-porcelain">Mission</h2>
        <p>The mission of Marketix is to set up, promote and implement high quality standards for competence and ethical behaviour in the financial advisory sector.</p>
        <p>We are an award-winning multinational company. We believe in quality and standard worldwide.</p>
      </div>
      <div class="panel overflow-hidden">
        <img src="/brand/ceo.jpg" alt="Alex Darden, Chief Executive" class="aspect-[4/5] w-full object-cover">
        <div class="p-5"><p class="tag">Chief Executive</p><p class="font-display mt-1 text-2xl font-bold"><?= e($c['ceo']) ?></p></div>
      </div>
    </div>
    <div class="mt-14">
      <h2 class="font-display text-3xl font-bold">Certificate</h2>
      <img src="/brand/certificate.jpg" alt="Certificate of Trade for Marketix Ltd" class="mt-6 w-full max-w-3xl rounded border border-line bg-white">
    </div>
  <?php shell_close(); ?></section>
  <section class="pb-8"><?php shell_open(); section_head('Why us','How the desk is run'); ?>
    <div class="mt-8 grid gap-4 md:grid-cols-2">
      <article class="panel p-6"><h3 class="text-xl">Protected platform</h3><p class="text-muted mt-3 text-sm leading-relaxed">The platform is protected against denial-of-service attacks. Data in transit is protected with 256-bit encryption.</p></article>
      <article class="panel p-6"><h3 class="text-xl">Investment growth</h3><p class="text-muted mt-3 text-sm leading-relaxed">We trade forex pairs and cryptocurrency to help investors use the published schedules on this platform.</p></article>
      <article class="panel p-6"><h3 class="text-xl">Withdrawals</h3><p class="text-muted mt-3 text-sm leading-relaxed">Manually reviewed and released within 1–2 hours. A 10% fee applies. The minimum withdrawal is $10.</p></article>
      <article class="panel p-6"><h3 class="text-xl">24/7 support</h3><p class="text-muted mt-3 text-sm leading-relaxed">Support is available every day. Requests are answered within 24 hours.</p></article>
    </div>
  <?php shell_close(); ?></section>
  <?php cta_band();
}

function page_business(): void {
  page_header('Business plan', 'Four schedules. One settlement coin.', 'Every payment is USDT on BEP20. Interest is counted 24 hours from the time the package is activated.', '');
  ?>
  <section id="plans" class="py-14"><?php shell_open(); ?>
    <div class="grid gap-4 md:grid-cols-2">
      <?php foreach (plan()['plans'] as $row):
        $max = $row['max'] === null ? 'Unlimited' : usd((float)$row['max'], 0);
      ?>
        <article class="panel p-6">
          <p class="tag"><?= e($row['name']) ?></p>
          <h2 class="font-display mt-3 text-4xl font-extrabold"><?= e((string)$row['daily']) ?>% <span class="text-xl font-bold text-muted">after 24 hours</span></h2>
          <p class="mt-4 text-lg"><?= usd((float)$row['min'], 0) ?> – <?= e($max) ?></p>
          <ul class="text-muted mt-4 space-y-2 text-sm leading-relaxed">
            <li>Referral income: 10%</li>
            <li>Withdrawal: manually reviewed, released within 1–2 hours</li>
            <li>24/7 support</li>
          </ul>
        </article>
      <?php endforeach; ?>
    </div>
    <p class="text-faint mt-6 text-sm">Amounts between the bands are not part of a plan. Plan 1 is $100–$500, Plan 2 is $600–$5,000, Plan 3 is $6,000–$50,000, and Plan 4 starts at $60,000.</p>
  <?php shell_close(); ?></section>
  <section><?php shell_open(); section_head('Settlement','How money moves'); ?>
    <div class="mt-8 grid gap-4 md:grid-cols-3">
      <article class="panel p-6"><h3>Deposit</h3><p class="text-muted mt-2 text-sm">Send USDT on BEP20 and submit the hash. Approval credits the fund wallet. It does not start a plan by itself.</p></article>
      <article class="panel p-6"><h3>Activate</h3><p class="text-muted mt-2 text-sm">Choose an amount inside a plan. The 24-hour clock starts then. Your sponsor receives 10%.</p></article>
      <article class="panel p-6"><h3>Withdraw or reinvest</h3><p class="text-muted mt-2 text-sm">Income can be withdrawn (10% fee, $10 minimum, transaction password, then an email code) or reinvested into a new plan.</p></article>
    </div>
  <?php shell_close(); ?></section>
  <?php cta_band();
}

function page_contact(): void {
  $c = cfg();
  page_header('Contact us', 'Talk to the desk', 'Support answers within 24 hours, every day of the week.', '');
  ?>
  <section class="py-14"><?php shell_open(); ?>
    <div class="grid gap-8 lg:grid-cols-[.8fr_1.2fr]">
      <div class="panel p-6 space-y-4 text-sm">
        <p><span class="tag">Address</span><br><?= e($c['address']) ?></p>
        <p><span class="tag">Mail</span><br><a class="text-brass" href="mailto:<?= e($c['support_email']) ?>"><?= e($c['support_email']) ?></a></p>
        <p><span class="tag">Phone</span><br><a class="text-brass" href="tel:<?= e($c['phone_tel']) ?>"><?= e($c['phone']) ?></a></p>
        <p><span class="tag">Telegram</span><br><a class="text-brass" href="<?= e($c['telegram']) ?>" target="_blank" rel="noopener"><?= e($c['telegram_handle']) ?></a></p>
        <p><span class="tag">WhatsApp</span><br><a class="text-brass" href="<?= e($c['whatsapp']) ?>" target="_blank" rel="noopener">Message the desk</a></p>
        <p class="text-faint"><?= e($c['hours']) ?></p>
      </div>
      <form method="post" class="panel p-6 flex flex-col gap-4">
        <?= csrf_field() ?>
        <div><label class="label" for="name">Name</label><input class="field" id="name" name="name" required></div>
        <div><label class="label" for="email">Email</label><input class="field" id="email" name="email" type="email" required></div>
        <div><label class="label" for="interest">Interest</label><input class="field" id="interest" name="interest" placeholder="Plan, deposit, account"></div>
        <div><label class="label" for="message">Message</label><textarea class="field" id="message" name="message" rows="5" required></textarea></div>
        <button class="btn-brass h-12">Send</button>
        <p class="text-faint text-xs">Marketix will never ask for a wallet seed phrase or your password.</p>
      </form>
    </div>
  <?php shell_close(); ?></section>
<?php }

function page_legal_doc(string $tag, string $title, string $lede, string $updated, array $clauses): void {
  page_header($tag, $title, $lede, '');
  echo '<section class="py-12">'; shell_open();
  echo '<p class="text-faint mb-8 font-mono text-xs">Updated ' . e($updated) . '. Have a lawyer in your jurisdiction review this before you rely on it.</p>';
  foreach ($clauses as $h => $paras) {
    echo '<h2 class="font-display mt-8 text-2xl font-bold">' . e($h) . '</h2>';
    foreach ($paras as $p) echo '<p class="text-muted mt-3 leading-relaxed">' . $p . '</p>';
  }
  shell_close(); echo '</section>';
}

function page_terms(): void {
  $c = cfg();
  page_legal_doc('Terms', 'Terms of service', 'How accounts, deposits, plans and withdrawals work on ' . $c['domain'] . '.', '3 November 2026', [
    'The company' => [
      'These terms govern your use of ' . e($c['domain']) . ' and your membership of ' . e($c['name']) . '. By registering you accept them.',
      'The office address is ' . e($c['address']) . '. Support is ' . e($c['support_email']) . '.',
    ],
    'Accounts' => [
      'A sponsor ID is required. The registration form shows that sponsor’s name before the account is created. After the email code is verified we email your member ID and password.',
      'You are responsible for the login password and for the separate transaction password used on withdrawals.',
    ],
    'Money' => [
      'The only accepted payment is USDT on BEP20 (BNB Smart Chain). Other assets sent to the company address cannot be recovered.',
      'An approved deposit credits your fund wallet. A plan starts only when you activate a package from that wallet, or when you reinvest available income. Interest is credited every 24 hours from that activation, at the rate of the plan the amount falls into.',
      'Referral income is 10% of a package, credited to the sponsor when the package is activated.',
      'Withdrawals are taken from available income, minimum $10, with a 10% fee. Each request needs the transaction password and then an email code. A person reviews it and releases it within 1–2 hours.',
      'Changing a saved payout address also requires an email code. Topping up another member’s fund wallet requires an email code.',
    ],
    'Risk' => [
      'The percentages on this website are the schedule the desk operates. They are not a promise that a market will produce that result, and capital can be lost. Do not invest money you cannot afford to lose.',
    ],
  ]);
}

function page_privacy(): void {
  $c = cfg();
  page_legal_doc('Privacy', 'Privacy policy', 'What ' . $c['domain'] . ' stores in order to run an account.', '3 November 2026', [
    'What we store' => [
      'Name, email, optional mobile number, country, sponsor ID, password hashes, an optional USDT payout address, optional KYC images, deposits, packages, withdrawals and support messages.',
      'KYC images are optional. They are not published on the website.',
    ],
    'Why' => [
      'To open the account, email login details and one-time codes, credit the fund wallet, run the published schedule, and pay withdrawals to the address you saved.',
      'Mail is sent from ' . e($c['from_email']) . ' through the host’s mail server.',
    ],
    'Cookies' => [
      'We use a session cookie to keep you signed in, a referral cookie if you arrive with ?ref=, and a security token on forms. The language menu is provided by Google Translate, which sets its own cookie if you use it.',
    ],
  ]);
}

function page_not_found(): void { ?>
  <section class="pt-32 pb-20"><?php shell_open(); ?>
    <h1 class="font-display text-5xl font-extrabold">Page not found</h1>
    <p class="text-muted mt-4">That address is not on this site.</p>
    <a class="btn-brass mt-8 inline-flex h-11 px-5" href="/">Back home</a>
  <?php shell_close(); ?></section>
<?php }
