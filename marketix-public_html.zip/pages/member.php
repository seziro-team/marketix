<?php
function ledger_sum(string $id, string $sqlKind): int {
  $st = db()->prepare("SELECT COALESCE(SUM(amount_cents),0) FROM ledger WHERE user_id=? AND amount_cents>0 AND kind IN ($sqlKind)");
  $st->execute([$id]);
  return (int)$st->fetchColumn();
}
function member_stats(array $u): array {
  $id = $u['id'];
  $interest = ledger_sum($id, "'roi','fd'");
  $referral = ledger_sum($id, "'direct'");
  $withdrawn = 0;
  $st = db()->prepare("SELECT COALESCE(SUM(amount_cents),0) FROM withdrawals WHERE user_id=? AND status IN ('pending','approved')");
  $st->execute([$id]);
  $withdrawn = (int)$st->fetchColumn();
  $sponsor = !empty($u['sponsor_id']) ? user_by_id((string)$u['sponsor_id']) : null;
  return [
    'invested' => invested_cents($id),
    'wallet' => (int)$u['wallet_cents'],
    'fund' => (int)($u['fund_cents'] ?? 0),
    'earned' => $interest + $referral,
    'interest' => $interest,
    'referral' => $referral,
    'withdrawn' => $withdrawn,
    'directs' => active_direct_count($id),
    'active' => has_active_package($id),
    'sponsor_name' => $sponsor['name'] ?? '',
    'sponsor_id' => $sponsor['id'] ?? '',
  ];
}

function page_dash(array $u): void {
  $s = member_stats($u);
  $st = db()->prepare('SELECT * FROM ledger WHERE user_id=? ORDER BY at DESC LIMIT 8');
  $st->execute([$u['id']]);
  $rows = $st->fetchAll();
  $ref = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? '') . '/register/?ref=' . $u['id'];
  $addr = get_setting('wallet_address', cfg()['wallet_address']);
  $stInv = db()->prepare("SELECT * FROM investments WHERE user_id=? AND status IN ('active','capped','matured') ORDER BY started_at DESC");
  $stInv->execute([$u['id']]);
  $positions = $stInv->fetchAll();
  ?>
  <div class="page-title dash-hello">
    <div>
      <h1>Welcome back, <?= e(explode(' ', $u['name'])[0]) ?></h1>
      <p class="muted">UID <?= e($u['id']) ?> · <?= $s['active'] ? 'Active' : 'Inactive' ?> · joined <?= e(when_fmt($u['created_at'])) ?></p>
      <?php if ($s['sponsor_id']): ?><p class="faint">Sponsor: <?= e($s['sponsor_name']) ?> (<?= e($s['sponsor_id']) ?>)</p><?php endif; ?>
    </div>
    <div class="dash-actions">
      <a class="btn-brass" href="/dashboard/deposit/">Deposit</a>
      <a class="btn-ghost" href="/dashboard/packages/">Activate</a>
      <a class="btn-ghost" href="/dashboard/withdraw/">Withdraw</a>
      <a class="btn-ghost" href="/dashboard/reinvest/">Reinvest</a>
    </div>
  </div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Available balance</p><div class="v" style="color:var(--brass)"><?= usd(dollars($s['wallet'])) ?></div><p class="faint">Income you can withdraw or reinvest</p></div>
    <div class="panel tile"><p class="tag">Fund wallet</p><div class="v"><?= usd(dollars($s['fund'])) ?></div><p class="faint">Deposits waiting to activate a plan</p></div>
    <div class="panel tile"><p class="tag">Total income</p><div class="v" style="color:var(--up)"><?= usd(dollars($s['earned'])) ?></div></div>
    <div class="panel tile"><p class="tag">Total withdrawn</p><div class="v"><?= usd(dollars($s['withdrawn'])) ?></div></div>
    <div class="panel tile"><p class="tag">Interest income</p><div class="v"><?= usd(dollars($s['interest'])) ?></div></div>
    <div class="panel tile"><p class="tag">Referral income</p><div class="v"><?= usd(dollars($s['referral'])) ?></div><p class="faint"><?= (int)$s['directs'] ?> active directs · 10%</p></div>
  </div>
  <div class="grid-2" style="margin-top:1rem">
    <div class="panel">
      <div class="card-h"><span class="tag">Referral link</span></div>
      <div style="padding:1.25rem">
        <input class="field break-all" readonly value="<?= e($ref) ?>" onclick="this.select()" style="font-size:.8rem">
        <p class="faint" style="margin-top:.75rem">Anyone who joins on this link sees your name as sponsor. You earn 10% of each package they activate.</p>
      </div>
    </div>
    <div class="panel">
      <div class="card-h"><span class="tag">Plan & investment</span><a href="/dashboard/packages/" style="color:var(--brass);font-family:var(--font-mono);font-size:.625rem">ACTIVATE</a></div>
      <?php if (!$positions): ?><p class="muted" style="padding:1.25rem">No active plan yet. Deposit USDT, then activate a package from the fund wallet.</p><?php endif; ?>
      <?php foreach (array_slice($positions, 0, 4) as $p): ?>
        <div style="display:flex;justify-content:space-between;gap:.75rem;flex-wrap:wrap;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
          <span><?= e(product_label($p['kind'])) ?><div class="faint"><?= e(rtrim(rtrim(number_format((float)($p['daily_pct'] ?? 0), 2, '.', ''), '0'), '.')) ?>% / 24h · <?= e(ucfirst((string)$p['status'])) ?></div></span>
          <span class="num"><?= usd(dollars((int)$p['principal_cents']), 0) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php if (($addr && $addr !== '0x0000000000000000000000000000000000000000') || wallet_qr_url()): ?>
  <div class="grid-2" style="margin-top:1rem">
    <div class="panel wallet-row" style="padding:1.25rem">
      <div style="flex-shrink:0"><?= company_qr_img(112) ?></div>
      <div style="min-width:0;flex:1;width:100%">
        <p class="tag">Company USDT BEP20</p>
        <input class="field break-all" style="margin-top:.5rem;font-family:var(--font-mono);font-size:.75rem" readonly value="<?= e($addr) ?>">
        <p class="faint" style="margin-top:.5rem">Scan the desk QR or copy the address. <a href="/dashboard/deposit/" style="color:var(--brass)">Deposit →</a></p>
      </div>
    </div>
    <div class="panel">
      <div class="card-h"><span class="tag">Your positions</span><a href="/dashboard/packages/" style="color:var(--brass);font-family:var(--font-mono);font-size:.625rem">ALL</a></div>
      <?php foreach ($positions as $p): ?>
        <div style="display:flex;justify-content:space-between;gap:.75rem;flex-wrap:wrap;padding:.85rem 1.25rem;border-top:1px solid var(--line-soft)">
          <span style="min-width:0"><?= e(product_label($p['kind'])) ?><div class="faint"><?= e(ucfirst((string)$p['status'])) ?></div></span>
          <span class="num"><?= usd(dollars((int)$p['principal_cents']), 0) ?></span>
        </div>
      <?php endforeach; if (!$positions): ?><p class="muted" style="padding:1.25rem">No funded products yet.</p><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Recent activity</span></div>
    <div class="table-wrap"><table class="ledger">
      <thead><tr><th>When</th><th>Type</th><th>Detail</th><th>Amount</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="muted"><?= e(when_fmt($r['at'])) ?></td>
          <td><?= e(kind_label($r['kind'])) ?></td>
          <td class="faint"><?= e($r['note']) ?></td>
          <td class="num" style="color:<?= $r['amount_cents']<0?'var(--down)':'var(--up)' ?>"><?= ($r['amount_cents']<0?'−':'+').usd(dollars(abs((int)$r['amount_cents']))) ?></td>
        </tr>
      <?php endforeach; if (!$rows): ?><tr><td colspan="4" class="muted">No movements yet.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
<?php }

function page_deposit(array $u): void {
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do'] ?? '')==='deposit') {
    csrf_check();
    try {
      if ($u['status'] !== 'active') throw new RuntimeException('Account is not active.');
      $amt = (float)($_POST['amount'] ?? 0);
      $hash = trim($_POST['hash'] ?? '');
      $min = (float)get_setting('min_deposit', '100');
      if ($amt < $min) throw new RuntimeException('Minimum deposit is $' . rtrim(rtrim(number_format($min, 2, '.', ''), '0'), '.') . '.');
      if (!preg_match('/^0x[a-fA-F0-9]{64}$/', $hash)) throw new RuntimeException('Paste a full BEP20 transaction hash.');
      $dup = db()->prepare('SELECT id FROM deposits WHERE lower(tx_hash)=lower(?)');
      $dup->execute([$hash]);
      if ($dup->fetch()) throw new RuntimeException('That hash was already submitted.');
      $id = next_id('DP','deposit',4);
      db()->prepare("INSERT INTO deposits (id,user_id,amount_cents,tx_hash,note,product,status,submitted_at) VALUES (?,?,?,?,?,?,'pending',?)")
        ->execute([$id,$u['id'],cents($amt),$hash,trim($_POST['note']??''),'plan',now()]);
      flash("Deposit $id is in the review queue.");
      redirect('/dashboard/deposit/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  $addr = get_setting('wallet_address', cfg()['wallet_address']);
  $st = db()->prepare('SELECT * FROM deposits WHERE user_id=? ORDER BY submitted_at DESC');
  $st->execute([$u['id']]);
  $rows = $st->fetchAll();
  ?>
  <div class="page-title"><div><h1>Deposit USDT</h1><p class="muted">BEP20 only. After the desk approves the hash, the amount lands in your fund wallet. Activate a plan from that balance.</p></div></div>
  <?php if ($addr === '0x0000000000000000000000000000000000000000'): ?>
    <div class="flash-err">Placeholder wallet — do not send funds. The desk has not set a receiving address.</div>
  <?php endif; ?>
  <div class="grid-2">
    <div class="panel" style="padding:1.25rem;text-align:center">
      <?= company_qr_img(168) ?>
      <p class="tag" style="margin-top:1rem">Receiving address</p>
      <input class="field" style="margin-top:.5rem;font-family:var(--font-mono);font-size:.8rem" readonly value="<?= e($addr) ?>">
      <p class="faint" style="margin-top:.75rem">USDT on BEP20 only. Other tokens or chains cannot be recovered.</p>
    </div>
    <form method="post" class="panel" style="padding:1.25rem;display:flex;flex-direction:column;gap:1rem">
      <?= csrf_field() ?><input type="hidden" name="do" value="deposit">
      <div><label class="label">Amount (USDT)</label><input class="field" type="number" name="amount" min="100" step="0.01" placeholder="100" required></div>
      <div><label class="label">Transaction hash</label><input class="field" name="hash" placeholder="0x…" required></div>
      <div><label class="label">Note</label><textarea class="field" name="note" rows="3"></textarea></div>
      <button class="btn-brass" style="height:44px" <?= $u['status']!=='active'?'disabled':'' ?>>Submit for verification</button>
    </form>
  </div>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">History</span></div>
    <div class="table-wrap"><table class="ledger">
      <thead><tr><th>Ref</th><th>When</th><th>Product</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr><td><?= e($r['id']) ?></td><td><?= e(when_fmt($r['submitted_at'])) ?></td><td>USDT BEP20</td><td><?= usd(dollars((int)$r['amount_cents'])) ?></td><td><?= status_pill($r['status']) ?></td></tr>
      <?php endforeach; if (!$rows): ?><tr><td colspan="5" class="muted">No deposits yet.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
<?php }

function assert_tx_password(array $u, string $given): void {
  $hash = (string)($u['tx_password_hash'] ?? '');
  if ($hash === '' || !password_verify($given, $hash)) {
    throw new RuntimeException('Transaction password is wrong. Set it under Passwords if you have not yet.');
  }
}
function page_withdraw(array $u): void {
  $step = $_GET['step'] ?? '';
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='withdraw') {
    csrf_check();
    try {
      $u = user_by_id($u['id']) ?: $u;
      assert_tx_password($u, (string)($_POST['tx_password'] ?? ''));
      $amount = (float)($_POST['amount'] ?? 0);
      $min = (float)get_setting('min_withdraw', '10');
      if ($amount < $min) throw new RuntimeException('Minimum withdrawal is $' . rtrim(rtrim(number_format($min, 2, '.', ''), '0'), '.') . '.');
      if (cents($amount) > (int)$u['wallet_cents']) throw new RuntimeException('Not enough available income.');
      if (!preg_match('/^0x[a-fA-F0-9]{40}$/', $u['usdt_address'] ?? '')) throw new RuntimeException('Save a USDT BEP20 address in Profile first.');
      issue_otp($u['email'], 'withdraw', ['uid' => $u['id'], 'amount' => $amount]);
      $_SESSION['otp_email'] = $u['email'];
      flash('We emailed a code. Enter it to confirm the withdrawal.');
      redirect('/dashboard/withdraw/?step=otp');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='withdraw-otp') {
    csrf_check();
    try {
      $payload = verify_otp($u['email'], 'withdraw', trim($_POST['code'] ?? ''));
      if (!$payload || ($payload['uid'] ?? '') !== $u['id']) throw new RuntimeException('That code is wrong or expired.');
      $fresh = user_by_id($u['id']) ?: $u;
      $id = request_withdrawal($fresh, (float)($payload['amount'] ?? 0));
      flash("Withdrawal $id is in the review queue. It is released within 1–2 hours after a manual review.");
      redirect('/dashboard/withdraw/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  $u = user_by_id($u['id']) ?: $u;
  $fee = (float)get_setting('profit_fee_pct', '10');
  $st = db()->prepare('SELECT * FROM withdrawals WHERE user_id=? ORDER BY requested_at DESC');
  $st->execute([$u['id']]);
  $rows = $st->fetchAll();
  ?>
  <div class="page-title"><div><h1>Withdraw</h1><p class="muted"><?= e(rtrim(rtrim(number_format($fee, 2, '.', ''), '0'), '.')) ?>% fee · minimum $10 · manually reviewed, released within 1–2 hours. A transaction password and an email code are both required.</p></div></div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Available income</p><div class="v" style="color:var(--brass)"><?= usd(dollars((int)$u['wallet_cents'])) ?></div></div>
  </div>
  <?php if ($step === 'otp'): ?>
  <form method="post" class="panel" style="margin-top:1rem;padding:1.25rem;display:flex;flex-direction:column;gap:1rem;max-width:640px">
    <?= csrf_field() ?><input type="hidden" name="do" value="withdraw-otp">
    <div><label class="label">Email code</label><input class="field" name="code" inputmode="numeric" autocomplete="one-time-code" required></div>
    <button class="btn-brass" style="height:48px">Confirm withdrawal</button>
  </form>
  <?php else: ?>
  <form method="post" class="panel" style="margin-top:1rem;padding:1.25rem;display:flex;flex-direction:column;gap:1rem;max-width:640px;width:100%">
    <?= csrf_field() ?><input type="hidden" name="do" value="withdraw">
    <div><label class="label">Amount (USDT)</label><input class="field" type="number" step="0.01" min="10" name="amount" placeholder="0.00" required></div>
    <div><label class="label">Transaction password</label><input class="field" type="password" name="tx_password" required></div>
    <div>
      <p class="label">Pays to</p>
      <input class="field break-all" readonly value="<?= e($u['usdt_address'] ?: 'No address on file — set it in Profile') ?>" style="font-family:var(--font-mono);font-size:.8rem">
    </div>
    <button class="btn-brass" style="height:48px">Email me a code</button>
  </form>
  <?php endif; ?>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">History</span></div>
    <div class="table-wrap"><table class="ledger">
      <thead><tr><th>Ref</th><th>When</th><th>Type</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr><td><?= e($r['id']) ?></td><td><?= e(when_fmt($r['requested_at'])) ?></td><td><?= e($r['type']) ?></td><td>−<?= usd(dollars((int)$r['amount_cents'])) ?></td><td><?= status_pill($r['status']) ?></td></tr>
      <?php endforeach; if (!$rows): ?><tr><td colspan="5" class="muted">None yet.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
<?php }

function page_wallet(array $u): void {
  $u = user_by_id($u['id']) ?: $u;
  ?>
  <div class="page-title"><div><h1>Fund wallet</h1><p class="muted">Approved deposits sit here until you activate a plan. You can also move this balance to another member ID.</p></div></div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Fund balance</p><div class="v" style="color:var(--brass)"><?= usd(dollars((int)$u['fund_cents'])) ?></div></div>
    <div class="panel tile"><p class="tag">Available income</p><div class="v"><?= usd(dollars((int)$u['wallet_cents'])) ?></div></div>
  </div>
  <div class="dash-actions" style="margin-top:1rem">
    <a class="btn-brass" href="/dashboard/packages/">Activate a package</a>
    <a class="btn-ghost" href="/dashboard/deposit/">Deposit</a>
    <a class="btn-ghost" href="/dashboard/topup/">Top up a member</a>
  </div>
<?php }
function page_topup(array $u): void {
  $step = $_GET['step'] ?? '';
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='topup') {
    csrf_check();
    try {
      $u = user_by_id($u['id']) ?: $u;
      $to = strtoupper(trim($_POST['member'] ?? ''));
      $amount = (float)($_POST['amount'] ?? 0);
      $centsAmt = cents($amount);
      if ($centsAmt < 100) throw new RuntimeException('Minimum top up is $1.');
      $target = user_by_id($to);
      if (!$target || $target['role'] !== 'member') throw new RuntimeException('That member ID was not found.');
      if ((int)$u['fund_cents'] < $centsAmt) throw new RuntimeException('Not enough in your fund wallet.');
      issue_otp($u['email'], 'topup', ['uid' => $u['id'], 'to' => $target['id'], 'amount' => $amount]);
      flash('We emailed a code so this top up cannot be sent by mistake.');
      redirect('/dashboard/topup/?step=otp');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='topup-otp') {
    csrf_check();
    try {
      $payload = verify_otp($u['email'], 'topup', trim($_POST['code'] ?? ''));
      if (!$payload || ($payload['uid'] ?? '') !== $u['id']) throw new RuntimeException('That code is wrong or expired.');
      $fresh = user_by_id($u['id']) ?: $u;
      transfer_fund($fresh, (string)$payload['to'], cents((float)$payload['amount']));
      flash('Top up sent to ' . $payload['to'] . '.');
      redirect('/dashboard/topup/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  $u = user_by_id($u['id']) ?: $u;
  ?>
  <div class="page-title"><div><h1>Top up a member</h1><p class="muted">Move USDT from your fund wallet into another member’s fund wallet. An email code confirms it.</p></div></div>
  <div class="panel tile" style="max-width:280px"><p class="tag">Your fund wallet</p><div class="v"><?= usd(dollars((int)$u['fund_cents'])) ?></div></div>
  <?php if ($step === 'otp'): ?>
  <form method="post" class="panel" style="margin-top:1rem;padding:1.25rem;max-width:560px;display:flex;flex-direction:column;gap:1rem">
    <?= csrf_field() ?><input type="hidden" name="do" value="topup-otp">
    <div><label class="label">Email code</label><input class="field" name="code" inputmode="numeric" required></div>
    <button class="btn-brass" style="height:44px">Confirm top up</button>
  </form>
  <?php else: ?>
  <form method="post" class="panel" style="margin-top:1rem;padding:1.25rem;max-width:560px;display:flex;flex-direction:column;gap:1rem">
    <?= csrf_field() ?><input type="hidden" name="do" value="topup">
    <div><label class="label">Member ID</label><input class="field" name="member" placeholder="MTX-100001" required></div>
    <div><label class="label">Amount (USDT)</label><input class="field" type="number" min="1" step="0.01" name="amount" required></div>
    <button class="btn-brass" style="height:44px">Email me a code</button>
  </form>
  <?php endif;
}
function page_reinvest(array $u): void {
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='reinvest') {
    csrf_check();
    try {
      $id = request_reinvest($u, (float)($_POST['amount']??0));
      $row = plan_for_cents(cents((float)($_POST['amount']??0)));
      flash('Reinvested into ' . ($row['name'] ?? 'a plan') . ' · ' . $id . '. The 24-hour clock starts now.');
      redirect('/dashboard/reinvest/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  $u = user_by_id($u['id']) ?: $u;
  $st = db()->prepare("SELECT * FROM ledger WHERE user_id=? AND kind='reinvest' ORDER BY at DESC");
  $st->execute([$u['id']]);
  $rows = $st->fetchAll();
  ?>
  <div class="page-title"><div><h1>Reinvest</h1><p class="muted">Move available income into a new plan. The amount has to sit inside a published band. Interest starts 24 hours after this activation.</p></div></div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Available income</p><div class="v" style="color:var(--brass)"><?= usd(dollars((int)$u['wallet_cents'])) ?></div></div>
  </div>
  <form method="post" class="panel" style="margin-top:1rem;padding:1.25rem;display:flex;flex-direction:column;gap:1rem;max-width:640px;width:100%">
    <?= csrf_field() ?><input type="hidden" name="do" value="reinvest">
    <div><label class="label">Amount (USDT)</label><input class="field" type="number" step="0.01" min="100" name="amount" required></div>
    <p class="faint"><?= e(plan_bands_text()) ?></p>
    <button class="btn-brass" style="height:48px">Reinvest</button>
  </form>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">History</span></div>
    <div class="table-wrap"><table class="ledger">
      <thead><tr><th>When</th><th>Detail</th><th>Amount</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr><td><?= e(when_fmt($r['at'])) ?></td><td class="faint"><?= e($r['note']) ?></td><td>−<?= usd(dollars(abs((int)$r['amount_cents']))) ?></td></tr>
      <?php endforeach; if (!$rows): ?><tr><td colspan="3" class="muted">None yet.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
<?php }

function page_tx(array $u): void {
  $st = db()->prepare('SELECT * FROM ledger WHERE user_id=? ORDER BY at DESC LIMIT 200');
  $st->execute([$u['id']]); $rows = $st->fetchAll();
  ?>
  <div class="page-title"><h1>Transactions</h1></div>
  <div class="tx-cards">
    <?php foreach ($rows as $r):
      $neg = (int)$r['amount_cents'] < 0;
    ?>
      <div class="tx-card">
        <div>
          <p class="tx-type"><?= e(kind_label($r['kind'])) ?></p>
          <p class="faint"><?= e($r['note'] ?: '—') ?></p>
          <p class="muted" style="margin-top:.35rem;font-size:.75rem"><?= e(when_fmt($r['at'])) ?></p>
        </div>
        <div class="num" style="color:<?= $neg?'var(--down)':'var(--up)' ?>"><?= ($neg?'−':'+').usd(dollars(abs((int)$r['amount_cents']))) ?></div>
      </div>
    <?php endforeach; if (!$rows): ?><p class="muted">Empty ledger.</p><?php endif; ?>
  </div>
  <div class="panel tx-table"><div class="table-wrap"><table class="ledger">
    <thead><tr><th>When</th><th>Type</th><th>Detail</th><th>Amount</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr><td><?= e(when_fmt($r['at'])) ?></td><td><?= e(kind_label($r['kind'])) ?></td><td class="faint"><?= e($r['note']) ?></td>
      <td class="num" style="color:<?= $r['amount_cents']<0?'var(--down)':'var(--up)' ?>"><?= ($r['amount_cents']<0?'−':'+').usd(dollars(abs((int)$r['amount_cents']))) ?></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="4" class="muted">Empty ledger.</td></tr><?php endif; ?>
    </tbody>
  </table></div></div>
<?php }

function page_packages(array $u): void {
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='activate') {
    csrf_check();
    try {
      $id = activate_package($u['id'], cents((float)($_POST['amount'] ?? 0)));
      flash('Package ' . $id . ' is active. The first interest posts 24 hours from now.');
      redirect('/dashboard/packages/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  $u = user_by_id($u['id']) ?: $u;
  $st = db()->prepare('SELECT * FROM investments WHERE user_id=? ORDER BY started_at DESC');
  $st->execute([$u['id']]); $rows = $st->fetchAll();
  ?>
  <div class="page-title"><div><h1>Activate package</h1><p class="muted">Spend the fund wallet on a plan. The 24 hours are counted from this activation.</p></div></div>
  <div class="panel tile" style="max-width:280px;margin-bottom:1rem"><p class="tag">Fund wallet</p><div class="v" style="color:var(--brass)"><?= usd(dollars((int)$u['fund_cents'])) ?></div></div>
  <form method="post" class="panel" style="padding:1.25rem;display:flex;flex-direction:column;gap:1rem;max-width:640px">
    <?= csrf_field() ?><input type="hidden" name="do" value="activate">
    <div><label class="label">Amount (USDT)</label><input class="field" type="number" min="100" step="0.01" name="amount" required></div>
    <p class="faint"><?= e(plan_bands_text()) ?></p>
    <button class="btn-brass" style="height:48px">Activate</button>
  </form>
  <div class="panel table-wrap" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Published plans</span></div>
    <table class="ledger">
      <thead><tr><th>Plan</th><th>Range</th><th>Interest</th><th>Referral</th></tr></thead>
      <tbody>
      <?php foreach (plan()['plans'] as $row): ?>
        <tr>
          <td><?= e($row['name']) ?></td>
          <td><?= usd((float)$row['min'], 0) ?> – <?= $row['max'] === null ? 'Unlimited' : usd((float)$row['max'], 0) ?></td>
          <td><?= e((string)$row['daily']) ?>% after 24 hours</td>
          <td>10%</td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="panel" style="margin-top:1rem">
    <div class="card-h"><span class="tag">Your packages</span></div>
    <div class="table-wrap"><table class="ledger">
      <thead><tr><th>ID</th><th>Kind</th><th>Started</th><th>Principal</th><th>Interest paid</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r):
        $paid = earned_on_investment($r);
        $cap = investment_cap_cents($r);
      ?>
        <tr><td><?= e($r['id']) ?></td><td><?= e(product_label($r['kind'])) ?> · <?= e(rtrim(rtrim(number_format((float)($r['daily_pct'] ?? 0), 2, '.', ''), '0'), '.')) ?>%</td><td><?= e(when_fmt($r['started_at'])) ?></td><td><?= usd(dollars((int)$r['principal_cents'])) ?></td><td class="num"><?= usd(dollars($paid), 0) ?></td><td><?= status_pill($r['status']) ?></td></tr>
      <?php endforeach; if (!$rows): ?><tr><td colspan="6" class="muted">None yet.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
<?php }

function member_detail_attrs(array $u): string {
  $c = member_card($u);
  return 'data-member="1" data-id="'.e($c['id']).'" data-name="'.e($c['name']).'" data-joined="'.e($c['joined']).'" data-status="'.($c['active']?'Active':'Inactive').'" data-package="'.e($c['package']).'" data-leg="'.e($c['leg']==='L'?'Left':($c['leg']==='R'?'Right':'—')).'"';
}

function gene_children(string $parentId): array {
  $st = db()->prepare('SELECT * FROM users WHERE placement_parent_id=?');
  $st->execute([$parentId]);
  $out = ['L' => null, 'R' => null];
  foreach ($st as $row) {
    if ($row['leg'] === 'L' || $row['leg'] === 'R') $out[$row['leg']] = $row;
  }
  return $out;
}

function render_gene_node(?array $u, string $side, int $depth = 0): void {
  if ($depth > 24) return;
  if (!$u) {
    echo '<div class="gene-leg"><div class="gene-empty">Open · '.($side==='L'?'Left':'Right').'</div></div>';
    return;
  }
  $kids = gene_children($u['id']);
  $active = has_active_package($u['id']);
  echo '<div class="gene-leg"><div class="gene-node">';
  echo '<button type="button" class="gene-card'.($active?' is-active':'').'" '.member_detail_attrs($u).'>';
  echo '<span class="gene-name">'.e($u['name']).'</span>';
  echo '<span class="faint" style="font-family:var(--font-mono);font-size:.625rem">'.e($u['id']).'</span>';
  echo package_pill($active ? ['status'=>'active','earning_cents'=>1] : ['status'=>'inactive','earning_cents'=>0]);
  echo '</button>';
  echo '<div class="gene-kids">';
  render_gene_node($kids['L'], 'L', $depth + 1);
  render_gene_node($kids['R'], 'R', $depth + 1);
  echo '</div></div></div>';
}

function member_detail_modal(): void { ?>
  <div id="member-detail" class="modal-bg">
    <div class="modal" role="dialog" aria-labelledby="md-name">
      <div class="modal-h"><h2 id="md-name" style="font-size:1.05rem">Member</h2><button type="button" class="btn-ghost" style="height:36px;padding:0 .8rem" data-md-close>Close</button></div>
      <div class="modal-b">
        <dl class="member-dl">
          <div><dt>Member ID</dt><dd id="md-id">—</dd></div>
          <div><dt>Status</dt><dd id="md-status">—</dd></div>
          <div><dt>Package</dt><dd id="md-package">—</dd></div>
          <div><dt>Joining date</dt><dd id="md-joined">—</dd></div>
          <div><dt>Leg</dt><dd id="md-leg">—</dd></div>
        </dl>
      </div>
    </div>
  </div>
  <script>
  (function () {
    var bg = document.getElementById('member-detail');
    if (!bg) return;
    function close() { bg.classList.remove('open'); }
    function openFrom(el) {
      document.getElementById('md-name').textContent = el.getAttribute('data-name') || 'Member';
      document.getElementById('md-id').textContent = el.getAttribute('data-id') || '—';
      document.getElementById('md-status').textContent = el.getAttribute('data-status') || '—';
      document.getElementById('md-package').textContent = el.getAttribute('data-package') || 'None';
      document.getElementById('md-joined').textContent = el.getAttribute('data-joined') || '—';
      document.getElementById('md-leg').textContent = el.getAttribute('data-leg') || '—';
      bg.classList.add('open');
    }
    document.addEventListener('click', function (e) {
      var hit = e.target.closest('[data-member]');
      if (hit) { e.preventDefault(); openFrom(hit); return; }
      if (e.target.closest('[data-md-close]') || e.target === bg) close();
    });
  })();
  </script>
<?php }

function page_team(array $u): void {
  $st = db()->prepare("SELECT u.*, COALESCE((SELECT SUM(principal_cents) FROM investments i WHERE i.user_id=u.id AND i.status IN ('active','capped','matured')),0) AS invested_cents, COALESCE((SELECT SUM(principal_cents) FROM investments i WHERE i.user_id=u.id AND i.status='active'),0) AS earning_cents FROM users u WHERE u.sponsor_id=? ORDER BY u.created_at DESC");
  $st->execute([$u['id']]); $rows = $st->fetchAll();
  $ref = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? '') . '/register/?ref=' . $u['id'];
  ?>
  <div class="page-title"><div><h1>Referral list</h1><p class="muted">Name, joining date, package and status for everyone who registered under you.</p></div></div>
  <div class="panel" style="padding:1.25rem;margin-bottom:1rem">
    <p class="tag">Referral link</p>
    <input class="field break-all" style="margin-top:.5rem;font-size:.8rem" readonly value="<?= e($ref) ?>">
    <p class="faint" style="margin-top:.6rem">New members see your name as their sponsor. You receive 10% when they activate a package.</p>
  </div>
  <div class="panel"><div class="table-wrap"><table class="ledger">
    <thead><tr><th>Member</th><th>Joined</th><th>Package</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr class="row-hit" <?= member_detail_attrs($r) ?>><td><?= e($r['name']) ?><div class="faint" style="font-family:var(--font-mono);font-size:.625rem"><?= e($r['id']) ?></div></td>
      <td><?= e(substr($r['created_at'],0,10)) ?></td><td class="faint"><?= e(current_package_label($r['id'])) ?></td><td><?= package_pill($r) ?></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="4" class="muted">Share your link to start.</td></tr><?php endif; ?>
    </tbody>
  </table></div></div>
  <?php member_detail_modal();
}

function page_gene(array $u): void {
  $s = member_stats($u);
  $kids = gene_children($u['id']);
  ?>
  <div class="page-title"><div><h1>Genealogy</h1><p class="muted">Full binary tree to the last level. Tap a member for Active/Inactive, package and joining date.</p></div></div>
  <div class="tiles">
    <div class="panel tile"><p class="tag">Left volume</p><div class="v"><?= usd(dollars($s['left']),0) ?></div></div>
    <div class="panel tile"><p class="tag">Right volume</p><div class="v"><?= usd(dollars($s['right']),0) ?></div></div>
    <div class="panel tile"><p class="tag">Active directs</p><div class="v"><?= $s['directs'] ?></div></div>
  </div>
  <div class="panel gene-wrap">
    <div class="gene-tree">
      <div class="gene-node gene-root">
        <div class="gene-card is-you">
          <span class="gene-name"><?= e($u['name']) ?></span>
          <span class="faint" style="font-family:var(--font-mono);font-size:.625rem"><?= e($u['id']) ?> · you</span>
        </div>
        <div class="gene-kids">
          <?php render_gene_node($kids['L'], 'L'); render_gene_node($kids['R'], 'R'); ?>
        </div>
      </div>
    </div>
  </div>
  <?php member_detail_modal();
}

function page_income(array $u): void {
  $kinds = [
    'roi' => 'Interest income',
    'direct' => 'Referral income',
  ];
  $k = $_GET['k'] ?? '';
  if ($k && !isset($kinds[$k])) $k = '';
  $sql = "SELECT * FROM ledger WHERE user_id=? AND amount_cents>0 AND kind IN ('roi','direct','level','generation','salary','community','fd','promo')";
  $args = [$u['id']];
  if ($k) { $sql .= ' AND kind=?'; $args[] = $k; }
  $sql .= ' ORDER BY at DESC';
  $st = db()->prepare($sql);
  $st->execute($args);
  $rows = $st->fetchAll();
  $sum = 0;
  foreach ($rows as $r) $sum += (int)$r['amount_cents'];
  $title = $k ? $kinds[$k] : 'All income';
  ?>
  <div class="page-title"><div><h1><?= e($title) ?></h1><p class="muted">Interest is credited every 24 hours from the time each package was activated.</p></div></div>
  <div class="income-tabs">
    <a href="/dashboard/income/" class="<?= $k===''?'on':'' ?>">All</a>
    <?php foreach ($kinds as $key=>$lab): ?>
      <a href="/dashboard/income/?k=<?= e($key) ?>" class="<?= $k===$key?'on':'' ?>"><?= e($lab) ?></a>
    <?php endforeach; ?>
  </div>
  <div class="panel tile" style="margin-bottom:1rem;max-width:280px"><p class="tag">Total</p><div class="v" style="color:var(--up)"><?= usd(dollars($sum)) ?></div></div>
  <div class="panel"><div class="table-wrap"><table class="ledger">
    <thead><tr><th>When</th><th>Type</th><th>Detail</th><th>Amount</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr><td><?= e(when_fmt($r['at'])) ?></td><td><?= e(kind_label($r['kind'])) ?></td><td class="faint"><?= e($r['note']) ?></td><td style="color:var(--up)">+<?= usd(dollars((int)$r['amount_cents'])) ?></td></tr>
    <?php endforeach; if (!$rows): ?><tr><td colspan="4" class="muted">No <?= $k ? strtolower($kinds[$k]) : 'income' ?> yet.</td></tr><?php endif; ?>
    </tbody>
  </table></div></div>
<?php }

function save_kyc_file(string $field, string $userId): string {
  if (empty($_FILES[$field]['tmp_name']) || !is_uploaded_file($_FILES[$field]['tmp_name'])) return '';
  $info = @getimagesize($_FILES[$field]['tmp_name']);
  if (!$info) throw new RuntimeException('KYC files must be images.');
  $map = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
  if (!isset($map[$info['mime'] ?? ''])) throw new RuntimeException('Use PNG or JPG for KYC.');
  if (($_FILES[$field]['size'] ?? 0) > 5 * 1024 * 1024) throw new RuntimeException('Each KYC image must be under 5 MB.');
  $dir = dirname(__DIR__) . '/uploads/kyc';
  if (!is_dir($dir)) mkdir($dir, 0755, true);
  $rel = '/uploads/kyc/' . preg_replace('/[^A-Z0-9-]/', '', $userId) . '-' . $field . '.' . $map[$info['mime']];
  if (!move_uploaded_file($_FILES[$field]['tmp_name'], dirname(__DIR__) . $rel)) throw new RuntimeException('Could not save the KYC image.');
  return $rel;
}
function page_profile(array $u): void {
  $step = $_GET['step'] ?? '';
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='profile') {
    csrf_check();
    try {
      $usdt = trim($_POST['usdt_address'] ?? '');
      $country = trim($_POST['country'] ?? '');
      if ($usdt !== '' && !preg_match('/^0x[a-fA-F0-9]{40}$/', $usdt)) throw new RuntimeException('USDT address must be 0x plus 40 hex characters.');
      if ($country !== '' && !valid_country($country)) throw new RuntimeException('Select a country from the list.');
      $current = (string)($u['usdt_address'] ?? '');
      $changingWallet = $usdt !== '' && strcasecmp($usdt, $current) !== 0 && $current !== '';
      if ($changingWallet) {
        issue_otp($u['email'], 'wallet', [
          'uid' => $u['id'],
          'name' => trim($_POST['name'] ?? $u['name']),
          'mobile' => trim($_POST['mobile'] ?? ''),
          'country' => $country !== '' ? $country : (string)$u['country'],
          'usdt' => $usdt,
        ]);
        flash('A code was sent to your email. The wallet address changes only after you enter it.');
        redirect('/dashboard/profile/?step=otp');
      }
      $front = save_kyc_file('kyc_front', $u['id']);
      $back = save_kyc_file('kyc_back', $u['id']);
      $kyc = (string)$u['kyc'];
      if ($front !== '' || $back !== '') $kyc = 'submitted';
      db()->prepare('UPDATE users SET name=?, mobile=?, country=?, usdt_address=?, kyc=?, kyc_front=CASE WHEN ?<>"" THEN ? ELSE kyc_front END, kyc_back=CASE WHEN ?<>"" THEN ? ELSE kyc_back END WHERE id=?')
        ->execute([
          trim($_POST['name'] ?? $u['name']),
          trim($_POST['mobile'] ?? ''),
          $country !== '' ? $country : (string)$u['country'],
          $usdt,
          $kyc,
          $front, $front, $back, $back,
          $u['id'],
        ]);
      flash('Profile saved.');
      redirect('/dashboard/profile/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='wallet-otp') {
    csrf_check();
    try {
      $payload = verify_otp($u['email'], 'wallet', trim($_POST['code'] ?? ''));
      if (!$payload || ($payload['uid'] ?? '') !== $u['id']) throw new RuntimeException('That code is wrong or expired.');
      db()->prepare('UPDATE users SET name=?, mobile=?, country=?, usdt_address=? WHERE id=?')
        ->execute([$payload['name'], $payload['mobile'], $payload['country'], $payload['usdt'], $u['id']]);
      flash('Wallet address updated.');
      redirect('/dashboard/profile/');
    } catch (Throwable $e) { flash($e->getMessage(), 'err'); }
  }
  $u = user_by_id($u['id']) ?: $u;
  $sponsor = !empty($u['sponsor_id']) ? user_by_id((string)$u['sponsor_id']) : null;
  ?>
  <div class="page-title"><div><h1>Profile</h1><p class="muted">UID <?= e($u['id']) ?><?php if ($sponsor): ?> · Sponsor <?= e($sponsor['name']) ?> (<?= e($sponsor['id']) ?>)<?php endif; ?></p></div></div>
  <?php if ($step === 'otp'): ?>
  <form method="post" class="panel" style="padding:1.25rem;max-width:560px;display:flex;flex-direction:column;gap:1rem">
    <?= csrf_field() ?><input type="hidden" name="do" value="wallet-otp">
    <p class="muted">Enter the email code to change the payout address.</p>
    <div><label class="label">Email code</label><input class="field" name="code" inputmode="numeric" required></div>
    <button class="btn-brass" style="height:44px">Update wallet address</button>
  </form>
  <?php else: ?>
  <form method="post" enctype="multipart/form-data" class="panel" style="padding:1.25rem;max-width:560px;display:flex;flex-direction:column;gap:1rem">
    <?= csrf_field() ?><input type="hidden" name="do" value="profile">
    <div><label class="label">Name</label><input class="field" name="name" value="<?= e($u['name']) ?>"></div>
    <div><label class="label">Email</label><input class="field" value="<?= e($u['email']) ?>" disabled></div>
    <div><label class="label">Mobile</label><input class="field" name="mobile" value="<?= e($u['mobile']) ?>"></div>
    <div><label class="label">Country</label><?= country_select('country', (string)$u['country']) ?></div>
    <div><label class="label">USDT BEP20 payout address</label><input class="field" name="usdt_address" value="<?= e($u['usdt_address']) ?>" placeholder="0x…"><p class="faint" style="margin-top:.4rem">The first save is immediate. Changing it later emails you a code.</p></div>
    <div><label class="label">KYC front (optional)</label><input class="field" type="file" name="kyc_front" accept="image/png,image/jpeg,image/webp"></div>
    <div><label class="label">KYC back (optional)</label><input class="field" type="file" name="kyc_back" accept="image/png,image/jpeg,image/webp"></div>
    <?php if (!empty($u['kyc_front']) || !empty($u['kyc_back'])): ?><p class="faint">KYC on file: <?= e((string)$u['kyc']) ?>.</p><?php endif; ?>
    <button class="btn-brass" style="height:44px">Save</button>
  </form>
  <?php endif;
}

function page_settings(array $u): void {
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='password') {
    csrf_check();
    $pw = $_POST['password'] ?? '';
    $pw2 = $_POST['confirm'] ?? '';
    if (!password_verify((string)($_POST['current'] ?? ''), $u['password_hash'])) flash('Current login password is wrong.', 'err');
    elseif (strlen($pw) < 8 || $pw !== $pw2) flash('Passwords must match and be at least 8 characters.', 'err');
    else {
      db()->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $u['id']]);
      flash('Password updated.');
      redirect('/dashboard/settings/');
    }
  }
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='tx') {
    csrf_check();
    $u = user_by_id($u['id']) ?: $u;
    $pw = (string)($_POST['tx_password'] ?? '');
    $pw2 = (string)($_POST['tx_confirm'] ?? '');
    $existing = (string)($u['tx_password_hash'] ?? '');
    if ($existing !== '' && !password_verify((string)($_POST['tx_current'] ?? ''), $existing)) flash('Current transaction password is wrong.', 'err');
    elseif (strlen($pw) < 6 || $pw !== $pw2) flash('Transaction passwords must match and be at least 6 characters.', 'err');
    else {
      db()->prepare('UPDATE users SET tx_password_hash=? WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $u['id']]);
      flash('Transaction password saved. Withdrawals will ask for it, then email you a code.');
      redirect('/dashboard/settings/');
    }
  }
  $u = user_by_id($u['id']) ?: $u;
  $hasTx = (string)($u['tx_password_hash'] ?? '') !== '';
  ?>
  <div class="page-title"><div><h1>Passwords</h1><p class="muted">Login password and the separate transaction password used for withdrawals.</p></div></div>
  <div class="grid grid-cols-1 gap-3 lg:grid-cols-2">
    <section class="panel min-w-0 overflow-hidden">
      <div class="border-line flex items-center justify-between gap-4 border-b px-5 py-3"><h2 class="tag text-[0.625rem]">Change login password</h2></div>
      <form method="post" class="p-5 flex flex-col gap-4">
        <?= csrf_field() ?><input type="hidden" name="do" value="password">
        <div><label class="label">Current password</label><input class="field" type="password" name="current" required></div>
        <div><label class="label">New password</label><input class="field" type="password" name="password" required></div>
        <div><label class="label">Confirm</label><input class="field" type="password" name="confirm" required></div>
        <button class="btn-brass h-11">Save password</button>
      </form>
    </section>
    <section class="panel min-w-0 overflow-hidden">
      <div class="border-line flex items-center justify-between gap-4 border-b px-5 py-3"><h2 class="tag text-[0.625rem]"><?= $hasTx ? 'Change transaction password' : 'Set transaction password' ?></h2></div>
      <form method="post" class="p-5 flex flex-col gap-4">
        <?= csrf_field() ?><input type="hidden" name="do" value="tx">
        <?php if ($hasTx): ?><div><label class="label">Current transaction password</label><input class="field" type="password" name="tx_current" required></div><?php endif; ?>
        <div><label class="label">New transaction password</label><input class="field" type="password" name="tx_password" required></div>
        <div><label class="label">Confirm</label><input class="field" type="password" name="tx_confirm" required></div>
        <button class="btn-brass h-11">Save transaction password</button>
      </form>
    </section>
    <section class="panel min-w-0 overflow-hidden">
      <div class="border-line flex items-center justify-between gap-4 border-b px-5 py-3"><h2 class="tag text-[0.625rem]">Active session</h2></div>
      <div class="px-5 py-3">
        <p class="text-[0.875rem]"><?= e(substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown device', 0, 72)) ?></p>
        <p class="text-faint mt-0.5 font-mono text-[0.6875rem]"><?= e($_SERVER['REMOTE_ADDR'] ?? 'ip unknown') ?> · this browser</p>
      </div>
    </section>
  </div>
<?php }

function page_support(array $u): void {
  if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['do']??'')==='ticket') {
    csrf_check();
    $sub = trim($_POST['subject']??''); $body = trim($_POST['body']??'');
    if (strlen($sub)<4 || strlen($body)<8) flash('Subject and message required.', 'err');
    else {
      $id = next_id('TK','ticket',4); $t = now();
      db()->prepare("INSERT INTO tickets (id,user_id,subject,category,status,created_at,updated_at) VALUES (?,?,?,?,'Open',?,?)")
        ->execute([$id,$u['id'],$sub,$_POST['category']??'Other',$t,$t]);
      db()->prepare("INSERT INTO ticket_messages (id,ticket_id,from_role,body,at) VALUES (?,?, 'member', ?, ?)")
        ->execute([next_id('MG','message',5), $id, $body, $t]);
      flash("Ticket $id opened."); redirect('/dashboard/support/');
    }
  }
  $st = db()->prepare('SELECT * FROM tickets WHERE user_id=? ORDER BY updated_at DESC');
  $st->execute([$u['id']]); $tickets = $st->fetchAll();
  ?>
  <div class="page-title"><h1>Support</h1></div>
  <form method="post" class="panel" style="padding:1.25rem;margin-bottom:1rem;display:flex;flex-direction:column;gap:.75rem;max-width:560px">
    <?= csrf_field() ?><input type="hidden" name="do" value="ticket">
    <div><label class="label">Subject</label><input class="field" name="subject" required></div>
    <div><label class="label">Category</label><select class="field" name="category"><option>Deposit</option><option>Withdrawal</option><option>Other</option></select></div>
    <div><label class="label">Message</label><textarea class="field" name="body" rows="4" required></textarea></div>
    <button class="btn-brass" style="height:40px">Open ticket</button>
  </form>
  <?php foreach ($tickets as $t):
    $ms = db()->prepare('SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY at'); $ms->execute([$t['id']]); ?>
    <div class="panel" style="padding:1.25rem;margin-bottom:.75rem">
      <div style="display:flex;justify-content:space-between"><strong><?= e($t['subject']) ?></strong><?= status_pill($t['status']) ?></div>
      <?php foreach ($ms as $m): ?>
        <p class="muted" style="margin-top:.75rem"><span class="tag"><?= $m['from_role']==='desk'?'Desk':'You' ?></span> <?= e($m['body']) ?></p>
      <?php endforeach; ?>
    </div>
  <?php endforeach;
} ?>
