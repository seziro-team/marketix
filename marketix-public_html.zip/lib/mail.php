<?php
function send_mail(string $to, string $subject, string $text): void {
  $c = cfg();
  $host = $c['smtp_host'] ?? 'smtp.hostinger.com';
  $port = (int)($c['smtp_port'] ?? 465);
  $user = $c['from_email'];
  $pass = $c['smtp_password'];
  $from = $c['from_email'];
  $fromName = $c['name'];

  $errno = 0; $errstr = '';
  $fp = stream_socket_client("ssl://{$host}:{$port}", $errno, $errstr, 20, STREAM_CLIENT_CONNECT);
  if (!$fp) throw new RuntimeException("Mail server unavailable ($errstr)");

  $read = function () use ($fp) {
    $data = '';
    while ($line = fgets($fp, 515)) {
      $data .= $line;
      if (isset($line[3]) && $line[3] === ' ') break;
    }
    return $data;
  };
  $cmd = function (string $line, string $expect) use ($fp, $read) {
    fwrite($fp, $line . "\r\n");
    $r = $read();
    if (!str_starts_with($r, $expect)) {
      throw new RuntimeException('Mail error: ' . trim($r));
    }
    return $r;
  };

  $read();
  $cmd('EHLO ' . (cfg()['domain'] ?? 'marketix.ltd'), '250');
  $cmd('AUTH LOGIN', '334');
  $cmd(base64_encode($user), '334');
  $cmd(base64_encode($pass), '235');
  $cmd("MAIL FROM:<{$from}>", '250');
  $cmd("RCPT TO:<{$to}>", '250');
  $cmd('DATA', '354');
  $headers = [
    "From: {$fromName} <{$from}>",
    "To: <{$to}>",
    "Reply-To: {$c['support_email']}",
    "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=",
    "MIME-Version: 1.0",
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: 8bit",
  ];
  fwrite($fp, implode("\r\n", $headers) . "\r\n\r\n" . $text . "\r\n.\r\n");
  $r = $read();
  if (!str_starts_with($r, '250')) throw new RuntimeException('Mail not accepted: ' . trim($r));
  $cmd('QUIT', '221');
  fclose($fp);
}

function send_registration_mail(string $email, string $name, string $login, string $password): void {
  $who = trim($name) !== '' ? trim($name) : 'Member';
  $body = "Registration Info!!!\n\n"
    . "Hello {$who},\n\n"
    . "Thank you for registration on our site.\n\n"
    . "Your login information:\n\n"
    . "Login: {$login}\n"
    . "Password: {$password}\n\n"
    . "You can login here: https://" . (cfg()['domain'] ?? 'marketix.ltd') . "\n\n"
    . "Contact us immediately if you did not authorize this registration.\n\n"
    . "Thank you.";
  send_mail($email, 'Registration Info!!!', $body);
}

function otp_skip_email(string $email): bool {
  $email = strtolower($email);
  return str_ends_with($email, '@example.com');
}

function issue_otp(string $email, string $purpose, array $payload = []): string {
  $email = strtolower($email);
  $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
  db()->prepare('DELETE FROM otps WHERE email=? AND purpose=?')->execute([$email, $purpose]);
  db()->prepare('INSERT INTO otps (email, purpose, code_hash, payload, expires_at, attempts) VALUES (?,?,?,?,?,0)')
    ->execute([$email, $purpose, password_hash($code, PASSWORD_DEFAULT), json_encode($payload), gmdate('c', time() + 600)]);
  if (otp_skip_email($email)) return $code;
  send_mail(
    $email,
    cfg()['name'] . ' code: ' . $code,
    "Your verification code is {$code}.\n\nIt expires in 10 minutes. If you did not request this, ignore the email.\n\n— " . cfg()['name']
  );
  return $code;
}

function verify_otp(string $email, string $purpose, string $code): ?array {
  $email = strtolower($email);
  $st = db()->prepare('SELECT * FROM otps WHERE email=? AND purpose=? ORDER BY id DESC LIMIT 1');
  $st->execute([$email, $purpose]);
  $row = $st->fetch();
  if (!$row) return null;
  if (strtotime($row['expires_at']) < time()) return null;
  if ((int)$row['attempts'] >= 8) return null;
  db()->prepare('UPDATE otps SET attempts = attempts + 1 WHERE id=?')->execute([$row['id']]);
  if (!password_verify($code, $row['code_hash'])) return null;
  db()->prepare('DELETE FROM otps WHERE id=?')->execute([$row['id']]);
  return json_decode($row['payload'] ?: '{}', true) ?: [];
}
