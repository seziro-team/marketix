<?php
function income_streams(): array {
  return [
    ['01', 'Plan interest', 'On an activated package', '8–15%', 'Every 24 hours from activation', 'Interest is credited once each 24 hours from the moment the package is activated. The rate is the plan you chose. There is no profit cap, and the principal stays invested.', [['Plan 1', '8% · $100 – $500'], ['Plan 2', '10% · $600 – $5,000'], ['Plan 3', '12% · $6,000 – $50,000'], ['Plan 4', '15% · $60,000 and above']]],
    ['02', 'Referral', 'On members you introduce', '10%', 'On each activation and reinvest', 'The sponsor receives 10% of the amount a direct member uses to activate or reinvest a package. It is paid into the income wallet. A deposit by itself does not pay the referral.', [['Rate', '10%'], ['When', 'Activation and reinvest'], ['Wallet', 'Available income']]],
    ['03', 'Fund wallet', 'Deposits before a plan', '—', 'Until you activate', 'An approved deposit credits the fund wallet. It does not start interest and it does not pay a referral. You activate a plan from that balance, or from available income when you reinvest.', [['Source', 'Approved USDT deposit'], ['Use', 'Activate a plan'], ['Minimum plan', '$100']]],
    ['04', 'Withdrawal', 'From available income', '10% fee', 'From $10, within 1–2 hours', 'Withdrawals come from income only. The minimum is $10. A 10% fee is deducted. The request needs your transaction password and an email code, then a person releases it within 1–2 hours.', [['Minimum', '$10'], ['Fee', '10%'], ['Principal', 'Stays invested']]],
  ];
}

function page_home(): void {
  $how = [
    ['01', 'Open your account', 'Register with a sponsor ID. The sponsor’s name is shown before you submit. We email your member ID and password, then a code to log in.'],
    ['02', 'Fund the wallet', 'Send USDT on BEP20 and submit the hash. After a person approves it, the amount sits in your fund wallet.'],
    ['03', 'Activate a plan', 'Choose a plan from that balance. Interest is counted 24 hours from the moment the package becomes active.'],
    ['04', 'Withdraw income', 'From $10, income only. A 10% fee applies. Principal stays invested. Released within 1–2 hours after review.'],
  ];
  $facts = [['$100', 'Minimum entry'], ['8–15%', 'After 24 hours'], ['BEP20', 'Settlement network'], ['10%', 'Referral']];
  $spec = [
    ['The book', 'Forex and cryptocurrency'],
    ['Your share', '8%, 10%, 12% or 15% after 24 hours. No profit cap'],
    ['Team income', '10% when a direct member activates or reinvests'],
    ['Settlement', 'USDT on BEP20 only, reviewed by a person'],
  ];
  ?>
  <section class="relative pt-8 pb-12 sm:pt-14">
    <?php shell_open(); ?>
      <div class="grid grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_1.06fr] lg:gap-14">
        <div>
          <span class="border-line bg-panel/50 text-muted inline-flex items-center gap-2.5 rounded-full border px-3 py-1.5 font-mono text-[0.625rem] tracking-[0.12em] uppercase sm:px-3.5 sm:text-[0.6875rem]"><span class="bg-up animate-pulse-dot h-1.5 w-1.5 shrink-0 rounded-full" aria-hidden="true"></span>Forex · Crypto · USDT BEP20</span>
          <h1 class="font-display mt-5 text-[clamp(2.15rem,8vw,4.05rem)] leading-[1] font-extrabold tracking-[-0.035em]">A trading desk you can read <span class="brass-text">line by line</span>.</h1>
          <p class="text-muted mt-5 max-w-[46ch] text-[1rem] leading-relaxed text-pretty sm:text-[1.0625rem]">Marketix Ltd has run since 2016. Allocate from $100 in USDT. Interest of 8% to 15% is counted 24 hours after a package is activated.</p>
          <div class="mt-7 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
            <a href="/register/" class="btn-brass h-12 w-full px-6 text-[0.9375rem] sm:w-auto">Open your account<?= icon('arrow-up-right','h-4 w-4','2.5') ?></a>
            <a href="/investment-plan/" class="btn-ghost h-12 w-full px-6 text-[0.9375rem] font-medium sm:w-auto">See the plans<?= icon('arrow-right','h-4 w-4') ?></a>
          </div>
          <dl class="border-line mt-9 grid grid-cols-2 gap-x-4 gap-y-5 border-t pt-6 sm:grid-cols-4">
            <?php foreach ($facts as $f): ?><div><dd class="font-display num text-xl leading-none font-bold tracking-tight sm:text-2xl"><?= e($f[0]) ?></dd><dt class="tag mt-1.5 text-[0.5625rem] leading-tight sm:text-[0.625rem]"><?= e($f[1]) ?></dt></div><?php endforeach; ?>
          </dl>
        </div>
        <?php hero_terminal(); ?>
      </div>
    <?php shell_close(); ?>
  </section>
  <?php tape_row(); ?>
  <section class="mt-16 sm:mt-24">
    <?php shell_open(); section_head('How it works', 'Four steps to your first statement.', 'A deposit fills the fund wallet. Interest starts only after you activate a plan.'); ?>
      <div class="mt-8 grid grid-cols-2 gap-x-5 gap-y-7 sm:mt-12 lg:grid-cols-4">
        <?php foreach ($how as $s): ?>
          <div class="border-line group h-full border-t pt-4 lg:border-t-0 lg:border-l lg:pt-0 lg:pl-5">
            <span class="text-faint group-hover:text-brass font-mono text-[0.625rem] tracking-[0.2em] transition-colors"><?= e($s[0]) ?></span>
            <h3 class="font-display mt-2 text-[0.9375rem] leading-snug font-bold sm:text-lg"><?= e($s[1]) ?></h3>
            <p class="text-muted mt-1.5 text-[0.8125rem] leading-relaxed text-pretty sm:text-[0.9375rem]"><?= e($s[2]) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php shell_close(); ?>
  </section>
  <section class="mt-16 sm:mt-24">
    <?php shell_open(); ?>
      <div class="grid grid-cols-1 items-center gap-8 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)] lg:gap-14">
        <?php figure('blocks', 'Stacked blocks in blue and teal — the Marketix allocation model', 'aspect-[7/5]', ['priority' => true]); ?>
        <div>
          <?php section_head('What we do', 'Four plans. One wallet. A published schedule.', 'Forex and cryptocurrency, settled only in USDT on BEP20.'); ?>
          <div class="mt-7 grid grid-cols-1">
            <?php foreach ($spec as $i => $r): ?>
              <div class="border-line grid grid-cols-1 gap-0.5 border-b py-3.5<?= $i === 0 ? ' first:border-t' : '' ?> sm:grid-cols-[minmax(0,104px)_minmax(0,1fr)] sm:items-baseline sm:gap-5">
                <span class="tag text-[0.5625rem] sm:text-[0.625rem]"><?= e($r[0]) ?></span>
                <span class="text-[0.9375rem] leading-snug text-pretty sm:text-base"><?= e($r[1]) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    <?php shell_close(); ?>
  </section>
  <section class="mt-16 sm:mt-24" id="plans">
    <?php shell_open(); section_head('Investment plan', 'Four plans, from $100.', 'Interest of 8%, 10%, 12% or 15% is counted 24 hours after activation. Principal stays invested.'); ?>
      <div class="mt-8 sm:mt-12"><?php package_cards(); ?></div>
      <div class="mt-6 flex justify-center"><a href="/investment-plan/" class="text-muted hover:text-brass inline-flex items-center gap-2 font-mono text-[0.6875rem] tracking-[0.14em] uppercase transition-colors">Full plan comparison<?= icon('arrow-right', 'h-3.5 w-3.5') ?></a></div>
    <?php shell_close(); ?>
  </section>
  <section class="mt-16 sm:mt-24">
    <?php shell_open(); section_head('The schedule', 'What each plan pays after 24 hours.', 'One credit per completed 24 hours from activation. Amounts between the bands are not accepted.'); ?>
      <div class="mt-8 sm:mt-12"><?php profit_calculator(); ?></div>
    <?php shell_close(); ?>
  </section>
  <?php figure_band('flows', 'Streams of colour flowing across a dark field', 'mt-16 h-[300px] sm:mt-24 sm:h-[380px] lg:h-[440px]', function () { ?>
    <?php shell_open(); ?>
      <div class="max-w-[34ch]">
        <span class="tag flex items-center gap-2.5"><span class="bg-brass h-[5px] w-[5px]" aria-hidden="true"></span>Business plan</span>
        <h2 class="font-display mt-4 text-[clamp(1.6rem,5.5vw,2.75rem)] leading-[1.05] font-bold">Interest and referral, in the same wallet.</h2>
        <a href="/business-plan/" class="text-brass mt-5 inline-flex items-center gap-2 font-mono text-[0.6875rem] tracking-[0.14em] uppercase">Read the business plan<?= icon('arrow-right', 'h-3.5 w-3.5') ?></a>
      </div>
    <?php shell_close(); ?>
  <?php }); ?>
  <section class="mt-16 sm:mt-24">
    <?php shell_open(); ?>
      <div class="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-12">
        <div class="grid grid-cols-1">
          <div class="border-line flex items-baseline justify-between gap-4 border-b pb-2.5"><span class="tag text-[0.5625rem] sm:text-[0.625rem]">Income line</span><span class="tag text-[0.5625rem] sm:text-[0.625rem]">Rate</span></div>
          <?php foreach (income_streams() as $s): ?>
            <div class="border-line flex items-center justify-between gap-4 border-b py-3.5 sm:py-4">
              <div class="min-w-0">
                <div class="flex items-baseline gap-2.5"><span class="text-faint font-mono text-[0.625rem] tracking-[0.2em]"><?= e($s[0]) ?></span><h3 class="font-display truncate text-[0.9375rem] font-bold sm:text-lg"><?= e($s[1]) ?></h3></div>
                <p class="text-muted mt-1 font-mono text-[0.6875rem] tracking-wide"><?= e($s[4]) ?></p>
              </div>
              <span class="num font-display text-brass shrink-0 text-lg font-bold tracking-tight sm:text-2xl"><?= e($s[3]) ?></span>
            </div>
          <?php endforeach; ?>
          <a href="/business-plan/" class="text-muted hover:text-brass mt-5 inline-flex items-center gap-2 font-mono text-[0.6875rem] tracking-[0.14em] uppercase transition-colors">How each line is calculated<?= icon('arrow-right', 'h-3.5 w-3.5') ?></a>
        </div>
        <div class="min-w-0"><?php referral_panel(); ?></div>
      </div>
    <?php shell_close(); ?>
  </section>
  <section class="mt-16 sm:mt-24">
    <?php shell_open(); section_head('The platform', 'Everything is one login away.', 'Balances, referrals, deposits, withdrawals and your support thread in one dashboard.'); ?>
      <div class="mt-8 sm:mt-12"><?php platform_preview(); ?></div>
    <?php shell_close(); ?>
  </section>
  <section class="mt-16 sm:mt-24">
    <?php shell_open(); section_head('Questions', 'Asked before funding.'); ?>
      <div class="mt-8 grid grid-cols-1 gap-8 sm:mt-10 lg:grid-cols-[minmax(0,0.75fr)_minmax(0,1.45fr)]">
        <?php figure('vault', 'Concentric rings around a lit core, representing custody controls', 'aspect-[3/2]', ['hide' => 'lg']); ?>
        <div><?php faq_block(4); ?><a href="/contact/" class="text-brass mt-6 inline-flex items-center gap-2 font-mono text-[0.6875rem] tracking-[0.14em] uppercase">Ask the desk<?= icon('arrow-right', 'h-3.5 w-3.5') ?></a></div>
      </div>
    <?php shell_close(); ?>
  </section>
  <?php cta_band();
}

function page_about(): void {
  $c = cfg();
  $spec = [
    ['The book', 'Forex and cryptocurrency'],
    ['The share', '8% to 15% after 24 hours, with no profit cap'],
    ['The structure', '10% referral when a direct member activates or reinvests'],
    ['The wallet', 'Deposits sit in the fund wallet until a plan is activated'],
  ];
  $flow = [
    ['01', 'You register', 'With a sponsor ID. The sponsor’s name is confirmed on the form.'],
    ['02', 'You send USDT', 'On BEP20, to the company address, with a hash you can verify.'],
    ['03', 'Desk reviews', 'A person checks it on-chain. Approval credits the fund wallet.'],
    ['04', 'You activate', 'Interest starts 24 hours after the package is activated.'],
    ['05', 'You withdraw', 'Income only, from $10, after a transaction password and an email code.'],
  ];
  $principles = [
    ['wallet', 'Fund wallet, then a plan', 'An approved deposit does not start interest. You activate a package from that balance.'],
    ['link-2', 'USDT on BEP20 only', 'Each deposit and withdrawal uses BNB Smart Chain. Another network will not credit.'],
    ['shield-check', 'A person on both sides', 'Deposits are approved by hand. Withdrawals are released within 1–2 hours after review.'],
    ['waves', 'No profit cap', 'Interest continues every 24 hours. Principal stays invested. Income is what you can withdraw.'],
  ];
  $miles = [
    [(string)$c['founded'], 'Company formed', 'Marketix Ltd is established in the United States.'],
    ['Today', 'Member desk', 'Accounts, fund wallet, plan activation, referral and withdrawals.'],
    ['Today', 'Open enrolment', 'Four plans, from $100, settled in USDT on BEP20.'],
  ];
  $aside = '<div class="panel p-5 sm:p-6"><span class="tag">At a glance</span><dl class="divide-line-soft mt-4 divide-y">';
  foreach ([
    ['Founded', (string)$c['founded']],
    ['Chief executive', $c['ceo']],
    ['Focus', 'Forex and crypto'],
    ['Settlement', 'USDT · BEP20'],
    ['Base', 'New York, United States'],
  ] as $r) {
    $aside .= '<div class="flex items-baseline justify-between gap-4 py-2.5"><dt class="text-muted text-[0.8125rem]">' . e($r[0]) . '</dt><dd class="num text-right font-mono text-[0.8125rem]">' . e($r[1]) . '</dd></div>';
  }
  $aside .= '</dl></div>';
  page_header('About ' . e($c['name']), 'We run one book, in the open.', 'Marketix Ltd is a fully certified, licensed United States company. Members allocate capital. The published schedule credits the same wallet. That is the product.', $aside);
  ?>
  <section class="mt-14 sm:mt-20"><?php shell_open(); ?>
    <div class="grid grid-cols-1 items-center gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] lg:gap-14">
      <div>
        <?php section_head('What we do', 'A desk, not a product catalogue.', 'Our mission is to hold a high standard in financial advisory work: a published plan, a named company, and a person reviewing both sides of the ledger.'); ?>
        <div class="mt-7 grid grid-cols-1">
          <?php foreach ($spec as $r): ?>
            <div class="border-line grid grid-cols-1 gap-0.5 border-b py-3.5 first:border-t sm:grid-cols-[minmax(0,104px)_minmax(0,1fr)] sm:items-baseline sm:gap-5">
              <span class="tag text-[0.5625rem] sm:text-[0.625rem]"><?= e($r[0]) ?></span><span class="text-[0.9375rem] leading-snug text-pretty sm:text-base"><?= e($r[1]) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php figure('desk', 'A bank of trading panels showing charts and order flow', 'aspect-[7/5]', ['priority' => true]); ?>
    </div>
  <?php shell_close(); ?></section>
  <?php figure_band('candles', 'A field of candlesticks receding into fog with a rising trend line', 'mt-14 h-[260px] sm:mt-20 sm:h-[340px]', function () { shell_open(); ?>
    <div class="max-w-[32ch]"><span class="tag flex items-center gap-2.5"><span class="bg-brass h-[5px] w-[5px]" aria-hidden="true"></span>Where the money goes</span><h2 class="font-display mt-3 text-[clamp(1.5rem,5.5vw,2.5rem)] leading-[1.05] font-bold">Two of the five steps are manual on purpose.</h2></div>
  <?php shell_close(); }); ?>
  <section class="mt-10 sm:mt-14"><?php shell_open(); ?>
    <div class="grid grid-cols-2 gap-x-5 gap-y-6 md:grid-cols-3 lg:grid-cols-5">
      <?php foreach ($flow as $s): ?><div class="border-line h-full border-t pt-4"><span class="text-brass font-mono text-[0.625rem] tracking-[0.2em]"><?= e($s[0]) ?></span><h3 class="font-display mt-2 text-[0.9375rem] leading-snug font-bold"><?= e($s[1]) ?></h3><p class="text-muted mt-1.5 text-[0.8125rem] leading-relaxed text-pretty"><?= e($s[2]) ?></p></div><?php endforeach; ?>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-24"><?php shell_open(); ?>
    <div class="grid grid-cols-1 items-center gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] lg:gap-14">
      <?php figure('vault', 'Concentric rings around a lit core, representing custody controls', 'aspect-[3/2]'); ?>
      <div>
        <?php section_head('Our commitments', 'What we hold ourselves to.'); ?>
        <div class="mt-7 grid grid-cols-1 gap-px sm:grid-cols-2">
          <?php foreach ($principles as $p): ?>
            <div class="border-line h-full border-t pt-4 sm:pr-5"><?= icon($p[0], 'text-brass h-[18px] w-[18px]', '1.75') ?><h3 class="font-display mt-3 text-[0.9375rem] leading-snug font-bold"><?= e($p[1]) ?></h3><p class="text-muted mt-1.5 text-[0.8125rem] leading-relaxed text-pretty"><?= e($p[2]) ?></p></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-24"><?php shell_open(); section_head('The company', $c['ceo'] . ', and the certificate.', 'An award-winning multinational company. We believe in quality and standard worldwide.'); ?>
    <div class="mt-8 grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
      <figure class="panel overflow-hidden">
        <img src="/brand/ceo.jpg" alt="<?= e($c['ceo']) ?>, Chief Executive Officer of <?= e($c['name']) ?>" width="1000" height="600" class="block h-auto w-full object-cover" loading="lazy" decoding="async">
        <figcaption class="border-line border-t px-5 py-4"><p class="font-display text-lg font-bold"><?= e($c['ceo']) ?></p><p class="text-muted mt-1 text-[0.875rem]">Chief Executive Officer</p></figcaption>
      </figure>
      <figure class="panel overflow-hidden">
        <img src="/brand/certificate.jpg" alt="Company certificate of <?= e($c['name']) ?>" width="1024" height="575" class="block h-auto w-full bg-white object-contain" loading="lazy" decoding="async">
        <figcaption class="border-line border-t px-5 py-4"><p class="font-display text-lg font-bold">Fully certified and licensed</p><p class="text-muted mt-1 text-[0.875rem] leading-relaxed"><?= e($c['name']) ?> is a United States company, operating since <?= e((string)$c['founded']) ?>, at <?= e($c['address']) ?>.</p></figcaption>
      </figure>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-24"><?php shell_open(); section_head('Timeline', 'How we got here.'); ?>
    <div class="mt-8"><?php foreach ($miles as $m): ?>
      <div class="border-line grid grid-cols-1 gap-1.5 border-b py-4 first:border-t sm:grid-cols-[90px_1fr_1.4fr] sm:gap-8">
        <span class="text-brass font-mono text-[0.8125rem] tracking-[0.14em]"><?= e($m[0]) ?></span>
        <h3 class="font-display text-[0.9375rem] leading-snug font-bold sm:text-base"><?= e($m[1]) ?></h3>
        <p class="text-muted text-[0.875rem] leading-relaxed text-pretty"><?= e($m[2]) ?></p>
      </div>
    <?php endforeach; ?></div>
  <?php shell_close(); ?></section>
  <?php cta_band('Talk to the desk before you fund', 'We would rather answer ten questions than take money from someone who has not read the plan.');
}

function page_investment(): void {
  $c = cfg();
  $aside = '<div class="panel p-5 sm:p-6"><span class="tag">Settlement</span><dl class="divide-line-soft mt-4 divide-y">';
  foreach ([['Token', 'USDT'], ['Network', 'BEP20'], ['Minimum', '$100'], ['Interest', '8% – 15%'], ['Referral', '10%']] as $r) {
    $aside .= '<div class="flex items-baseline justify-between gap-4 py-2.5"><dt class="text-muted text-[0.8125rem]">' . e($r[0]) . '</dt><dd class="num font-mono text-[0.8125rem]">' . e($r[1]) . '</dd></div>';
  }
  $aside .= '</dl><p class="text-faint mt-4 text-[0.75rem] leading-relaxed">BEP20 only. Other networks will not credit.</p></div>';
  page_header('Investment plan', 'Four plans. A published schedule.', 'From $100. Plan 1 pays 8% after 24 hours, up to Plan 4 at 15%. There is no profit cap. Amounts that fall between the bands are not accepted.', $aside);
  $rules = [
    ['Interest', 'Once every 24 hours from the moment the package is activated'],
    ['Bands', '$100–$500 at 8%, $600–$5,000 at 10%, $6,000–$50,000 at 12%, $60,000 and above at 15%'],
    ['Gaps', '$501–$599, $5,001–$5,999 and $50,001–$59,999 are declined'],
    ['Profit cap', 'None. Principal stays invested'],
    ['Deposit', 'Credits the fund wallet. It does not start a plan and does not pay a referral'],
    ['Activation', 'You choose a plan from the fund wallet. That is when the 24 hours begin'],
    ['Referral', '10% of each activation and reinvest, paid to the sponsor’s income'],
    ['Reinvest', 'From available income, into a plan. Referral is paid again'],
    ['Withdrawal minimum', '$10, from income only'],
    ['Withdrawal fee', '10%'],
    ['Release', 'After a transaction password and an email code, within 1–2 hours'],
    ['Network', 'USDT on BEP20 (BNB Smart Chain) only'],
    ['Receiving address', 'The first save is immediate. Changing it needs an email code'],
  ];
  ?>
  <section class="mt-14 sm:mt-20" id="plans"><?php shell_open(); section_head('The plans', 'Four bands. One schedule.', 'Interest is a percentage of the amount you activate, paid every 24 hours.'); ?>
    <div class="mt-8 sm:mt-12"><?php package_cards(true); ?></div>
  <?php shell_close(); ?></section>
  <?php figure_band('candles', 'A field of candlesticks receding into fog beneath a rising trend line', 'mt-14 h-[240px] sm:mt-24 sm:h-[320px]', function () { shell_open(); ?>
    <div class="max-w-[30ch]"><span class="tag">Schedule</span><h2 class="font-display mt-3 text-[clamp(1.5rem,4vw,2.2rem)] font-bold">One credit, every 24 hours.</h2></div>
  <?php shell_close(); }); ?>
  <section class="mt-14 sm:mt-20"><?php shell_open(); section_head('Worked examples', 'The rate, applied once.'); ?>
    <div class="mt-8 sm:mt-12"><?php profit_calculator(); ?></div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-20"><?php shell_open(); ?>
    <div class="grid grid-cols-1 gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      <div>
        <?php section_head('The bands', 'Four packages.'); ?>
        <div class="mt-8 table-wrap"><table class="ledger w-full"><thead><tr><th>Plan</th><th>Amount</th><th class="text-right">After 24 hours</th></tr></thead><tbody>
          <?php foreach (plan()['plans'] as $s):
            $max = $s['max'] === null ? 'Unlimited' : ('$' . number_format((float)$s['max'], 0));
          ?>
            <tr><td class="font-medium"><?= e($s['name']) ?></td><td class="font-mono">$<?= number_format((float)$s['min'], 0) ?> – <?= e($max) ?></td><td class="text-brass text-right font-mono"><?= (int)$s['daily'] ?>%</td></tr>
          <?php endforeach; ?>
        </tbody></table></div>
        <p class="text-faint mt-4 text-[0.8125rem] leading-relaxed">You can hold more than one package. Each one keeps its own 24-hour clock from the time it was activated. Principal is not withdrawn. Income is.</p>
      </div>
      <div class="panel p-0">
        <div class="border-line border-b px-5 py-3"><span class="tag">Payout rules</span></div>
        <dl class="divide-line-soft divide-y"><?php foreach ($rules as $r): ?><div class="px-5 py-3"><dt class="tag text-[0.5625rem]"><?= e($r[0]) ?></dt><dd class="mt-1 text-[0.875rem]"><?= e($r[1]) ?></dd></div><?php endforeach; ?></dl>
      </div>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-20"><?php shell_open(); ?>
    <div class="grid grid-cols-1 items-center gap-8 lg:grid-cols-2">
      <?php figure('globe', 'A network of members', 'aspect-[4/3]', ['hide' => 'lg']); ?>
      <div><?php section_head('How a package starts', 'Deposit, then activate.', 'Sending USDT only fills the fund wallet. You open a plan from that balance. The sponsor is paid 10% at that moment, not when the deposit arrives. Reinvesting from income starts another package and pays the referral again.'); ?></div>
    </div>
  <?php shell_close(); ?></section>
  <?php cta_band();
}

function page_business(): void {
  $aside = '<div class="panel p-6"><span class="tag">Structure</span><dl class="divide-line-soft mt-4 divide-y">';
  foreach ([
    ['Plans', 'Four bands'],
    ['Interest', '8% – 15% / 24h'],
    ['Referral', '10% direct'],
    ['Direct members', 'Unlimited'],
    ['Profit cap', 'None'],
    ['Withdrawal', 'Income · 10% fee'],
  ] as $r) {
    $aside .= '<div class="flex items-baseline justify-between gap-4 py-2.5"><dt class="text-muted text-[0.8125rem]">' . e($r[0]) . '</dt><dd class="num text-right font-mono text-[0.8125rem]">' . e($r[1]) . '</dd></div>';
  }
  $aside .= '</dl></div>';
  page_header('Business plan', 'Interest on your capital,<br class="hidden sm:block"> plus a direct referral.', 'Your package earns 8% to 15% every 24 hours. A direct member’s activation or reinvest pays you 10%, into the same income wallet.', $aside);
  $rules = [
    ['Interest clock', '24 hours from package activation, then every 24 hours'],
    ['Referral', '10% of a direct member’s activation or reinvest'],
    ['Deposit', 'Fund wallet only, until you activate'],
    ['Top up a member', 'Move at least $1 from your fund wallet to another member’s fund wallet. An email code is required'],
    ['Reinvest', 'From available income. Referral is paid to your sponsor'],
    ['Withdrawal minimum', '$10, income only'],
    ['Withdrawal fee', '10%'],
    ['Release', 'Within 1–2 hours after the transaction password and email code'],
    ['Principal', 'Stays invested'],
    ['Network', 'USDT on BEP20 only'],
    ['Receiving address', 'First save is immediate. A change needs an email code'],
    ['Active', 'A member with a package that is currently earning'],
  ];
  ?>
  <section class="mt-14 sm:mt-20"><?php shell_open(); section_head('Income lines', 'Where every credit in your wallet comes from.'); ?>
    <div class="mt-8 grid grid-cols-1 gap-4 sm:mt-12 lg:grid-cols-2">
      <?php foreach (income_streams() as $s): ?>
        <div class="panel panel-lift flex h-full flex-col p-5">
          <div class="flex items-baseline justify-between gap-4"><span class="text-faint font-mono text-[0.625rem] tracking-[0.2em]"><?= e($s[0]) ?></span><span class="num text-brass font-display text-xl font-bold"><?= e($s[3]) ?></span></div>
          <h3 class="font-display mt-3 text-lg font-bold"><?= e($s[1]) ?></h3>
          <p class="text-muted mt-1 text-[0.8125rem]"><?= e($s[2]) ?> · <?= e($s[4]) ?></p>
          <p class="text-muted mt-4 text-[0.9375rem] leading-relaxed"><?= e($s[5]) ?></p>
          <dl class="divide-line-soft border-line mt-auto divide-y border-t pt-2"><?php foreach ($s[6] as $d): ?><div class="flex items-baseline justify-between gap-4 py-2"><dt class="text-muted text-[0.8125rem]"><?= e($d[0]) ?></dt><dd class="num text-right font-mono text-[0.8125rem]"><?= e($d[1]) ?></dd></div><?php endforeach; ?></dl>
        </div>
      <?php endforeach; ?>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-16 sm:mt-24"><?php shell_open(); ?>
    <div class="grid grid-cols-1 items-center gap-10 lg:grid-cols-2">
      <div><?php section_head('Referral', 'Ten percent, once per activation.', 'Introduce a member with your link. When they activate a package, or reinvest, 10% of that amount is credited to your income wallet. Their deposit, before activation, pays nothing.'); ?></div>
      <?php referral_panel(); ?>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-16 sm:mt-24" id="plans"><?php shell_open(); ?>
    <div class="grid grid-cols-1 gap-8 lg:grid-cols-2">
      <div>
        <?php section_head('The four plans', 'Same bands as the investment page.'); ?>
        <div class="table-wrap"><table class="ledger mt-8 w-full"><thead><tr><th>Plan</th><th>Amount</th><th class="text-right">24h</th></tr></thead><tbody>
          <?php foreach (plan()['plans'] as $s):
            $max = $s['max'] === null ? 'Unlimited' : ('$' . number_format((float)$s['max'], 0));
          ?>
            <tr><td><?= e($s['name']) ?></td><td class="font-mono">$<?= number_format((float)$s['min'], 0) ?> – <?= e($max) ?></td><td class="text-brass text-right font-mono"><?= (int)$s['daily'] ?>%</td></tr>
          <?php endforeach; ?>
        </tbody></table></div>
      </div>
      <div>
        <?php section_head('Two balances', 'Fund wallet and income.'); ?>
        <div class="border-line mt-8 divide-y divide-[var(--color-line-soft)] border-t">
          <?php foreach ([
            ['Fund wallet', 'Approved deposits land here. Activate a plan from it, or send at least $1 to another member’s fund wallet.'],
            ['Available income', 'Interest and referral land here. Withdraw from $10, or reinvest into a plan.'],
            ['Total withdrawn', 'The sum of withdrawal requests that are pending or already released.'],
            ['Principal', 'Stays in the package. It is not part of a withdrawal.'],
          ] as $row): ?>
            <div class="py-4"><p class="font-display text-[0.9375rem] font-bold"><?= e($row[0]) ?></p><p class="text-muted mt-1 text-[0.875rem] leading-relaxed"><?= e($row[1]) ?></p></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-16 sm:mt-24"><?php shell_open(); section_head('Standing rules', 'How money leaves the desk.'); ?>
    <div class="mt-8 grid grid-cols-1 gap-px sm:grid-cols-2"><?php foreach ($rules as $r): ?><div class="border-line border-t py-4 sm:pr-8"><p class="tag text-[0.5625rem]"><?= e($r[0]) ?></p><p class="mt-1.5 text-[0.9375rem]"><?= e($r[1]) ?></p></div><?php endforeach; ?></div>
  <?php shell_close(); ?></section>
  <?php cta_band();
}

function page_contact(): void {
  $c = cfg();
  $aside = '<div class="panel p-6"><span class="tag flex items-center gap-2">' . icon('clock', 'h-3.5 w-3.5') . 'Support hours</span><p class="font-display mt-3 text-lg font-bold">' . e($c['hours']) . '</p><p class="text-muted mt-3 text-[0.875rem] leading-relaxed">The desk is open around the clock. A reply is sent within 24 hours. Withdrawals are released within 1–2 hours after review.</p></div>';
  page_header('Contact us', 'Ask before you fund.', 'Questions about a package, a deposit that has not credited, or a withdrawal in review — all of it reaches the same desk.', $aside);
  ?>
  <section class="mt-12 sm:mt-16"><?php shell_open(); ?>
    <div class="grid grid-cols-1 gap-px sm:grid-cols-2">
      <a href="mailto:<?= e($c['support_email']) ?>" class="block h-full"><div class="panel panel-lift h-full p-6"><?= icon('mail', 'text-brass h-5 w-5') ?><p class="tag mt-4">Email</p><p class="mt-1.5 text-[0.9375rem] font-medium break-words"><?= e($c['support_email']) ?></p><p class="text-faint mt-2 text-[0.8125rem] leading-relaxed">Documents and account queries</p></div></a>
      <a href="tel:<?= e($c['phone_tel']) ?>" class="block h-full"><div class="panel panel-lift h-full p-6"><?= icon('phone', 'text-brass h-5 w-5') ?><p class="tag mt-4">Phone</p><p class="mt-1.5 text-[0.9375rem] font-medium break-words"><?= e($c['phone']) ?></p><p class="text-faint mt-2 text-[0.8125rem] leading-relaxed"><?= e($c['hours']) ?></p></div></a>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-20"><?php shell_open(); section_head('Send an enquiry', 'Tell us what you need to know.', 'The form is sent to ' . e($c['support_email']) . ' from ' . e($c['from_email']) . '.'); ?>
    <div class="mt-8 grid grid-cols-1 gap-4 sm:mt-12 lg:grid-cols-[1.5fr_1fr]">
      <form method="post" class="panel p-6 sm:p-8">
        <?= csrf_field() ?>
        <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <div><label class="label" for="c-name">Full name</label><input id="c-name" name="name" class="field" placeholder="Your name" required></div>
          <div><label class="label" for="c-email">Email</label><input id="c-email" name="email" type="email" class="field" placeholder="you@example.com" required></div>
          <div class="sm:col-span-2"><label class="label" for="c-interest">Interested in</label>
            <select id="c-interest" name="interest" class="field"><option value="">Select a plan</option><?php foreach (bfx_packages() as $pk): ?><option value="<?= e($pk['name']) ?>"><?= e($pk['name']) ?> · <?= e($pk['headline']) ?></option><?php endforeach; ?><option value="General question">General question</option></select>
          </div>
        </div>
        <div class="mt-5"><label class="label" for="c-message">Message</label><textarea id="c-message" name="message" rows="5" class="field resize-y" required></textarea></div>
        <button class="btn-brass mt-6 h-12 w-full text-[0.9375rem]">Send to <?= e($c['support_email']) ?></button>
        <p class="text-faint mt-4 text-[0.75rem] leading-relaxed">Goes to the desk from <?= e($c['from_email']) ?>. We reply within 24 hours.</p>
      </form>
      <div class="flex h-full flex-col gap-4">
        <div class="panel p-6"><span class="tag flex items-center gap-2"><?= icon('map-pin', 'h-3.5 w-3.5') ?>Office</span><address class="mt-4 text-[0.9375rem] leading-relaxed not-italic"><?= e($c['address_street']) ?><br><?= e($c['address_city']) ?>, <?= e($c['address_region']) ?> <?= e($c['address_postal']) ?><br><?= e($c['address_country']) ?></address></div>
        <div class="panel p-6">
          <span class="tag">Also on</span>
          <div class="mt-4 flex flex-col gap-3">
            <a href="<?= e($c['telegram']) ?>" class="text-porcelain hover:text-brass inline-flex items-center gap-2 text-[0.9375rem]" target="_blank" rel="noopener"><?= icon('share-2', 'h-4 w-4') ?>Telegram <?= e($c['telegram_handle']) ?></a>
            <a href="<?= e($c['whatsapp']) ?>" class="text-porcelain hover:text-brass inline-flex items-center gap-2 text-[0.9375rem]" target="_blank" rel="noopener" aria-label="WhatsApp"><svg class="h-4 w-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.5 3.5A11 11 0 0 0 2.1 16.8L1 23l6.4-1.1A11 11 0 0 0 20.5 3.5zM12 20.2a8.2 8.2 0 0 1-4.2-1.1l-.3-.2-3.8.6.6-3.7-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.4-.7-1.6-.8s-.4-.1-.5.1-.6.8-.7.9-.3.2-.5.1a6.7 6.7 0 0 1-2-1.2 7.4 7.4 0 0 1-1.4-1.7c-.1-.2 0-.4.1-.5l.4-.4.2-.3c.1-.1.1-.2.2-.3s0-.2 0-.4c0-.1-.5-1.3-.7-1.8s-.4-.4-.5-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 12 12 0 0 0 4.5 4c.5.2 1 .4 1.5.5a3.6 3.6 0 0 0 1.7.1 2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.2-.1-.4-.2z"/></svg>WhatsApp</a>
            <a href="/login/" class="text-porcelain hover:text-brass inline-flex items-center gap-2 text-[0.9375rem]"><?= icon('life-buoy', 'h-4 w-4') ?>Support ticket, after login</a>
          </div>
        </div>
        <div class="panel p-6"><span class="tag">Before you write in</span><ul class="mt-4 flex flex-col gap-3"><?php foreach (['Deposit not credited? Have the transaction hash ready.', 'Withdrawal pending? The release goes to the USDT address saved on your profile.', 'Changing a saved receiving address needs an email code. The first time you save one, it does not.'] as $t): ?><li class="text-muted flex gap-2.5 text-[0.875rem] leading-relaxed"><span class="bg-brass mt-2 h-1 w-1 shrink-0" aria-hidden="true"></span><?= e($t) ?></li><?php endforeach; ?></ul></div>
        <div class="panel bg-brass/[0.06] border-brass/30 p-6"><span class="tag text-brass">Security note</span><p class="text-muted mt-3 text-[0.875rem] leading-relaxed"><?= e($c['name']) ?> will never ask for your wallet seed phrase, private key or password. Any message that does is not from us — report it to <a href="mailto:<?= e($c['support_email']) ?>" class="text-brass underline underline-offset-2"><?= e($c['support_email']) ?></a>.</p></div>
      </div>
    </div>
  <?php shell_close(); ?></section>
  <section class="mt-14 sm:mt-24"><?php shell_open(); section_head('Quick answers', 'Most questions land here first.'); ?>
    <div class="mt-10 max-w-[860px]"><?php faq_block(); ?></div>
  <?php shell_close(); ?></section>
<?php }

function page_legal_doc(string $tag, string $title, string $lede, string $updated, string $asideLede, array $clauses): void {
  $aside = '<div class="panel p-6"><span class="tag">Last updated</span><p class="font-display num mt-2 text-lg font-bold">' . e($updated) . '</p><p class="text-faint mt-3 text-[0.8125rem] leading-relaxed">' . e($asideLede) . '</p></div>';
  page_header($tag, $title, $lede, $aside);
  ?>
  <section class="mt-12 mb-8 sm:mt-16">
    <?php shell_open(); ?>
      <div class="grid grid-cols-1 gap-12 lg:grid-cols-[220px_1fr]">
        <nav aria-label="On this page" class="hidden lg:block">
          <p class="tag mb-4">Contents</p>
          <ol class="flex flex-col gap-2.5">
            <?php foreach ($clauses as $i => $c): ?>
              <li>
                <a href="#c<?= $i + 1 ?>" class="text-muted hover:text-brass flex gap-2.5 text-[0.8125rem] leading-snug transition-colors">
                  <span class="text-faint shrink-0 font-mono text-[0.6875rem]"><?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
                  <?= e($c['h']) ?>
                </a>
              </li>
            <?php endforeach; ?>
          </ol>
        </nav>
        <div>
          <?php foreach ($clauses as $i => $c): ?>
            <section id="c<?= $i + 1 ?>" class="border-line scroll-mt-28 border-t py-8 first:border-t-0 first:pt-0">
              <h2 class="font-display flex gap-3 text-[1.25rem] leading-snug font-bold">
                <span class="text-brass mt-1 font-mono text-[0.75rem] tracking-widest"><?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
                <?= e($c['h']) ?>
              </h2>
              <div class="mt-4 flex flex-col gap-3.5 pl-0 sm:pl-9">
                <?php foreach ($c['p'] as $para): ?>
                  <p class="text-muted text-[0.9375rem] leading-relaxed text-pretty"><?= e($para) ?></p>
                <?php endforeach; ?>
              </div>
            </section>
          <?php endforeach; ?>
        </div>
      </div>
    <?php shell_close(); ?>
  </section>
<?php }

function page_terms(): void {
  $c = cfg();
  page_legal_doc(
    'Terms of service',
    'The rules of membership.',
    'What you agree to when you open an account on ' . $c['domain'] . ', and how deposits, plans, interest, referral and withdrawals work.',
    '4 November 2026',
    'These terms describe the account, the four plans, USDT on BEP20, and the published schedule.',
    [
      ['h' => 'Who these terms are between', 'p' => [
        'These terms govern your use of ' . $c['domain'] . ' and your membership of ' . $c['name'] . ' (“' . $c['name'] . '”, “we”, “us”), a United States company at ' . $c['address'] . '. By registering an account you accept them.',
        'If you do not accept them, do not register and do not send funds.',
      ]],
      ['h' => 'Eligibility', 'p' => [
        'You must be at least 18 years old and legally able to enter into a contract where you live.',
        'You confirm that this membership, including referral income, is lawful where you live. We may decline or close an account where we believe it is not.',
        'One person may hold one account. Accounts opened to manufacture referral volume may be closed and that income reversed.',
      ]],
      ['h' => 'Opening an account', 'p' => [
        'Registration needs a full name, an email address, a country, a password, a sponsor ID, and acceptance of these terms and the privacy policy. A mobile number is optional.',
        'The sponsor’s name is shown before you submit, so you can see whose team you are joining. Member IDs are in the form MTX-……. We email a one-time code from ' . $c['from_email'] . '. After that code is verified, the member ID is issued and we email the member ID and password to the address you registered.',
        'Login and password reset also use an email code. We will never ask for your password, wallet seed phrase or private key.',
      ]],
      ['h' => 'Account status', 'p' => [
        'An account that has completed the email code can sign in. That is not the same as an active plan.',
        'On the dashboard, Active means the member has a package that is currently earning. A member who has only registered, or who has no earning package, shows as Inactive.',
        'We may suspend or reinstate an account. A suspended account cannot use the desk until it is reinstated.',
      ]],
      ['h' => 'Deposits', 'p' => [
        'Deposits are accepted in USDT on BEP20 (BNB Smart Chain) only, to the company address shown in your dashboard. Another token, or USDT on another network, will not credit and cannot be recovered by us.',
        'The minimum deposit is $100. You submit the amount and the transaction hash. A person verifies the hash and approves or declines it. Approval credits your fund wallet. It does not open a plan, it does not start interest, and it does not pay a referral.',
      ]],
      ['h' => 'Plans', 'p' => [
        'You activate a plan from the fund wallet. The bands are: Plan 1, $100 to $500 at 8%; Plan 2, $600 to $5,000 at 10%; Plan 3, $6,000 to $50,000 at 12%; Plan 4, $60,000 and above at 15%. Amounts from $501 to $599, $5,001 to $5,999, and $50,001 to $59,999 are not accepted.',
        'Interest is credited once every 24 hours, counted from the moment that package is activated. There is no profit cap. Principal stays invested.',
        'Reinvesting uses available income and opens another package on the same rules. You may hold more than one package. Each keeps its own clock.',
      ]],
      ['h' => 'Referral', 'p' => [
        'The sponsor receives 10% of the amount a direct member uses to activate a package, and 10% again if that member reinvests. It is credited to the sponsor’s income wallet.',
        'A deposit that has not yet been used to activate a package does not pay the referral.',
        'You may also move at least $1 from your fund wallet to another member’s fund wallet. That transfer needs an email code. It credits their fund wallet. It is not a plan and it does not pay a referral.',
        'When you introduce a member you must describe the plan as it is published on this website.',
      ]],
      ['h' => 'Withdrawals', 'p' => [
        'Withdrawals are taken from available income. Principal is not withdrawn. The minimum is $10. A 10% fee is deducted from the amount you request.',
        'A withdrawal needs your transaction password and then an email code. A person reviews it and releases it to the USDT BEP20 address on your profile, within 1–2 hours.',
        'The first time you save a receiving address, it is stored immediately. Changing a saved address needs an email code. Withdrawals go only to the address on the profile.',
        'We may pause a withdrawal while we look into a security concern or a legal request, and we will tell you when we do.',
      ]],
      ['h' => 'Your details', 'p' => [
        'You are responsible for the name, email, optional mobile number, country and USDT address on your profile, and for keeping your login and transaction passwords secret.',
        'Optional identity documents, a front and a back, can be uploaded from settings. They are stored for review and are not shown on the public site.',
      ]],
      ['h' => 'Conduct', 'p' => [
        'You must not use the platform for money laundering, sanctions evasion, or on behalf of an undisclosed third party.',
        'You must not attempt to interfere with the platform or access another member’s account.',
        'You must not use the ' . $c['name'] . ' name or logo to make claims we have not published.',
      ]],
      ['h' => 'Suspension and closure', 'p' => [
        'We may suspend or close an account that breaches these terms, and may reverse referral income that came from the breach.',
        'You may ask to close your account by writing to ' . $c['support_email'] . '. Credited income can be withdrawn on the published terms. Principal stays in the package.',
      ]],
      ['h' => 'Support and reports', 'p' => [
        'Member support is ' . $c['support_email'] . ', ' . $c['phone'] . ', Telegram ' . $c['telegram_handle'] . ', and the ticket desk inside your dashboard. Hours are ' . $c['hours'] . '.',
        'To report fraud, impersonation or a grievance about the website itself, use Report to developer in the footer. That form is emailed to ' . report_email() . '.',
      ]],
      ['h' => 'Changes and disputes', 'p' => [
        'We may update these terms. The date at the top of this page is the current version. Continuing to use the platform after a change is acceptance of that version.',
        'Raise a membership dispute first by writing to ' . $c['support_email'] . '. Governing law is the law of the State of New York, United States, without regard to conflict-of-law rules.',
      ]],
    ]
  );
}

function page_privacy(): void {
  $c = cfg();
  page_legal_doc(
    'Privacy policy',
    'What we hold about you.',
    'The data ' . $c['domain'] . ' needs to run your account, why it needs it, who sees it, and what you can ask us to do with it.',
    '4 November 2026',
    'This policy matches the forms, emails and dashboards on ' . $c['domain'] . '.',
    [
      ['h' => 'Who controls your data', 'p' => [
        $c['name'] . ', at ' . $c['address'] . ', is the controller of the personal data described here. Write to ' . $c['support_email'] . ' with any question about it.',
      ]],
      ['h' => 'What we collect', 'p' => [
        'Account details you give us at registration: full name, email address, country, password (stored as a hash), optional mobile number, and the sponsor ID.',
        'Profile details you add later: USDT BEP20 receiving address, transaction password (stored as a hash), and optional identity images (front and back).',
        'Financial records: deposits, hashes, fund-wallet movements, plan activations, interest, referral, reinvests and withdrawals.',
        'Team data: who introduced you, and the members who joined on your link.',
        'Support data: tickets you open, and enquiries from the contact page (name, email, interest, message).',
        'Developer reports: name, optional contact number and description, submitted through Report to developer.',
        'Security data: one-time codes (stored as hashes, with a short expiry), the session cookie, IP address and browser type.',
      ]],
      ['h' => 'Why we collect it', 'p' => [
        'To open and operate your account, send email codes, credit interest and referral, and process deposits and withdrawals.',
        'To check that a deposit reached the company address and that a withdrawal is going to the address on your profile.',
        'To show Active only when you have a package that is earning.',
        'To calculate the 10% referral from a direct member’s activation or reinvest.',
        'To reply to support and to let the desk review a fraud or misuse report.',
      ]],
      ['h' => 'Emails we send', 'p' => [
        'One-time codes, the registration message with your member ID and password, and contact-form copies are sent from ' . $c['from_email'] . '.',
        'Member support replies come from ' . $c['support_email'] . '.',
        'Developer reports are sent to ' . report_email() . '. That mailbox is not used for marketing.',
      ]],
      ['h' => 'What is visible to other members', 'p' => [
        'Your sponsor can see your name, member ID, whether you are Active, and the package you activated, because that is what the referral is calculated from.',
        'They cannot see your email, password, wallet address, transaction hashes or ticket history.',
      ]],
      ['h' => 'Who else sees it', 'p' => [
        'The hosting provider that runs ' . $c['domain'] . ' and stores the database, and the email provider that sends mail from ' . $c['from_email'] . '.',
        'The address ' . report_email() . ', when you submit a Report to developer form.',
        'Public blockchains: a deposit or withdrawal on BNB Smart Chain is permanently public. We cannot delete it.',
        'Authorities, where the law requires disclosure. We do not sell personal data and we do not share it with advertisers.',
      ]],
      ['h' => 'How long we keep it', 'p' => [
        'Account and ledger records are kept while the account is open and for a further period where record-keeping law requires it.',
        'One-time codes are removed when they are used or when they expire.',
        'Identity images are kept while they are useful for the review you asked for.',
        'The session cookie lasts for the signed-in period you chose.',
      ]],
      ['h' => 'Security', 'p' => [
        'Deposit approval and withdrawal release are manual steps. Changing a saved receiving address needs an email code. The connection is protected in transit.',
        'Use a unique password. Write to ' . $c['support_email'] . ' immediately if you think someone else has used your account.',
      ]],
      ['h' => 'Your rights', 'p' => [
        'You can ask for a copy of your data, ask us to correct it, and ask us to delete it where we are not required to keep it.',
        'You can edit most of your profile from the dashboard. Write to ' . $c['support_email'] . ' to exercise any other right.',
      ]],
      ['h' => 'Cookies', 'p' => [
        'We use cookies that are necessary to keep you signed in, to remember a sponsor ID if you arrived on a referral link, and to protect forms. We do not use advertising cookies and we do not embed a language translator.',
        'Blocking cookies in your browser means the dashboard cannot keep you signed in.',
      ]],
      ['h' => 'Changes', 'p' => [
        'If this policy changes we update the date at the top of this page. Continuing to use ' . $c['domain'] . ' after that is acceptance of the current version.',
      ]],
    ]
  );
}

function handle_report(): void {
  csrf_check();
  $return = (string)($_POST['return'] ?? '/');
  if ($return === '' || $return[0] !== '/' || str_starts_with($return, '//') || str_contains($return, "\n") || str_contains($return, "\r")) {
    $return = '/';
  }
  if (!empty($_POST['website'])) {
    redirect($return);
  }
  $name = trim((string)($_POST['name'] ?? ''));
  $phone = trim((string)($_POST['phone'] ?? ''));
  $details = trim((string)($_POST['details'] ?? ''));
  $phoneDigits = preg_replace('/\D+/', '', $phone) ?? '';
  $reopen = (str_contains($return, '?') ? '&' : '?') . 'report=1';
  if (strlen($name) < 2 || strlen($details) < 20) {
    flash('Name and a description of the issue are required.', 'err');
    redirect($return . $reopen);
  }
  if ($phone !== '' && strlen($phoneDigits) < 8) {
    flash('If you add a contact number, use a working one.', 'err');
    redirect($return . $reopen);
  }
  $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
  $st = db()->prepare('SELECT COUNT(*) FROM reports WHERE ip = ? AND created_at > ?');
  $st->execute([$ip, gmdate('c', time() - 300)]);
  if ((int)$st->fetchColumn() >= 3) {
    flash('Please wait a few minutes before sending another report.', 'err');
    redirect($return . $reopen);
  }
  db()->prepare('INSERT INTO reports (name, phone, details, ip, created_at) VALUES (?,?,?,?,?)')
    ->execute([$name, $phone, $details, $ip, now()]);
  $when = (new DateTime('now', tz()))->format('d M Y, H:i') . ' IST';
  $domain = cfg()['domain'];
  $body = "A visitor filed a report on {$domain}.\n\n"
    . "Name: {$name}\n"
    . "Contact: " . ($phone !== '' ? $phone : '—') . "\n"
    . "IP: {$ip}\n"
    . "When: {$when}\n"
    . "Page: {$return}\n\n"
    . "--- Report ---\n{$details}\n";
  try {
    send_mail(report_email(), cfg()['name'] . ' report — ' . $name, $body);
    flash('Report sent.');
  } catch (Throwable $e) {
    flash('Saved, but the report could not be sent. Please try again.', 'err');
  }
  redirect($return);
}

function page_not_found(): void { ?>
  <?= backdrop() ?>
  <main class="mx-auto flex min-h-screen max-w-[720px] flex-col justify-center px-6 py-20">
    <a href="/" aria-label="<?= e(cfg()['name']) ?> home" class="w-fit"><?= logo() ?></a>
    <p class="tag mt-14 flex items-center gap-2.5"><span class="bg-brass h-[5px] w-[5px]" aria-hidden="true"></span>Error 404</p>
    <h1 class="font-display mt-5 text-[clamp(2.2rem,5vw,3.4rem)] leading-[1.02] font-extrabold tracking-[-0.035em]">That page isn’t on the ledger.</h1>
    <p class="text-muted mt-5 max-w-[52ch] text-[1.0625rem] leading-relaxed">The address you followed doesn’t match anything here. It may have moved, or the link may have been mistyped.</p>
    <nav class="border-line mt-10 border-t pt-6"><p class="tag mb-4">Try one of these</p><ul class="flex flex-col">
      <?php foreach (bfx_nav() as $n): ?><li><a href="<?= e($n[1]) ?>" class="border-line-soft text-muted hover:text-brass flex items-center justify-between border-b py-3 text-[0.9375rem] transition-colors"><?= e($n[0]) ?><span class="text-faint font-mono text-[0.6875rem]"><?= e($n[1]) ?></span></a></li><?php endforeach; ?>
    </ul></nav>
    <a href="/" class="btn-brass mt-8 h-11 w-fit px-5 text-[0.9375rem]"><?= icon('arrow-left', 'h-4 w-4') ?>Back to the home page</a>
  </main>
<?php }
