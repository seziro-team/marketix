<?php
function auth_shell(string $side, string $title, string $lede, string $footer, callable $inner): void {
  $facts = $side === 'login'
    ? [['$100','Minimum entry'],['8–15%','Interest / 24 hours'],['BEP20','USDT only'],['10%','Referral']]
    : [['$100','Minimum entry'],['8–15%','Interest / 24 hours'],['BEP20','USDT only'],['10%','Referral']];
  $h2 = $side === 'login' ? 'Your desk, your ledger, one login.' : 'Open the account. Read every line.';
  $p = $side === 'login'
    ? 'Fund wallet, packages, withdrawals and your support thread — all in one place.'
    : 'Registration takes a few minutes. We email your login, then you can fund in USDT on BEP20.';
  document_start($title, ['robots' => 'noindex, follow']);
  echo backdrop();
  ?>
  <div class="grid min-h-screen grid-cols-1 lg:grid-cols-[1fr_1.15fr]">
    <aside class="border-line relative hidden flex-col justify-between overflow-hidden border-r p-10 lg:flex xl:p-14">
      <span class="pointer-events-none absolute inset-0 -z-10" style="background:radial-gradient(90% 60% at 0% 0%, rgba(56,189,248,0.18), transparent 60%)" aria-hidden="true"></span>
      <a href="/" aria-label="<?= e(cfg()['name']) ?> home"><?= logo() ?></a>
      <div>
        <h2 class="font-display max-w-[16ch] text-[clamp(1.9rem,3vw,2.7rem)] leading-[1.04] font-extrabold tracking-[-0.035em]"><?= e($h2) ?></h2>
        <p class="text-muted mt-5 max-w-[42ch] text-[0.9375rem] leading-relaxed text-pretty"><?= e($p) ?></p>
        <dl class="border-line mt-10 grid grid-cols-2 gap-y-6 border-t pt-8">
          <?php foreach ($facts as $f): ?><div><dd class="font-display num text-2xl leading-none font-bold tracking-tight"><?= e($f[0]) ?></dd><dt class="tag mt-2 text-[0.625rem]"><?= e($f[1]) ?></dt></div><?php endforeach; ?>
        </dl>
      </div>
      <p class="text-faint max-w-[52ch] text-[0.75rem] leading-relaxed">Plan percentages describe how credits are calculated on the published tables.</p>
    </aside>
    <div class="flex flex-col">
      <div class="border-line flex items-center justify-between border-b px-6 py-4 sm:px-10">
        <a href="/" class="lg:hidden" aria-label="<?= e(cfg()['name']) ?> home"><?= logo() ?></a>
        <a href="/" class="text-muted hover:text-porcelain ml-auto flex items-center gap-2 font-mono text-[0.6875rem] tracking-[0.14em] uppercase transition-colors"><?= icon('arrow-left','h-3.5 w-3.5') ?>Back to site</a>
      </div>
      <div class="flex flex-1 items-center justify-center px-6 py-12 sm:px-10">
        <div class="w-full max-w-[520px]">
          <h1 class="font-display text-[clamp(1.6rem,3vw,2.1rem)] leading-tight font-extrabold tracking-[-0.03em]"><?= e($title) ?></h1>
          <p class="text-muted mt-2.5 text-[0.9375rem] leading-relaxed"><?= e($lede) ?></p>
          <?php include dirname(__DIR__) . '/views/flash.php'; ?>
          <?php $inner(); ?>
          <div class="text-muted mt-8 text-center text-[0.875rem]"><?= $footer ?></div>
        </div>
      </div>
    </div>
  </div>
  <?php
  document_end();
}
