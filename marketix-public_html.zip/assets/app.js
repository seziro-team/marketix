(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  const header = $("#site-header");
  if (header) {
    const onScroll = () => {
      const on = window.scrollY > 12 || ($("#nav-drawer") && !$("#nav-drawer").classList.contains("hidden"));
      header.classList.toggle("border-line", on);
      header.classList.toggle("bg-ground/85", on);
      header.classList.toggle("border-b", true);
      header.classList.toggle("backdrop-blur-xl", on);
      header.classList.toggle("border-transparent", !on);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const openBtn = $("#nav-open") || $('[aria-label="Open menu"]');
    const drawer = $("#nav-drawer");
    if (openBtn && drawer) {
      openBtn.addEventListener("click", () => {
        const open = drawer.classList.toggle("hidden") === false;
        document.body.style.overflow = open ? "hidden" : "";
        openBtn.setAttribute("aria-expanded", open ? "true" : "false");
        onScroll();
      });
    }
  }

  $$(".js-faq [data-faq]").forEach((item, i, all) => {
    const btn = item.querySelector("button");
    const body = item.querySelector(".faq-body");
    if (!btn || !body) return;
    btn.addEventListener("click", () => {
      const open = btn.getAttribute("aria-expanded") === "true";
      all.forEach((other) => {
        const b = other.querySelector("button");
        const d = other.querySelector(".faq-body");
        const plus = b && b.querySelector("span:last-child");
        const label = b && b.querySelector("span");
        if (!b || !d) return;
        const is = other === item && !open;
        b.setAttribute("aria-expanded", is ? "true" : "false");
        d.style.display = is ? "" : "none";
        if (label) label.classList.toggle("text-brass", is);
        if (plus) plus.classList.toggle("rotate-45", is);
      });
    });
  });

  function bindCalc(root) {
    const SUBS = [
      { amount: 100, cap: 180 },
      { amount: 500, cap: 1000 },
      { amount: 1000, cap: 2200 },
      { amount: 2500, cap: 5750 },
      { amount: 5000, cap: 12000 },
      { amount: 10000, cap: 25000 },
      { amount: 25000, cap: 65000 },
      { amount: 50000, cap: 140000 },
      { amount: 100000, cap: 300000 },
    ];
    const DAYS = 30, W = 580, H = 190;
    const nearest = (a) => SUBS.reduce((b, s) => Math.abs(s.amount - a) < Math.abs(b.amount - a) ? s : b);
    const toAmount = (t) => nearest(Math.exp(Math.log(100) + t * (Math.log(100000) - Math.log(100)))).amount;
    const toSlider = (a) => (Math.log(a) - Math.log(100)) / (Math.log(100000) - Math.log(100));
    const usd = (n, d = 2) =>
      "$" + Number(n).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
    const range = $("[data-calc-range]", root);
    const amountEl = $("[data-calc-amount]", root);
    const dailyEl = $("[data-calc-daily]", root);
    const boostEl = $("[data-calc-boost]", root);
    const endEl = $("[data-calc-end]", root);
    const band = $("[data-calc-band]", root);
    const boostP = $("[data-calc-hi]", root);
    const baseP = $("[data-calc-lo]", root);
    const grid = $("[data-calc-grid]", root);
    function draw(amount) {
      const sub = nearest(amount);
      amount = sub.amount;
      const cap = sub.cap;
      const lo = 0.005, hi = 0.01;
      const base = Array.from({ length: DAYS + 1 }, (_, d) => amount + Math.min(cap, amount * lo * d));
      const boost = Array.from({ length: DAYS + 1 }, (_, d) => amount + Math.min(cap, amount * hi * d));
      const top = Math.max(boost[DAYS], amount + cap), bottom = amount, span = top - bottom || 1, pad = 14;
      const xy = (v, d) => [(d / DAYS) * W, pad + (1 - (v - bottom) / span) * (H - pad * 2)];
      const line = (s) => s.map((v, d) => (d === 0 ? "M " : "L ") + xy(v, d).join(" ")).join(" ");
      const bD = line(base), uD = line(boost);
      const bandD = uD + " " + base.slice().reverse().map((v, i) => "L " + xy(v, DAYS - i).join(" ")).join(" ") + " Z";
      if (grid && !grid.childElementCount) {
        [0.25, 0.5, 0.75].forEach((f) => {
          const y = pad + f * (H - pad * 2);
          const l = document.createElementNS("http://www.w3.org/2000/svg", "line");
          l.setAttribute("x1", "0");
          l.setAttribute("x2", String(W));
          l.setAttribute("y1", String(y));
          l.setAttribute("y2", String(y));
          l.setAttribute("stroke", "#123842");
          l.setAttribute("stroke-width", "1");
          grid.appendChild(l);
        });
      }
      if (band) band.setAttribute("d", bandD);
      if (boostP) boostP.setAttribute("d", uD);
      if (baseP) baseP.setAttribute("d", bD);
      if (amountEl) amountEl.textContent = usd(amount, 0);
      if (dailyEl) dailyEl.textContent = usd((amount * 0.5) / 100);
      if (boostEl) boostEl.textContent = usd((amount * 1) / 100);
      if (endEl) endEl.textContent = usd(base[DAYS], 0) + " – " + usd(boost[DAYS], 0);
      $$("[data-calc-presets] button", root).forEach((b) => {
        const on = Number(b.getAttribute("data-v")) === amount;
        b.classList.toggle("border-brass", on);
        b.classList.toggle("bg-brass/12", on);
        b.classList.toggle("text-brass", on);
        b.classList.toggle("border-line", !on);
        b.classList.toggle("text-muted", !on);
      });
    }
    const applyT = (t) => {
      const n = Math.min(1, Math.max(0, Number(t) || 0));
      if (range) range.value = String(n);
      draw(toAmount(n));
    };
    if (range) {
      const onMove = () => applyT(range.value);
      range.addEventListener("input", onMove);
      range.addEventListener("change", onMove);
    }
    $$("[data-calc-presets] button", root).forEach((b) => {
      b.addEventListener("click", (e) => {
        e.preventDefault();
        applyT(toSlider(Number(b.getAttribute("data-v"))));
      });
    });
    applyT(range ? range.value : toSlider(2500));
  }
  $$(".js-calc").forEach(bindCalc);

  const preview = $("#platform-preview");
  if (preview) {
    const tabs = $$("[data-tab]", preview);
    const panels = $$("[data-panel]", preview);
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        const name = tab.dataset.tab;
        tabs.forEach((t) => {
          const on = t === tab;
          t.classList.toggle("text-brass", on);
          t.classList.toggle("text-faint", !on);
          const line = t.querySelector(".tab-line");
          if (on && !line) {
            const s = document.createElement("span");
            s.className = "bg-brass absolute inset-x-0 bottom-0 h-px tab-line";
            t.appendChild(s);
          } else if (!on && line) line.remove();
        });
        panels.forEach((p) => { p.hidden = p.getAttribute("data-panel") !== name; });
      });
    });
  }

  $$("[data-copy]").forEach((box) => {
    const btn = $(".js-copy", box);
    if (!btn) return;
    btn.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(box.getAttribute("data-copy") || "");
        btn.textContent = "Copied";
        setTimeout(() => { btn.innerHTML = btn.innerHTML; btn.textContent = "Copy"; }, 1600);
      } catch (_) {}
    });
  });

  const appMenu = $("#app-menu");
  const appDrawer = $("#app-drawer");
  if (appMenu && appDrawer) {
    const bg = $("[data-drawer-bg]", appDrawer);
    const open = () => appDrawer.classList.add("open");
    const close = () => appDrawer.classList.remove("open");
    appMenu.addEventListener("click", open);
    if (bg) bg.addEventListener("click", close);
  }

  $$(".modal-bg").forEach((el) => {
    el.addEventListener("click", (e) => { if (e.target === el) el.classList.remove("open"); });
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") $$(".modal-bg.open, .bfx-drawer.open").forEach((el) => el.classList.remove("open"));
  });

  const reportModal = $("#report-modal");
  const reportOpen = $("#report-open");
  if (reportModal && reportOpen) {
    const openReport = () => reportModal.classList.add("open");
    const closeReport = () => reportModal.classList.remove("open");
    reportOpen.addEventListener("click", openReport);
    $$("[data-report-close]", reportModal).forEach((btn) => btn.addEventListener("click", closeReport));
    try {
      if (new URLSearchParams(location.search).has("report")) openReport();
    } catch (_) {}
  }
})();
