<?php
declare(strict_types=1);
require __DIR__ . '/lib/helpers.php';
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/engine.php';
db();
$key = $_GET['key'] ?? ($_POST['key'] ?? '');
$need = get_setting('cron_key', cfg()['cron_key']);
if (!$need || !hash_equals($need, $key)) {
  http_response_code(401);
  header('Content-Type: text/plain');
  echo "unauthorized\n";
  exit;
}
header('Content-Type: application/json');
echo json_encode(run_daily(), JSON_PRETTY_PRINT);
