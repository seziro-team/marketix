<?php
function bfx_packages(): array {
  $arts = ['tier-basic', 'tier-silver', 'tier-gold', 'tier-basic'];
  $out = [];
  foreach (plan()['plans'] as $i => $row) {
    $max = $row['max'] === null ? 'Unlimited' : ('$' . number_format((float)$row['max'], 0));
    $out[] = [
      'key' => 'plan' . $row['id'],
      'name' => $row['name'],
      'index' => (int)$row['id'],
      'headline' => $row['daily'] . '%',
      'sub' => 'after 24 hours',
      'accent' => 'var(--color-brass)',
      'art' => $arts[$i] ?? 'tier-basic',
      'range' => '$' . number_format((float)$row['min'], 0) . ' – ' . $max,
      'summary' => 'Interest is counted 24 hours from the moment this package is activated. There is no profit cap. Principal stays invested.',
      'features' => ['USDT on BEP20 only', 'Referral 10% to the sponsor', 'Withdraw income from $10', '10% withdrawal fee'],
      'featured' => (int)$row['id'] === 2,
    ];
  }
  return $out;
}

function package_cards(bool $detailed = false): void { ?>
  <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
    <?php foreach (bfx_packages() as $p): $feat = $p['featured']; ?>
      <article id="<?= e($p['key']) ?>" class="panel panel-lift relative flex h-full scroll-mt-28 flex-col overflow-hidden<?= $feat ? ' border-brass/45' : '' ?>">
        <div class="relative">
          <?php figure($p['art'], '', 'h-[104px] sm:h-[150px]', ['framed'=>false,'img'=>'object-cover','tint'=>'rgba(10,32,41,0.96)']); ?>
          <span class="absolute inset-x-0 top-0 h-[3px]" style="background:<?= e($p['accent']) ?>" aria-hidden="true"></span>
          <?php if ($feat): ?><span class="bg-brass absolute top-3 right-3 rounded-[2px] px-2 py-0.5 font-mono text-[0.5625rem] tracking-[0.14em] text-[#04121a] uppercase">24 hours</span><?php endif; ?>
          <div class="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4 sm:p-5">
            <div>
              <div class="flex items-center gap-2"><span class="text-faint font-mono text-[0.625rem] tracking-[0.18em]">0<?= $p['index'] ?></span><h3 class="font-display text-lg font-bold sm:text-xl"><?= e($p['name']) ?></h3></div>
              <p class="num text-muted mt-0.5 font-mono text-[0.75rem]"><?= e($p['range']) ?></p>
            </div>
            <div class="text-right">
              <span class="font-display num block text-[2rem] leading-[0.85] font-extrabold tracking-tight sm:text-[2.4rem]" style="color:<?= e($p['accent']) ?>"><?= e($p['headline']) ?></span>
              <span class="text-faint mt-1 block font-mono text-[0.5625rem] tracking-[0.1em] uppercase"><?= e($p['sub']) ?></span>
            </div>
          </div>
        </div>
        <div class="p-4 sm:p-5">
          <p class="text-muted text-[0.875rem] leading-relaxed text-pretty"><?= e($p['summary']) ?></p>
          <ul class="border-line mt-4 flex flex-col gap-2 border-t pt-4">
            <?php foreach ($p['features'] as $i => $f): ?>
              <li class="flex items-start gap-2.5 text-[0.875rem]<?= $i > 2 ? ' hidden sm:flex' : '' ?>"><?= icon('check','mt-[3px] h-3.5 w-3.5 shrink-0','3') ?><span class="text-porcelain/90"><?= e($f) ?></span></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <?php if ($detailed): ?>
          <div class="border-line bg-ground-2/50 border-t px-4 py-3 sm:px-5"><p class="text-faint text-[0.75rem] leading-relaxed"><?= e($p['headline']) ?> <?= e($p['sub']) ?>. Minimum <?= e($p['range']) ?>.</p></div>
        <?php endif; ?>
        <div class="mt-auto p-4 pt-3 sm:p-5 sm:pt-4">
          <a href="/register/" class="<?= $feat ? 'btn-brass' : 'btn-ghost font-medium' ?> h-11 w-full text-sm">Start with <?= e($p['name']) ?><?= icon('arrow-up-right','h-3.5 w-3.5','2.5') ?></a>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
<?php }

function tape_row(): void {
  $tape = [
    ['EUR/USD','1.0874',0.12],['GBP/USD','1.2691',-0.08],['USD/JPY','151.42',0.31],['BTC/USDT','64,180',1.84],
    ['ETH/USDT','3,142',0.96],['XAU/USD','2,318.60',0.44],['USD/INR','83.29',-0.05],['BNB/USDT','588.40',2.11],
    ['AUD/USD','0.6612',-0.19],['SOL/USDT','146.20',3.27],
  ];
  $row = array_merge($tape, $tape);
  ?>
  <div class="border-line bg-ground-2/60 relative my-4 border-y sm:my-6" role="marquee" aria-label="Indicative reference levels">
    <div class="mask-fade-x flex overflow-hidden">
      <div class="animate-tape flex w-max shrink-0 items-center">
        <?php foreach ($row as $i => $t): ?>
          <span class="border-line-soft flex items-center gap-2.5 border-r px-5 py-2.5 font-mono text-xs whitespace-nowrap">
            <span class="text-muted tracking-wide"><?= e($t[0]) ?></span>
            <span class="num text-porcelain"><?= e($t[1]) ?></span>
            <span class="num <?= $t[2] >= 0 ? 'text-up' : 'text-down' ?>"><?= $t[2] >= 0 ? '▲' : '▼' ?> <?= number_format(abs($t[2]), 2) ?>%</span>
          </span>
        <?php endforeach; ?>
      </div>
    </div>
    <span class="bg-ground border-line text-faint absolute top-1/2 right-0 hidden -translate-y-1/2 border-l px-4 py-2.5 font-mono text-[0.625rem] tracking-[0.16em] uppercase sm:block">Indicative</span>
  </div>
<?php }

function faqs(): array {
  return [
    ['How do I deposit, and how long does it take?','Send USDT on BEP20 to the address in your dashboard and submit the hash. A person approves it once it has enough confirmations — usually within a few hours.'],
    ['When does interest start?','24 hours after the package is activated. A deposit only fills the fund wallet. The percentage is the published schedule, not a market forecast.'],
    ['When can I withdraw?','From $10, from available income. Principal stays invested. A 10% fee applies. The request needs a transaction password and an email code, then a person releases it within 1–2 hours.'],
    ['How does referral income work?','The sponsor receives 10% of each package a direct member activates or reinvests. It is paid into the income wallet. A deposit by itself does not pay the referral.'],
    ['Which network do you support?','USDT on BEP20 (BNB Smart Chain) only. Any other token, or USDT on another network, will not credit and cannot be recovered.'],
    ['What fees are deducted?','10% on a withdrawal. Minimum withdrawal is $10. No deposit fee.'],
  ];
}

function faq_block(?int $limit = null): void {
  $items = $limit ? array_slice(faqs(), 0, $limit) : faqs();
  ?>
  <div class="border-line border-t js-faq">
    <?php foreach ($items as $i => $f): $open = $i === 0; ?>
      <div class="border-line border-b" data-faq>
        <h3>
          <button type="button" aria-expanded="<?= $open ? 'true' : 'false' ?>" class="group flex w-full items-start justify-between gap-6 py-5 text-left">
            <span class="font-display text-[1.0625rem] leading-snug font-semibold transition-colors sm:text-[1.125rem] <?= $open ? 'text-brass' : 'text-porcelain group-hover:text-brass' ?>"><?= e($f[0]) ?></span>
            <span class="border-line mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-[2px] border transition-all duration-300<?= $open ? ' border-brass/60 rotate-45' : '' ?>"><?= icon('plus','h-3.5 w-3.5 ' . ($open ? 'text-brass' : 'text-muted')) ?></span>
          </button>
        </h3>
        <div class="overflow-hidden faq-body" style="<?= $open ? '' : 'display:none' ?>">
          <p class="text-muted prose-measure pb-6 text-[0.9375rem] leading-relaxed text-pretty"><?= e($f[1]) ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php }

function hero_terminal(): void {
  $h = json_decode((string)file_get_contents(__DIR__ . '/../assets/hero.json'), true) ?: [];
  $line = $h['line'] ?? '';
  $area = $h['area'] ?? '';
  $lastX = $h['lastX'] ?? 607;
  $lastY = $h['lastY'] ?? 18;
  $value = $h['value'] ?? 11246.58;
  $change = $h['change'] ?? 3.12;
  $grid = $h['gridYs'] ?? [49.32, 98.04, 146.76];
  $up = $change >= 0;
  $alloc = [['FX majors',42,'var(--color-brass)'],['Digital assets',31,'var(--color-up)'],['Metals',18,'var(--color-tier-basic)'],['Cash buffer',9,'var(--color-faint)']];
  ?>
  <div class="panel relative overflow-hidden backdrop-blur-sm">
    <div class="border-line flex items-center justify-between border-b px-4 py-3">
      <div class="flex items-center gap-2.5"><span class="bg-up animate-pulse-dot h-1.5 w-1.5 rounded-full" aria-hidden="true"></span><span class="tag text-porcelain/80">Member terminal</span></div>
      <div class="flex items-center gap-1">
        <?php foreach (['1D','1W','1M','1Y'] as $i => $t): ?>
          <span class="rounded-[2px] px-2 py-1 font-mono text-[0.625rem] tracking-wider <?= $i===2 ? 'bg-brass/15 text-brass' : 'text-faint' ?>"><?= $t ?></span>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-[1.55fr_1fr]">
      <div class="border-line px-4 pt-4 pb-2 md:border-r">
        <div class="flex items-baseline gap-3"><span class="tag">Portfolio value</span><span class="pill <?= $up ? 'pill-up' : 'pill-down' ?>"><?= $up ? '▲' : '▼' ?> <?= number_format(abs($change), 2) ?>%</span></div>
        <div class="font-display num mt-1 text-[1.65rem] leading-none font-bold tracking-tight sm:text-[2rem]"><?= usd($value) ?></div>
        <svg viewBox="0 0 620 210" class="mt-3 h-auto w-full" aria-hidden="true">
          <defs>
            <linearGradient id="hero-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#38bdf8" stop-opacity="0.30"/><stop offset="65%" stop-color="#38bdf8" stop-opacity="0.05"/><stop offset="100%" stop-color="#38bdf8" stop-opacity="0"/></linearGradient>
            <linearGradient id="hero-line" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#0284c7"/><stop offset="55%" stop-color="#38bdf8"/><stop offset="100%" stop-color="#7dd3fc"/></linearGradient>
          </defs>
          <?php foreach ($grid as $y): ?><line x1="0" y1="<?= $y ?>" x2="620" y2="<?= $y ?>" stroke="#123842" stroke-width="1"></line><?php endforeach; ?>
          <path d="<?= e($area) ?>" fill="url(#hero-fill)"></path>
          <path d="<?= e($line) ?>" fill="none" stroke="url(#hero-line)" stroke-width="2.25" stroke-linecap="round"></path>
          <g transform="translate(<?= $lastX ?>, <?= $lastY ?>)"><circle r="9" fill="#38bdf8" opacity="0.18" class="animate-blip"></circle><circle r="4" fill="#38bdf8" stroke="#04121a" stroke-width="2"></circle></g>
        </svg>
      </div>
      <div class="hidden px-4 py-4 md:block" id="hero-alloc">
        <span class="tag">Desk allocation</span>
        <ul class="mt-4 space-y-3.5">
          <?php foreach ($alloc as $a): ?>
            <li>
              <div class="flex items-baseline justify-between"><span class="text-[0.8125rem]"><?= e($a[0]) ?></span><span class="num text-muted font-mono text-xs"><?= $a[1] ?>%</span></div>
              <div class="bg-ground-2 mt-1.5 h-[3px] w-full overflow-hidden"><div class="bar h-full" style="width:<?= $a[1] ?>%;background:<?= e($a[2]) ?>"></div></div>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
    <div class="border-line grid grid-cols-3 border-t">
      <?php foreach ([['Interest','$80.00','text-up'],['Referral','$100.00','text-porcelain'],['Available','$180.00','text-brass']] as $i => $s): ?>
        <div class="px-2.5 py-2.5 sm:px-4 sm:py-3<?= $i < 2 ? ' border-line border-r' : '' ?>">
          <div class="tag text-[0.5rem] leading-tight sm:text-[0.625rem]"><?= e($s[0]) ?></div>
          <div class="num font-display mt-1 text-[0.8125rem] font-bold sm:text-base <?= e($s[2]) ?>"><?= e($s[1]) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <p class="border-line bg-ground-2/60 text-faint border-t px-3 py-2 font-mono text-[0.5625rem] leading-relaxed tracking-wider sm:px-4 sm:text-[0.625rem]">Illustrative preview of the member dashboard. Figures are sample data, not a live account.</p>
  </div>
<?php }

function profit_calculator(): void {
  $examples = [
    ['$100 on Plan 1', '$8', '8% after 24 hours'],
    ['$600 on Plan 2', '$60', '10% after 24 hours'],
    ['$6,000 on Plan 3', '$720', '12% after 24 hours'],
    ['Referral on $600', '$60', '10% to the sponsor, once'],
  ];
  ?>
  <div class="panel">
    <div class="grid grid-cols-1 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
      <div class="border-line p-4 sm:p-6 lg:border-r">
        <span class="tag">Published schedule</span>
        <p class="text-muted mt-3 max-w-[54ch] text-[0.9375rem] leading-relaxed">Interest is credited once, 24 hours after the package is activated, and again every 24 hours after that. The percentage is of the amount activated. There is no profit cap. Principal stays invested.</p>
        <div class="mt-6 table-wrap">
          <table class="ledger w-full">
            <thead><tr><th>Plan</th><th>Amount</th><th class="text-right">After 24 hours</th></tr></thead>
            <tbody>
              <?php foreach (plan()['plans'] as $row):
                $max = $row['max'] === null ? 'Unlimited' : ('$' . number_format((float)$row['max'], 0));
              ?>
                <tr>
                  <td class="font-medium"><?= e($row['name']) ?></td>
                  <td class="font-mono">$<?= number_format((float)$row['min'], 0) ?> – <?= e($max) ?></td>
                  <td class="text-brass text-right font-mono"><?= (int)$row['daily'] ?>%</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <p class="text-faint mt-4 text-[0.8125rem] leading-relaxed">Amounts between the bands — $501 to $599, $5,001 to $5,999, and $50,001 to $59,999 — are not accepted.</p>
      </div>
      <div class="bg-ground-2/50 grid grid-cols-2 lg:flex lg:flex-col">
        <?php foreach ($examples as $ex): ?>
          <div class="border-line-soft border-b px-4 py-3 sm:px-6 sm:py-4">
            <span class="tag text-[0.625rem]"><?= e($ex[0]) ?></span>
            <div class="num font-display mt-1 text-lg font-bold text-brass"><?= e($ex[1]) ?></div>
            <p class="text-faint mt-0.5 text-[0.75rem]"><?= e($ex[2]) ?></p>
          </div>
        <?php endforeach; ?>
        <p class="text-faint col-span-2 mt-auto p-4 text-[0.75rem] leading-relaxed sm:p-6 sm:pt-5">Worked examples of the published rates. Not a forecast of trading profit.</p>
      </div>
    </div>
  </div>
<?php }

function referral_panel(): void { ?>
  <div class="panel min-w-0 overflow-hidden">
    <div class="border-line flex flex-wrap items-center gap-x-5 gap-y-2 border-b px-4 py-2.5 sm:px-5 sm:py-3">
      <span class="tag">Referral · 10%</span>
      <span class="text-muted font-mono text-[0.6875rem]">Paid on activation and reinvest</span>
    </div>
    <div class="grid grid-cols-1 items-center gap-4 px-4 py-5 sm:grid-cols-[1fr_auto_1fr] sm:px-6 sm:py-8">
      <div class="border-line bg-panel-2 rounded-[3px] border px-4 py-3">
        <div class="tag text-[0.5625rem]">Sponsor</div>
        <div class="font-display mt-1 text-lg font-bold">You</div>
        <p class="text-muted mt-1 text-[0.8125rem]">10% is credited to your income wallet.</p>
      </div>
      <div class="text-brass text-center font-mono text-[0.6875rem] tracking-[0.14em] uppercase">10%</div>
      <div class="border-line bg-ground-2 rounded-[3px] border px-4 py-3">
        <div class="tag text-[0.5625rem]">Direct member</div>
        <div class="font-display mt-1 text-lg font-bold">Activates $1,000</div>
        <p class="text-muted mt-1 text-[0.8125rem]">A deposit alone pays nothing. Activation does.</p>
      </div>
    </div>
    <div class="border-line grid grid-cols-2 divide-x divide-y divide-[var(--color-line-soft)] border-t sm:grid-cols-4 sm:divide-y-0">
      <?php foreach ([['Rate','10%','text-brass'],['When','Activation','text-porcelain'],['Reinvest','Pays again','text-porcelain'],['Example','$100','text-brass']] as $c): ?>
        <div class="px-4 py-3 sm:px-5 sm:py-4"><div class="tag text-[0.625rem]"><?= e($c[0]) ?></div><div class="num font-display mt-1 text-base font-bold sm:text-lg <?= e($c[2]) ?>"><?= e($c[1]) ?></div></div>
      <?php endforeach; ?>
    </div>
    <p class="border-line text-faint border-t px-4 py-2.5 font-mono text-[0.625rem] leading-relaxed tracking-wide sm:px-5 sm:py-3 sm:text-[0.6875rem]">A direct member activates $1,000. The sponsor’s income wallet is credited $100. The same 10% is paid again if that member reinvests.</p>
  </div>
<?php }

function platform_preview(): void {
  $bars = [38,52,44,66,58,79,71,88,82,96,90,100];
  ?>
  <div class="panel overflow-hidden" id="platform-preview">
    <div class="border-line bg-ground-2/70 flex items-center gap-4 border-b px-4 py-2.5">
      <div class="flex gap-1.5" aria-hidden="true"><?php foreach (['#f2645c','#f2a23c','#5bd6a8'] as $c): ?><span class="h-2.5 w-2.5 rounded-full opacity-60" style="background:<?= $c ?>"></span><?php endforeach; ?></div>
      <div class="border-line bg-ground text-faint hidden flex-1 rounded-[2px] border px-3 py-1 text-center font-mono text-[0.6875rem] sm:block">marketix.ltd/dashboard</div>
    </div>
    <div class="border-line scroll-x flex border-b" data-tabs>
      <?php foreach (['Overview','Referrals','Wallet','Support'] as $i => $t): ?>
        <button type="button" data-tab="<?= e($t) ?>" class="relative shrink-0 px-4 py-3 font-mono text-[0.6875rem] tracking-[0.14em] uppercase transition-colors <?= $i===0 ? 'text-brass' : 'text-faint hover:text-muted' ?>"><?= e($t) ?><?php if ($i===0): ?><span class="bg-brass absolute inset-x-0 bottom-0 h-px tab-line"></span><?php endif; ?></button>
      <?php endforeach; ?>
    </div>
    <div class="bg-ground/60 relative min-h-[248px] p-3 sm:min-h-[302px] sm:p-5">
      <div data-panel="Overview">
        <div class="space-y-4">
          <div class="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <?php foreach ([['Available income','$180.00','text-brass'],['Fund wallet','$1,000.00',''],['Interest','$80.00','text-up'],['Referral','$100.00','text-up']] as $t): ?>
              <div class="panel px-3.5 py-3"><div class="tag text-[0.5625rem]"><?= e($t[0]) ?></div><div class="num font-display mt-1 text-[1.0625rem] font-bold <?= e($t[2]) ?>"><?= e($t[1]) ?></div></div>
            <?php endforeach; ?>
          </div>
          <div class="panel p-4">
            <div class="flex items-center justify-between"><span class="tag text-[0.625rem]">Earnings · last 12 months</span><span class="pill pill-up">▲ 18.4%</span></div>
            <div class="mt-4 flex h-24 items-end gap-1.5">
              <?php foreach ($bars as $i => $h): ?>
                <span class="flex-1 rounded-t-[1px]" style="height:<?= $h ?>%;background:<?= $i===count($bars)-1 ? 'var(--color-brass)' : 'color-mix(in srgb, var(--color-brass) 40%, var(--color-ground))' ?>"></span>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
      <div data-panel="Referrals" hidden>
        <div class="panel overflow-hidden">
          <div class="border-line flex items-center justify-between border-b px-4 py-2.5"><span class="tag text-[0.625rem]">Direct members</span><span class="text-faint font-mono text-[0.625rem]">10% on activation</span></div>
          <div class="divide-y divide-[var(--color-line-soft)]">
            <?php foreach ([['MTX-104821','Plan 2 · $1,000','$100','pill-up'],['MTX-104902','Plan 1 · $250','$25','pill-up'],['MTX-105014','Registered','—','pill-idle']] as $r): ?>
              <div class="flex items-center justify-between gap-3 px-4 py-3"><span class="flex min-w-0 items-center gap-3"><span class="text-faint shrink-0 font-mono text-[0.6875rem]"><?= e($r[0]) ?></span><span class="truncate text-[0.8125rem]"><?= e($r[1]) ?></span></span><span class="num font-mono text-[0.8125rem] <?= $r[2]==='—' ? 'text-faint' : 'text-brass' ?>"><?= e($r[2]) ?></span></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <div data-panel="Wallet" hidden>
        <div class="grid grid-cols-1 gap-3 lg:grid-cols-[1fr_1.25fr]">
          <div class="panel p-4"><span class="tag text-[0.625rem]">Deposit · USDT BEP20</span>
            <div class="border-line bg-ground mt-3 grid h-[104px] w-[104px] place-items-center rounded-[2px] border">
              <svg viewBox="0 0 7 7" class="h-[76px] w-[76px]" aria-hidden="true" shape-rendering="crispEdges"><?php foreach (['1110111','1000101','1011101','1010001','1110110','0001011','1101011'] as $y=>$row) for ($x=0;$x<7;$x++) if ($row[$x]==='1') echo '<rect x="'.$x.'" y="'.$y.'" width="1" height="1" fill="#edf4f4"></rect>'; ?></svg>
            </div>
            <p class="text-faint mt-3 font-mono text-[0.625rem] break-all">0x0000…0000</p>
          </div>
          <div class="panel overflow-hidden">
            <div class="border-line border-b px-4 py-2.5"><span class="tag text-[0.625rem]">Recent movements</span></div>
            <div class="divide-y divide-[var(--color-line-soft)]">
              <?php foreach ([['Deposit','+$1,000.00','Fund wallet','pill-up'],['Interest','+$80.00','Credited','pill-up'],['Referral','+$100.00','Credited','pill-up'],['Withdrawal','−$90.00','Pending','pill-wait']] as $r): ?>
                <div class="flex items-center justify-between gap-3 px-4 py-2.5"><span class="text-[0.8125rem]"><?= e($r[0]) ?></span><span class="flex items-center gap-3"><span class="num font-mono text-[0.8125rem]"><?= e($r[1]) ?></span><span class="pill <?= e($r[3]) ?>"><?= e($r[2]) ?></span></span></div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>
      <div data-panel="Support" hidden>
        <div class="panel overflow-hidden">
          <div class="border-line flex items-center justify-between border-b px-4 py-2.5"><span class="tag text-[0.625rem]">Support tickets</span><span class="text-faint font-mono text-[0.625rem]">3 open</span></div>
          <div class="divide-y divide-[var(--color-line-soft)]">
            <?php foreach ([['#MTX-4021','Withdrawal not received','Open','pill-wait'],['#MTX-4017','Change BEP20 address','Answered','pill-up'],['#MTX-3998','Package activation','Answered','pill-up'],['#MTX-3960','Deposit hash verification','Closed','pill-idle']] as $r): ?>
              <div class="flex items-center justify-between gap-3 px-4 py-3"><span class="flex min-w-0 items-center gap-3"><span class="text-faint shrink-0 font-mono text-[0.6875rem]"><?= e($r[0]) ?></span><span class="truncate text-[0.8125rem]"><?= e($r[1]) ?></span></span><span class="pill shrink-0 <?= e($r[3]) ?>"><?= e($r[2]) ?></span></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php }
