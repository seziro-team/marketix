<?php
function current_user(): ?array {
  $id = $_SESSION['uid'] ?? null;
  if (!$id) return null;
  $st = db()->prepare('SELECT * FROM users WHERE id = ?');
  $st->execute([$id]);
  $u = $st->fetch();
  return $u ?: null;
}
function require_login(): array {
  $u = current_user();
  if (!$u) {
    $_SESSION['next'] = path();
    redirect('/login/');
  }
  if ($u['status'] === 'suspended' || $u['status'] === 'rejected') {
    unset($_SESSION['uid']);
    flash('This account cannot sign in.', 'err');
    redirect('/login/');
  }
  return $u;
}
function require_member(): array {
  $u = require_login();
  if ($u['role'] !== 'member') redirect('/admin/');
  return $u;
}
function require_admin(): array {
  $u = require_login();
  if ($u['role'] !== 'admin') redirect('/dashboard/');
  return $u;
}
function login_user(string $login, string $password): string|true {
  $st = db()->prepare('SELECT * FROM users WHERE lower(email) = lower(?) OR id = ?');
  $st->execute([$login, strtoupper($login)]);
  $u = $st->fetch();
  if (!$u || !password_verify($password, $u['password_hash'])) return 'Email, member ID or password is wrong.';
  if ($u['status'] === 'rejected' || $u['status'] === 'suspended') return 'This account cannot sign in.';
  session_regenerate_id(true);
  $_SESSION['uid'] = $u['id'];
  return true;
}
function logout_user(): void {
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
  }
  session_destroy();
}
