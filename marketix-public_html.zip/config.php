<?php
/**
 * Marketix Ltd — Hostinger public_html pack.
 * Create noreply@marketix.ltd in hPanel and paste its mailbox password below
 * before registration emails and OTP will send.
 */
return [
  'name' => 'Marketix Ltd',
  'tagline' => 'Forex & cryptocurrency investment schedules',
  'domain' => 'marketix.ltd',
  'url' => 'https://marketix.ltd',
  'cron_key' => 'AGUbev3aZo4RzdRKQZyL',
  'session' => 'mtx_hostinger',
  'min_deposit' => 100,
  'confirmations' => 12,
  'wallet_address' => '0x4a80a20c5f9750b610dbC39f229B273174aCA65D',
  'wallet_network' => 'BEP20 (BNB Smart Chain)',
  'admin_email' => 'support@marketix.ltd',
  'admin_password' => 'Mtx-Desk-2026-k7Q',
  'support_email' => 'support@marketix.ltd',
  'report_email' => 'support@marketix.ltd',
  'from_email' => 'noreply@marketix.ltd',
  'smtp_host' => 'smtp.hostinger.com',
  'smtp_port' => 465,
  'smtp_password' => '',
  'phone' => '+1 423-500-2799',
  'phone_tel' => '+14235002799',
  'whatsapp' => 'https://wa.me/message/DE6UFTLOKDUKN1',
  'telegram' => 'https://t.me/marketixltd',
  'telegram_handle' => '@marketixltd',
  'hours' => '24/7 · replies within 24 hours',
  'founded' => 2016,
  'ceo' => 'Alex Darden',
  'address' => 'One World Trade Center, 285 Fulton St, New York, NY 10007, United States',
  'address_street' => 'One World Trade Center, 285 Fulton St',
  'address_city' => 'New York',
  'address_region' => 'NY',
  'address_postal' => '10007',
  'address_country' => 'United States',
];
