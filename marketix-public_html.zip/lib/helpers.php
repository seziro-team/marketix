<?php
function cfg(): array {
  static $c;
  return $c ??= require __DIR__ . '/../config.php';
}
function report_email(): string {
  return (string)(cfg()['report_email'] ?? 'support@marketix.ltd');
}
function plan(): array {
  static $p;
  return $p ??= require __DIR__ . '/plan.php';
}
function e(?string $s): string {
  return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function asset_url(string $rel): string {
  $rel = '/' . ltrim($rel, '/');
  $fs = dirname(__DIR__) . $rel;
  $v = is_file($fs) ? (string)filemtime($fs) : (string)time();
  return $rel . '?v=' . $v;
}
function send_no_store_headers(): void {
  if (headers_sent()) return;
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  header('Pragma: no-cache');
  header('Expires: 0');
}
function usd(float $n, int $d = 2): string {
  return '$' . number_format($n, $d);
}
function cents(float $n): int { return (int) round($n * 100); }
function dollars(int $c): float { return round($c / 100, 2); }
function tz(): DateTimeZone { return new DateTimeZone('Asia/Kolkata'); }
function now(): string { return gmdate('c'); }
function today(): string {
  return (new DateTime('now', tz()))->format('Y-m-d');
}
function ist_end_utc(string $date): string {
  $d = new DateTime($date . ' 23:59:59', tz());
  $d->setTimezone(new DateTimeZone('UTC'));
  return $d->format('c');
}
function redirect(string $to): never {
  header('Location: ' . $to, true, 302);
  exit;
}
function path(): string {
  $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
  $uri = '/' . trim($uri, '/');
  if ($uri !== '/') $uri .= '/';
  return $uri === '//' ? '/' : $uri;
}
function flash(?string $msg = null, string $type = 'ok'): ?array {
  if ($msg !== null) {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
    return null;
  }
  $f = $_SESSION['flash'] ?? null;
  unset($_SESSION['flash']);
  return $f;
}
function csrf_token(): string {
  if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
  return $_SESSION['csrf'];
}
function csrf_check(): void {
  $t = $_POST['_csrf'] ?? '';
  if (!$t || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
    http_response_code(400);
    exit('Bad request');
  }
}
function csrf_field(): string {
  return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function get_setting(string $k, string $fallback = ''): string {
  $st = db()->prepare('SELECT value FROM settings WHERE key = ?');
  $st->execute([$k]);
  $row = $st->fetch();
  return $row ? (string)$row['value'] : $fallback;
}
function set_setting(string $k, string $v): void {
  db()->prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')->execute([$k, $v]);
}
function next_id(string $prefix, string $counter, int $pad = 6): string {
  $db = db();
  $db->beginTransaction();
  $st = $db->prepare('SELECT value FROM counters WHERE key = ?');
  $st->execute([$counter]);
  $n = (int)$st->fetchColumn() + 1;
  $db->prepare('UPDATE counters SET value = ? WHERE key = ?')->execute([$n, $counter]);
  $db->commit();
  return $prefix . '-' . str_pad((string)$n, $pad, '0', STR_PAD_LEFT);
}
function kind_label(string $k): string {
  return [
    'roi' => 'Interest', 'direct' => 'Referral income', 'level' => 'Level income',
    'generation' => 'Team generation',
    'salary' => 'Salary reward', 'community' => 'Community reward', 'fd' => 'Fixed deposit',
    'promo' => 'Promotional', 'deposit' => 'Deposit', 'fund' => 'Fund wallet',
    'activation' => 'Package activation', 'reinvest' => 'Reinvest',
    'topup_out' => 'Top up sent', 'withdrawal' => 'Withdrawal',
    'withdrawal_reversal' => 'Withdrawal reversed', 'principal_out' => 'Principal out',
    'principal_reversal' => 'Principal restored',
  ][$k] ?? $k;
}
function status_pill(string $s): string {
  $map = [
    'active' => ['Active', 'pill-up'], 'approved' => ['Approved', 'pill-up'], 'credited' => ['Credited', 'pill-up'],
    'pending' => ['Pending', 'pill-wait'], 'open' => ['Open', 'pill-wait'], 'answered' => ['Answered', 'pill-up'],
    'rejected' => ['Rejected', 'pill-down'], 'suspended' => ['Suspended', 'pill-down'],
    'closed' => ['Closed', 'pill-idle'], 'verified' => ['Verified', 'pill-up'],
    'inactive' => ['Inactive', 'pill-idle'],
    'capped' => ['Capped', 'pill-wait'],
    'matured' => ['Matured', 'pill-up'],
  ];
  $x = $map[strtolower($s)] ?? [ucfirst($s), 'pill-idle'];
  return '<span class="pill ' . $x[1] . '">' . e($x[0]) . '</span>';
}
function package_status(array $u): string {
  $st = (string)($u['status'] ?? '');
  if ($st === 'suspended' || $st === 'rejected') return $st;
  if (array_key_exists('earning_cents', $u)) {
    return (int)$u['earning_cents'] > 0 ? 'active' : 'inactive';
  }
  return has_active_package((string)$u['id']) ? 'active' : 'inactive';
}
function package_pill(array $u): string {
  return status_pill(package_status($u));
}
function initials(string $name): string {
  $p = preg_split('/\s+/', trim($name)) ?: [];
  return strtoupper(substr($p[0] ?? '', 0, 1) . substr($p[1] ?? '', 0, 1));
}
function when_fmt(?string $iso): string {
  if (!$iso) return '—';
  try {
    $d = new DateTime($iso);
    $d->setTimezone(tz());
    return $d->format('d M Y, h:i A');
  } catch (Exception $e) {
    return substr(str_replace('T', ' ', $iso), 0, 16);
  }
}
function product_label(?string $k): string {
  if (preg_match('/^plan(\d+)$/', (string)$k, $m)) {
    foreach (plan()['plans'] as $row) {
      if ((int)$row['id'] === (int)$m[1]) return (string)$row['name'];
    }
  }
  $p = plan()['products'][$k ?? ''] ?? null;
  return $p ? (string)$p['name'] : ($k ? strtoupper((string)$k) : '—');
}
function plan_for_cents(int $centsAmt): ?array {
  $usd = $centsAmt / 100;
  foreach (plan()['plans'] as $row) {
    if ($usd + 0.0001 < (float)$row['min']) continue;
    if ($row['max'] !== null && $usd - 0.0001 > (float)$row['max']) continue;
    return $row;
  }
  return null;
}
function plan_bands_text(): string {
  $parts = [];
  foreach (plan()['plans'] as $row) {
    $max = $row['max'] === null ? 'unlimited' : ('$' . number_format((float)$row['max'], 0));
    $parts[] = $row['name'] . ' $' . number_format((float)$row['min'], 0) . '–' . $max;
  }
  return implode('; ', $parts) . '.';
}
function plan_option_list(): string {
  $html = '';
  foreach (plan()['plans'] as $row) {
    $max = $row['max'] === null ? 'Unlimited' : usd((float)$row['max'], 0);
    $html .= '<option value="' . (int)$row['id'] . '">' . e($row['name'] . ' · ' . usd((float)$row['min'], 0) . ' – ' . $max . ' · ' . $row['daily'] . '% / 24h') . '</option>';
  }
  return $html;
}
function subscription_by_amount_cents(int $cents): ?array {
  foreach (plan()['subscriptions'] as $s) {
    if (cents((float)$s['amount']) === $cents) return $s;
  }
  return null;
}
function subscription_label(array $s): string {
  $amt = usd((float)$s['amount'], 0);
  $mult = rtrim(rtrim(number_format((float)$s['mult'], 1, '.', ''), '0'), '.');
  return 'Subscription ' . $s['id'] . ' · ' . $amt . ' · ' . $mult . '× cap ' . usd((float)$s['cap'], 0);
}
function require_subscription_cents(int $cents): array {
  $s = subscription_by_amount_cents($cents);
  if (!$s) throw new RuntimeException('Choose a published subscription amount.');
  return $s;
}
function wallet_qr_url(): ?string {
  $p = get_setting('wallet_qr_path', '');
  if ($p === '') return null;
  $fs = dirname(__DIR__) . $p;
  if (!is_file($fs)) return null;
  return $p . '?v=' . filemtime($fs);
}
function company_qr_img(int $size = 148): string {
  $url = wallet_qr_url();
  $addr = get_setting('wallet_address', cfg()['wallet_address']);
  if ($url) {
    return '<img src="' . e($url) . '" alt="Company wallet QR" width="' . $size . '" height="' . $size . '" style="margin:0 auto;background:#fff;padding:8px;object-fit:contain;max-width:100%">';
  }
  $bundled = dirname(__DIR__) . '/brand/deposit-qr.jpg';
  if (is_file($bundled)) {
    return '<img src="/brand/deposit-qr.jpg" alt="USDT BEP20 QR" width="' . $size . '" height="' . $size . '" style="margin:0 auto;background:#fff;padding:8px;object-fit:contain;max-width:100%;height:auto">';
  }
  $qr = 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size . '&data=' . urlencode($addr);
  return '<img src="' . e($qr) . '" alt="QR" width="' . $size . '" height="' . $size . '" style="margin:0 auto;background:#fff;padding:8px">';
}
function save_uploaded_wallet_qr(): ?string {
  if (empty($_FILES['wallet_qr']['tmp_name']) || !is_uploaded_file($_FILES['wallet_qr']['tmp_name'])) return null;
  $tmp = $_FILES['wallet_qr']['tmp_name'];
  $info = @getimagesize($tmp);
  if (!$info) throw new RuntimeException('QR must be an image (PNG, JPG or WebP).');
  $map = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'];
  $mime = $info['mime'] ?? '';
  if (!isset($map[$mime])) throw new RuntimeException('Use PNG, JPG or WebP for the QR image.');
  if (($_FILES['wallet_qr']['size'] ?? 0) > 4 * 1024 * 1024) throw new RuntimeException('QR image must be under 4 MB.');
  $dir = dirname(__DIR__) . '/uploads';
  if (!is_dir($dir)) mkdir($dir, 0755, true);
  foreach (glob($dir . '/wallet-qr.*') ?: [] as $old) @unlink($old);
  $destRel = '/uploads/wallet-qr.' . $map[$mime];
  if (!move_uploaded_file($tmp, dirname(__DIR__) . $destRel)) throw new RuntimeException('Could not save the QR image.');
  set_setting('wallet_qr_path', $destRel);
  return $destRel;
}
function positions_summary(array $investments): string {
  if (!$investments) return '—';
  $parts = [];
  foreach ($investments as $i) {
    if (!in_array($i['status'], ['active', 'matured'], true)) continue;
    $parts[] = product_label($i['kind']) . ' ' . usd(dollars((int)$i['principal_cents']), 0);
  }
  return $parts ? implode(' · ', $parts) : '—';
}
