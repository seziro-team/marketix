<?php
require_once __DIR__ . '/kit.php';
require_once __DIR__ . '/widgets.php';
require_once __DIR__ . '/auth-shell.php';
public_document_start($title ?? (cfg()['name'] ?? 'Marketix Ltd'), $GLOBALS['meta'] ?? []);
public_header();
