<?php
const BFX_HTML_CLASS = 'archivo_c50fddcf-module__xTJHDW__variable hanken_grotesk_fba5aca1-module__RiqvWW__variable ibm_plex_mono_93a398a6-module__Tx7x6q__variable';

function bfx_nav(): array {
  return [
    ['Home', '/'],
    ['About Us', '/about/'],
    ['Business Plan', '/business-plan/'],
    ['Contact Us', '/contact/'],
  ];
}

function icon(string $name, string $class = 'h-4 w-4', string $sw = '2'): string {
  $p = [
    'arrow-up-right' => '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
    'arrow-right' => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
    'arrow-left' => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    'arrow-down-to-line' => '<path d="M12 17V3"/><path d="m6 11 6 6 6-6"/><path d="M19 21H5"/>',
    'arrow-up-from-line' => '<path d="m18 9-6-6-6 6"/><path d="M12 3v14"/><path d="M5 21h14"/>',
    'menu' => '<path d="M4 5h16"/><path d="M4 12h16"/><path d="M4 19h16"/>',
    'x' => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    'mail' => '<path d="m22 7-8.99 5.74a2 2 0 0 1-2.02 0L2 7"/><rect x="2" y="4" width="20" height="16" rx="2"/>',
    'map-pin' => '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
    'clock' => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    'life-buoy' => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><path d="m4.93 4.93 4.24 4.24"/><path d="m14.83 14.83 4.24 4.24"/><path d="m14.83 9.17 4.24-4.24"/><path d="m4.93 19.07 4.24-4.24"/>',
    'check' => '<path d="M20 6 9 17l-5-5"/>',
    'plus' => '<path d="M5 12h14"/><path d="M12 5v14"/>',
    'copy' => '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    'wallet' => '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2.3"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
    'piggy-bank' => '<path d="M19 5c-1.5 0-2.8 1.4-3 2-3.5-1.5-11-.3-11 5 0 1.8 0 3 2 4.5V20h4v-2h3v2h4v-4c1-.5 1.7-1 2-2h2v-4h-2c0-1-.5-1.5-1-2V5z"/><path d="M2 9v1c0 1.1.9 2 2 2h1"/><path d="M16 11h.01"/>',
    'trending-up' => '<path d="M16 7h6v6"/><path d="m22 7-8.5 8.5-5-5L2 17"/>',
    'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    'receipt' => '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/>',
    'layers' => '<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/>',
    'git-branch' => '<circle cx="6" cy="6" r="3"/><path d="M6 9v12"/><path d="M18 9a9 9 0 0 1-9 9"/><circle cx="18" cy="6" r="3"/>',
    'user' => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    'settings' => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    'layout-dashboard' => '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
    'gauge' => '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
    'shield-check' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    'share-2' => '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
    'log-out' => '<path d="m16 17 5-5-5-5"/><path d="M21 12H9"/><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>',
    'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
    'landmark' => '<path d="M10 18v-7"/><path d="M11.12 2.198a2 2 0 0 1 1.76.006l7.866 3.847c.52.254.52 1.05 0 1.305l-7.866 3.846a2 2 0 0 1-1.76.006L3.354 7.356a.734.734 0 0 1 0-1.306z"/><path d="M14 18v-7"/><path d="M18 18v-7"/><path d="M3 22h18"/><path d="M6 18v-7"/>',
    'banknote' => '<rect width="20" height="12" x="2" y="6" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/>',
    'link-2' => '<path d="M9 17H7A5 5 0 0 1 7 7h2"/><path d="M15 7h2a5 5 0 1 1 0 10h-2"/><line x1="8" x2="16" y1="12" y2="12"/>',
    'waves' => '<path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>',
  ];
  $d = $p[$name] ?? '';
  return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' . e($sw) . '" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-' . e($name) . ' ' . e($class) . '" aria-hidden="true">' . $d . '</svg>';
}

function logo_mark(string $class = 'h-9 w-9'): string {
  return '<img src="/brand/logo.jpg" alt="" class="shrink-0 object-contain ' . e($class) . '" width="36" height="36">';
}

function logo(): string {
  $name = e(cfg()['name'] ?? 'Marketix Ltd');
  return '<span class="inline-flex items-center gap-2.5">' . logo_mark() . '<span class="font-display text-[1.15rem] leading-none font-extrabold tracking-[-0.04em] text-porcelain">' . $name . '</span></span>';
}

function backdrop(): string {
  return '<div class="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
    <div class="bg-ground absolute inset-0"></div>
    <div class="desk-rules mask-fade-b absolute inset-0 opacity-[0.55]"></div>
    <div class="animate-sheen absolute -top-[22rem] left-1/2 h-[46rem] w-[86rem] -translate-x-1/2 rounded-full blur-[130px]" style="background:radial-gradient(closest-side, rgba(56,189,248,0.28), rgba(14,165,233,0.08) 55%, transparent)"></div>
    <div class="animate-drift absolute top-[26rem] -right-40 h-[34rem] w-[34rem] rounded-full blur-[120px]" style="background:radial-gradient(closest-side, rgba(91,214,168,0.10), transparent)"></div>
    <div class="grain absolute inset-0 opacity-[0.16] mix-blend-overlay"></div>
  </div>';
}

function office_meta_desc(): string {
  $c = cfg();
  return $c['name'] . ' is a United States investment company, running since ' . $c['founded'] . '. Forex and cryptocurrency schedules from $100, settled in USDT on BEP20. ' . $c['address'] . '.';
}
function jsonld_organization(): string {
  $c = cfg();
  $data = [
    '@context' => 'https://schema.org',
    '@type' => 'Organization',
    'name' => $c['name'],
    'url' => $c['url'],
    'email' => $c['support_email'],
    'telephone' => $c['phone'],
    'image' => $c['url'] . '/brand/logo-lockup.jpg',
    'address' => [
      '@type' => 'PostalAddress',
      'streetAddress' => $c['address_street'],
      'addressLocality' => $c['address_city'],
      'addressRegion' => $c['address_region'],
      'postalCode' => $c['address_postal'],
      'addressCountry' => 'US',
    ],
  ];
  return '<script type="application/ld+json">' . json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}
function document_start(string $title, array $meta = []): void {
  $robots = $meta['robots'] ?? 'index, follow';
  $desc = $meta['desc'] ?? office_meta_desc();
  $brand = cfg()['name'];
  $origin = cfg()['url'];
  $pageTitle = ($title === $brand || $title === 'Marketix Ltd') ? ($brand . ' — ' . cfg()['tagline']) : ($title . ' · ' . $brand);
  echo '<!doctype html><html lang="en" class="' . BFX_HTML_CLASS . '"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#e7f3fb"><meta name="color-scheme" content="light">
<title>' . e($pageTitle) . '</title>
<meta name="description" content="' . e($desc) . '">
<meta name="robots" content="' . e($robots) . '">
<link rel="canonical" href="' . e($origin . path()) . '">
<meta property="og:type" content="website">
<meta property="og:site_name" content="' . e($brand) . '">
<meta property="og:url" content="' . e($origin . path()) . '">
<meta property="og:title" content="' . e($pageTitle) . '">
<meta property="og:description" content="' . e($desc) . '">
<meta property="og:locale" content="en_US">
<meta name="geo.region" content="US-NY">
<meta name="geo.placename" content="New York">
<link rel="icon" href="/favicon.png" type="image/png">
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
<meta http-equiv="Pragma" content="no-cache">
<link rel="stylesheet" href="' . e(asset_url('/assets/next/chunks/app.css')) . '">
<link rel="stylesheet" href="' . e(asset_url('/assets/app.css')) . '">
<link rel="stylesheet" href="' . e(asset_url('/assets/bridge.css')) . '">
' . jsonld_organization() . '
</head><body class="min-h-screen antialiased">';
}

function document_end(): void {
  $wa = cfg()['whatsapp'] ?? '';
  echo '<a class="wa-float" href="' . e($wa) . '" target="_blank" rel="noopener" aria-label="WhatsApp">WhatsApp</a>';
  echo '<script src="' . e(asset_url('/assets/app.js')) . '" defer></script></body></html>';
}

function shell_open(string $class = ''): void {
  echo '<div class="mx-auto w-full max-w-[1240px] px-5 sm:px-8' . ($class ? ' ' . e($class) : '') . '">';
}
function shell_close(): void { echo '</div>'; }

function section_head(string $tag, string $title, string $lede = '', string $align = 'left'): void { ?>
  <div class="relative border-t border-line pt-9">
    <span class="rule-tag tag absolute -top-[8px] flex items-center <?= $align === 'center' ? 'left-1/2 -translate-x-1/2 pl-4' : 'left-0' ?>">
      <span class="h-[5px] w-[5px] bg-brass" aria-hidden="true"></span><?= e($tag) ?>
    </span>
    <div class="<?= $align === 'center' ? 'text-center' : '' ?>">
      <h2 class="font-display text-[clamp(1.75rem,3.6vw,2.9rem)] leading-[1.06] font-bold"><?= $title ?></h2>
      <?php if ($lede): ?><p class="text-muted mt-4 text-[1.0625rem] leading-relaxed text-pretty <?= $align === 'center' ? 'mx-auto max-w-[58ch]' : 'max-w-[58ch]' ?>"><?= $lede ?></p><?php endif; ?>
    </div>
  </div>
<?php }

function figure(string $name, string $alt, string $class = '', array $opt = []): void {
  $framed = ($opt['framed'] ?? true);
  $hide = $opt['hide'] ?? '';
  $priority = !empty($opt['priority']);
  $tint = $opt['tint'] ?? '';
  $imgClass = $opt['img'] ?? '';
  $sizes = ['blocks'=>[1400,980],'flows'=>[1400,720],'globe'=>[1100,1100],'candles'=>[1400,900],'vault'=>[1200,800],'desk'=>[1400,900],'tier-basic'=>[900,560],'tier-silver'=>[900,560],'tier-gold'=>[900,560]];
  [$w,$h] = $sizes[$name] ?? [1400,900];
  $hideClass = $hide === 'lg' ? ' hidden lg:block' : ($hide === 'sm' ? ' hidden sm:block' : '');
  $frameClass = $framed ? ' border-line rounded-[3px] border shadow-[0_24px_60px_-40px_rgba(0,0,0,0.95)]' : '';
  ?>
  <figure class="relative overflow-hidden<?= $frameClass . $hideClass ?><?= $class ? ' ' . e($class) : '' ?>">
    <picture>
      <source media="(max-width: 640px)" srcset="/img/<?= e($name) ?>-sm.jpg">
      <img src="/img/<?= e($name) ?>.jpg" alt="<?= e($alt) ?>" width="<?= $w ?>" height="<?= $h ?>" loading="<?= $priority ? 'eager' : 'lazy' ?>" decoding="async" class="block h-full w-full object-cover<?= $imgClass ? ' ' . e($imgClass) : '' ?>">
    </picture>
    <?php if ($framed): ?><span class="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/15" aria-hidden="true"></span><?php endif; ?>
    <?php if ($tint): ?><span class="pointer-events-none absolute inset-x-0 bottom-0 h-1/3" style="background:linear-gradient(to top, <?= e($tint) ?>, transparent)" aria-hidden="true"></span><?php endif; ?>
  </figure>
<?php }

function figure_band(string $name, string $alt, string $height, callable $inner): void { ?>
  <section class="border-line relative overflow-hidden border-y <?= e($height) ?>">
    <picture>
      <source media="(max-width: 640px)" srcset="/img/<?= e($name) ?>-sm.jpg">
      <img src="/img/<?= e($name) ?>.jpg" alt="<?= e($alt) ?>" loading="lazy" decoding="async" class="absolute inset-0 h-full w-full object-cover">
    </picture>
    <span class="absolute inset-0" style="background:linear-gradient(to right, rgba(4,18,26,0.94) 0%, rgba(4,18,26,0.78) 42%, rgba(4,18,26,0.35) 100%)" aria-hidden="true"></span>
    <div class="relative flex h-full items-center"><?php $inner(); ?></div>
  </section>
<?php }

function page_header(string $tag, string $title, string $lede = '', string $aside = ''): void { ?>
  <section class="border-line relative border-b pt-9 pb-12 sm:pt-12">
    <?php shell_open(); ?>
      <div class="grid grid-cols-1 items-end gap-10 lg:grid-cols-[1.6fr_1fr]">
        <div>
          <span class="tag flex items-center gap-2.5"><span class="bg-brass h-[5px] w-[5px]" aria-hidden="true"></span><?= e($tag) ?></span>
          <h1 class="font-display mt-5 text-[clamp(2.1rem,4.8vw,3.5rem)] leading-[1.02] font-extrabold tracking-[-0.035em]"><?= $title ?></h1>
          <?php if ($lede): ?><p class="text-muted mt-5 max-w-[58ch] text-[1.0625rem] leading-relaxed text-pretty"><?= $lede ?></p><?php endif; ?>
        </div>
        <?php if ($aside !== ''): ?><div><?= $aside ?></div><?php endif; ?>
      </div>
    <?php shell_close(); ?>
  </section>
<?php }

function site_header(): void {
  $here = path();
  $nav = bfx_nav();
  ?>
  <header class="fixed inset-x-0 top-0 z-50 border-b border-transparent transition-[background-color,border-color,backdrop-filter] duration-400" id="site-header">
    <div class="mx-auto w-full max-w-[1240px] px-5 sm:px-8">
      <div class="flex h-[68px] items-center justify-between gap-6">
        <a href="/" aria-label="<?= e(cfg()['name']) ?> home" class="shrink-0"><?= logo() ?></a>
        <nav class="hidden items-center gap-1 lg:flex">
          <?php foreach ($nav as [$label,$href]): $on = $here === $href; ?>
            <a href="<?= e($href) ?>" class="relative rounded-[2px] px-3.5 py-2 text-[0.875rem] transition-[color,background-color] duration-200 <?= $on ? 'text-porcelain' : 'text-muted hover:bg-panel/50 hover:text-porcelain' ?>">
              <?= e($label) ?>
              <?php if ($on): ?><span class="bg-brass absolute inset-x-3.5 -bottom-px h-px"></span><?php endif; ?>
            </a>
          <?php endforeach; ?>
        </nav>
        <div class="hidden items-center gap-2.5 lg:flex">
          <div id="google_translate_element"></div>
          <a href="/login/" class="btn-ghost h-9 px-4 text-sm font-medium">Log in</a>
          <a href="/register/" class="btn-brass h-9 px-4 text-sm">Register<?= icon('arrow-up-right','h-3.5 w-3.5','2.5') ?></a>
        </div>
        <button type="button" id="nav-open" class="border-line text-porcelain flex h-10 w-10 items-center justify-center rounded-[2px] border lg:hidden" aria-label="Open menu" aria-expanded="false"><?= icon('menu','h-5 w-5') ?></button>
      </div>
    </div>
    <div id="nav-drawer" class="border-line bg-ground hidden overflow-hidden border-t lg:hidden">
      <div class="mx-auto w-full max-w-[1240px] px-5 py-5 sm:px-8">
        <nav class="flex flex-col">
          <?php foreach ($nav as [$label,$href]): ?>
            <a href="<?= e($href) ?>" class="border-line-soft flex items-center justify-between border-b py-3.5 text-lg"><?= e($label) ?><?= icon('arrow-up-right','text-faint h-4 w-4') ?></a>
          <?php endforeach; ?>
        </nav>
        <div class="mt-5 flex gap-2.5">
          <a href="/login/" class="btn-ghost h-11 flex-1 text-sm font-medium">Log in</a>
          <a href="/register/" class="btn-brass h-11 flex-1 text-sm">Register</a>
        </div>
        <div id="google_translate_element_m" class="mt-4 lg:hidden"></div>
      </div>
    </div>
  </header>
  <script>
  function googleTranslateElementInit() {
    if (!window.google || !google.translate) return;
    new google.translate.TranslateElement({pageLanguage:'en', includedLanguages:'en,hi,es,fr,de,ar,zh-CN,pt,ru,ja,ko,tr,id,vi,th,it,nl,pl,uk,bn,ur,ta,te,mr,gu', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
  }
  </script>
  <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<?php }

function site_footer(): void {
  $c = cfg();
  $nav = bfx_nav();
  $packages = [];
  foreach (plan()['plans'] as $row) $packages[] = [$row['name'] . ' · ' . $row['daily'] . '%', '/business-plan/#plans'];
  $here = path();
  ?>
  <footer class="border-line bg-ground-2/40 relative mt-28 border-t">
    <div class="mx-auto w-full max-w-[1240px] px-5 py-14 sm:px-8">
      <div class="grid grid-cols-1 gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <?= logo() ?>
          <p class="text-muted mt-4 max-w-[36ch] text-sm leading-relaxed">An award-winning multinational company. We believe in quality and standard worldwide. Forex and cryptocurrency schedules, settled only in USDT on BEP20.</p>
        </div>
        <div><p class="tag mb-4">Company</p><div class="flex flex-col gap-2.5"><?php foreach ($nav as [$l,$h]): ?><a href="<?= e($h) ?>" class="text-muted hover:text-porcelain text-sm transition-colors"><?= e($l) ?></a><?php endforeach; ?></div></div>
        <div><p class="tag mb-4">Plans</p><div class="flex flex-col gap-2.5"><?php foreach ($packages as [$l,$h]): ?><a href="<?= e($h) ?>" class="text-muted hover:text-porcelain text-sm transition-colors"><?= e($l) ?></a><?php endforeach; ?><a href="/business-plan/" class="text-muted hover:text-porcelain text-sm transition-colors">Income structure</a><a href="/marketix-presentation.pdf" class="text-muted hover:text-porcelain text-sm transition-colors">Presentation (PDF)</a><a href="/marketix-member-guide.pdf" class="text-muted hover:text-porcelain text-sm transition-colors">Member guide</a><a href="/register/" class="text-muted hover:text-porcelain text-sm transition-colors">Open an account</a></div></div>
        <div>
          <p class="tag mb-4">Reach us</p>
          <div class="flex flex-col gap-2.5">
            <a href="mailto:<?= e($c['support_email']) ?>" class="text-muted hover:text-porcelain flex items-start gap-2.5 text-sm transition-colors"><?= icon('mail','mt-0.5 h-4 w-4 shrink-0') ?><?= e($c['support_email']) ?></a>
            <a href="tel:<?= e($c['phone_tel']) ?>" class="text-muted hover:text-porcelain flex items-start gap-2.5 text-sm transition-colors"><?= icon('life-buoy','mt-0.5 h-4 w-4 shrink-0') ?><?= e($c['phone']) ?></a>
            <a href="<?= e($c['telegram']) ?>" class="text-muted hover:text-porcelain flex items-start gap-2.5 text-sm transition-colors" target="_blank" rel="noopener"><?= icon('share-2','mt-0.5 h-4 w-4 shrink-0') ?>Telegram <?= e($c['telegram_handle']) ?></a>
            <a href="<?= e($c['whatsapp']) ?>" class="text-muted hover:text-porcelain flex items-start gap-2.5 text-sm transition-colors" target="_blank" rel="noopener"><?= icon('mail','mt-0.5 h-4 w-4 shrink-0') ?>WhatsApp</a>
            <span class="text-muted flex items-start gap-2.5 text-sm"><?= icon('map-pin','mt-0.5 h-4 w-4 shrink-0') ?><span><?= e($c['address_street']) ?><br><?= e($c['address_city']) ?>, <?= e($c['address_region']) ?> <?= e($c['address_postal']) ?><br><?= e($c['address_country']) ?></span></span>
            <span class="text-faint block pt-1 font-mono text-[0.6875rem] tracking-wide"><?= e($c['hours']) ?></span>
          </div>
        </div>
      </div>
      <div class="border-line-soft mt-8 flex flex-col gap-4 border-t pt-6 sm:flex-row sm:items-center sm:justify-between">
        <p class="text-faint font-mono text-[0.6875rem] tracking-wide">© <?= (int)$c['founded'] ?>–<?= date('Y') ?> <?= e($c['name']) ?> · All rights reserved</p>
        <div class="flex flex-wrap gap-x-5 gap-y-2">
          <a href="/terms/" class="text-faint hover:text-muted font-mono text-[0.6875rem] tracking-wide transition-colors">Terms of Service</a>
          <a href="/privacy/" class="text-faint hover:text-muted font-mono text-[0.6875rem] tracking-wide transition-colors">Privacy Policy</a>
          <button type="button" id="report-open" class="text-faint hover:text-muted font-mono text-[0.6875rem] tracking-wide transition-colors bg-transparent border-0 p-0 cursor-pointer">Report to developer</button>
        </div>
      </div>
    </div>
  </footer>
  <div class="modal-bg" id="report-modal" role="dialog" aria-modal="true" aria-labelledby="report-title">
    <div class="modal">
      <div class="modal-h">
        <div>
          <p class="tag">Developer grievance</p>
          <h2 id="report-title" class="font-display mt-1 text-lg font-bold">Report to developer</h2>
        </div>
        <button type="button" class="btn-ghost" style="height:32px;width:32px" data-report-close aria-label="Close">×</button>
      </div>
      <form method="post" action="/report/" class="modal-b">
        <?= csrf_field() ?>
        <input type="hidden" name="return" value="<?= e($here) ?>">
        <input type="text" name="website" value="" tabindex="-1" autocomplete="off" class="report-hp" aria-hidden="true">
        <p class="text-muted mb-5 text-[0.875rem] leading-relaxed">Use this form to report fraud, a scam, or anything this business has done that customer support has not helped with.</p>
        <div class="flex flex-col gap-4">
          <div><label class="label" for="report-name">Full name</label><input id="report-name" name="name" class="field" placeholder="Your name" required></div>
          <div>
            <label class="label" for="report-phone">Contact number <span class="text-faint font-normal normal-case tracking-normal">(optional)</span></label>
            <input id="report-phone" name="phone" class="field" type="tel" placeholder="+91 …">
          </div>
          <div><label class="label" for="report-details">Description</label><textarea id="report-details" name="details" class="field" rows="6" placeholder="What happened" required></textarea></div>
        </div>
        <button class="btn-brass mt-6 h-12 w-full text-[0.9375rem]">Send report</button>
      </form>
    </div>
  </div>
<?php }

function cta_band(string $title = 'Open an account and choose a plan', string $body = 'Register, fund in USDT on BEP20, and activate a plan. Interest is counted 24 hours from the time the package becomes active.'): void {
  $c = cfg(); ?>
  <div class="mx-auto mt-16 w-full max-w-[1240px] px-5 sm:mt-24 sm:px-8">
    <div class="panel relative overflow-hidden">
      <span class="pointer-events-none absolute inset-0 -z-10" style="background:radial-gradient(120% 130% at 12% 0%, rgba(56,189,248,0.22), transparent 60%)" aria-hidden="true"></span>
      <div class="grid grid-cols-1 items-center gap-7 p-6 sm:gap-8 sm:p-12 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <div>
          <span class="tag">Next step</span>
          <h2 class="font-display mt-4 text-[clamp(1.75rem,3.4vw,2.6rem)] leading-[1.06] font-bold"><?= e($title) ?></h2>
          <p class="text-muted mt-4 max-w-[52ch] text-[1.0625rem] leading-relaxed text-pretty"><?= e($body) ?></p>
        </div>
        <div class="flex flex-col gap-3">
          <a href="/register/" class="btn-brass h-12 w-full text-[0.9375rem]">Open your account<?= icon('arrow-up-right','h-4 w-4','2.5') ?></a>
          <a href="/contact/" class="btn-ghost h-12 w-full text-[0.9375rem] font-medium"><?= icon('mail','h-4 w-4') ?>Email the desk</a>
          <p class="text-faint mt-1 text-center font-mono text-[0.6875rem] tracking-wide"><?= e($c['hours']) ?></p>
        </div>
      </div>
    </div>
  </div>
<?php }

function copy_field(string $value, string $display = ''): void { ?>
  <div class="border-line bg-ground-2/70 flex items-center gap-2 rounded-[2px] border p-1 pl-3" data-copy="<?= e($value) ?>">
    <code class="text-porcelain min-w-0 flex-1 truncate font-mono text-[0.8125rem]"><?= e($display !== '' ? $display : $value) ?></code>
    <button type="button" class="js-copy bg-panel-2 text-muted hover:bg-brass/10 hover:text-brass flex h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-[2px] px-2.5 font-mono text-[0.625rem] tracking-[0.1em] uppercase transition-colors"><?= icon('copy','h-3 w-3') ?>Copy</button>
  </div>
<?php }
