<?php
require_once __DIR__ . '/kit.php';
require_once __DIR__ . '/widgets.php';
require_once __DIR__ . '/auth-shell.php';
document_start($title ?? (cfg()['name'] ?? 'Marketix Ltd'), $GLOBALS['meta'] ?? []);
echo backdrop();
site_header();
echo '<main class="pt-[68px]">';
