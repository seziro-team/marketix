<?php
declare(strict_types=1);
if (PHP_SAPI === 'cli-server') {
  $p = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
  $f = __DIR__ . $p;
  if ($p !== '/' && is_file($f)) return false;
}
session_name('mtx_hostinger');
session_start([
  'cookie_httponly' => true,
  'cookie_samesite' => 'Lax',
  'cache_limiter' => 'nocache',
]);

require __DIR__ . '/lib/helpers.php';
send_no_store_headers();
require __DIR__ . '/lib/countries.php';
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/auth.php';
require __DIR__ . '/lib/engine.php';
require __DIR__ . '/lib/mail.php';
require __DIR__ . '/views/kit.php';
require __DIR__ . '/views/widgets.php';
require __DIR__ . '/views/auth-shell.php';
require __DIR__ . '/pages/marketing.php';
require __DIR__ . '/pages/auth.php';
require __DIR__ . '/pages/member.php';
require __DIR__ . '/pages/admin.php';

db();

$route = path();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($route === '/logout/' && $method === 'POST') {
  csrf_check();
  logout_user();
  redirect('/');
}

function site(string $title, callable $fn, array $meta = []): void {
  $GLOBALS['title'] = $title;
  $GLOBALS['meta'] = $meta;
  include __DIR__ . '/views/header.php';
  include __DIR__ . '/views/flash.php';
  $fn();
  include __DIR__ . '/views/footer.php';
}
function app(string $title, string $variant, callable $fn): void {
  $me = $variant === 'admin' ? require_admin() : require_member();
  ob_start();
  $fn($me);
  $content = ob_get_clean();
  include __DIR__ . '/views/app.php';
}

switch ($route) {
  case '/':
    site('Marketix Ltd', 'page_home'); break;
  case '/about/':
    site('About Us', 'page_about'); break;
  case '/investment-plan/':
    redirect('/business-plan/'); break;
  case '/business-plan/':
    site('Business Plan', 'page_business'); break;
  case '/contact/':
    if ($method === 'POST') {
      csrf_check();
      $n = trim($_POST['name'] ?? '');
      $em = trim($_POST['email'] ?? '');
      $msg = trim($_POST['message'] ?? '');
      $interest = trim($_POST['interest'] ?? '');
      if ($n === '' || !filter_var($em, FILTER_VALIDATE_EMAIL) || strlen($msg) < 8) {
        flash('Name, a valid email and a short message are required.', 'err');
        site('Contact', 'page_contact');
        break;
      }
      db()->prepare('INSERT INTO enquiries (name,email,message,created_at) VALUES (?,?,?,?)')->execute([$n, $em, $msg, now()]);
      try {
        send_mail(
          cfg()['support_email'],
          'Website enquiry from ' . $n,
          "Name: {$n}\nEmail: {$em}\nInterest: " . ($interest !== '' ? $interest : '—') . "\n\n{$msg}\n"
        );
        flash('Sent. The desk will reply to ' . $em . '.');
      } catch (Throwable $e) {
        flash('Saved, but email did not send. Write directly to ' . cfg()['support_email'] . '.', 'err');
      }
      redirect('/contact/');
    }
    site('Contact', 'page_contact'); break;
  case '/terms/':
    site('Terms of Service', 'page_terms'); break;
  case '/privacy/':
    site('Privacy Policy', 'page_privacy'); break;
  case '/report/':
    if ($method === 'POST') { handle_report(); break; }
    redirect('/');
  case '/risk-disclosure/':
    redirect('/');
  case '/login/':
    $title = 'Log in'; page_login(); break;
  case '/register/':
    $title = 'Open an account'; page_register(); break;
  case '/register/lookup/':
    page_sponsor_lookup(); break;
  case '/verify/':
    page_verify(); break;
  case '/reset/':
    page_reset(); break;
  case '/dashboard/':
    app('Dashboard', 'member', 'page_dash'); break;
  case '/dashboard/deposit/':
    app('Deposit', 'member', 'page_deposit'); break;
  case '/dashboard/wallet/':
    app('Fund wallet', 'member', 'page_wallet'); break;
  case '/dashboard/withdraw/':
    app('Withdraw', 'member', 'page_withdraw'); break;
  case '/dashboard/topup/':
    app('Top up', 'member', 'page_topup'); break;
  case '/dashboard/reinvest/':
    app('Reinvest', 'member', 'page_reinvest'); break;
  case '/dashboard/transactions/':
    app('Transactions', 'member', 'page_tx'); break;
  case '/dashboard/packages/':
    app('Packages', 'member', 'page_packages'); break;
  case '/dashboard/team/':
    app('Direct members', 'member', 'page_team'); break;
  case '/dashboard/genealogy/':
    redirect('/dashboard/team/'); break;
  case '/dashboard/income/':
    app('Income', 'member', 'page_income'); break;
  case '/dashboard/profile/':
    app('Profile', 'member', 'page_profile'); break;
  case '/dashboard/support/':
    app('Support', 'member', 'page_support'); break;
  case '/dashboard/settings/':
    app('Security', 'member', 'page_settings'); break;
  case '/admin/':
    app('Admin', 'admin', fn() => page_admin_home()); break;
  case '/admin/deposits/':
    app('Deposits', 'admin', fn() => page_admin_deposits()); break;
  case '/admin/withdrawals/':
    app('Withdrawals', 'admin', fn() => page_admin_withdrawals()); break;
  case '/admin/members/':
    app('Members', 'admin', fn() => page_admin_members()); break;
  case '/admin/referrals/':
    app('Referrals', 'admin', fn() => page_admin_referrals()); break;
  case '/admin/packages/':
    app('Plan', 'admin', fn() => page_admin_packages()); break;
  case '/admin/positions/':
    app('Plans & deposits', 'admin', fn() => page_admin_positions()); break;
  case '/admin/settings/':
    app('Settings', 'admin', fn() => page_admin_settings()); break;
  case '/admin/tickets/':
    app('Tickets', 'admin', fn() => page_admin_tickets()); break;
  default:
    http_response_code(404);
    $title = 'Page not found';
    $GLOBALS['meta'] = ['robots' => 'noindex, follow'];
    include __DIR__ . '/views/header.php';
    page_not_found();
    include __DIR__ . '/views/footer.php';
}
