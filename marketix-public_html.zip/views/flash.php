<?php $f = flash(); if ($f): ?>
  <div class="<?= $f['type'] === 'err' ? 'flash-err' : 'flash-ok' ?>"><?= e($f['msg']) ?></div>
<?php endif; ?>
