<?php
/**
 * Marketix Ltd published schedules.
 * Plan 1 daily rate is 8%: the handwritten sheet shows an 8 beside a corrected digit.
 * Interest is credited every 24 hours from the moment the package is activated.
 */
return [
  'min' => 100,
  'direct_pct' => 10,
  'min_withdraw' => 10,
  'withdraw_fee' => 10,
  'profit_fee' => 10,
  'principal_fee' => 10,
  'roi' => 8,
  'booster' => 8,
  'booster_directs' => 0,
  'booster_days' => 0,
  'strong' => 60,
  'weak' => 40,
  'plans' => [
    ['id' => 1, 'name' => 'Plan 1', 'min' => 100, 'max' => 500, 'daily' => 8],
    ['id' => 2, 'name' => 'Plan 2', 'min' => 600, 'max' => 5000, 'daily' => 10],
    ['id' => 3, 'name' => 'Plan 3', 'min' => 6000, 'max' => 50000, 'daily' => 12],
    ['id' => 4, 'name' => 'Plan 4', 'min' => 60000, 'max' => null, 'daily' => 15],
  ],
  'products' => [
    'plan' => ['name' => 'Investment plan', 'lock' => 0, 'daily' => 0],
  ],
  'subscriptions' => [],
  'levels' => [],
  'salary' => [],
  'community' => [],
];
