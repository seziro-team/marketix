<?php
require_once __DIR__ . '/public.php';

function auth_shell(string $side, string $title, string $lede, string $footer, callable $inner): void {
  public_document_start($title, ['robots' => 'noindex, follow']);
  public_header();
  ?>
  <section class="auth-wrap">
    <div class="auth-card">
      <h1><?= e($title) ?></h1>
      <p class="lede"><?= e($lede) ?></p>
      <?php include __DIR__ . '/flash.php'; ?>
      <?php $inner(); ?>
      <div class="auth-foot"><?= $footer ?></div>
    </div>
  </section>
  <?php
  public_footer();
}
